"""Read timecode, rate and length from QuickTime and MP4 headers."""

import os as _os
import struct as _struct

from smtl_models import frames_to_timecode as _timecode


_TC_DROP_FRAME = 0x0001


def read(path):
    """Return `{timecode, rate, drop, first, last}` for a file, or None."""
    if not path or not _os.path.isfile(path):
        return None
    if _os.path.splitext(path)[1].lower() not in ('.mov', '.mp4', '.m4v'):
        return None
    try:
        with open(path, 'rb') as fh:
            return _read_quicktime(fh)
    except Exception:
        return None


def _atoms(fh, end):
    """Yield (kind, body_start, end) for each atom at one level."""
    while fh.tell() + 8 <= end:
        start = fh.tell()
        header = fh.read(8)
        if len(header) < 8:
            return
        size, kind = _struct.unpack('>I4s', header)
        if size == 1:
            size = _struct.unpack('>Q', fh.read(8))[0]
        elif size == 0:
            size = end - start
        if size < 8:
            return
        yield kind, fh.tell(), start + size
        fh.seek(start + size)


def _find(fh, end, path):
    """Descend a path of atom kinds, returning (start, end) of the last."""
    if not path:
        return None
    want = path[0]
    for kind, body, stop in _atoms(fh, end):
        if kind != want:
            continue
        if len(path) == 1:
            return body, stop
        fh.seek(body)
        got = _find(fh, stop, path[1:])
        if got:
            return got
    return None


def _read_quicktime(fh):
    """Return the start timecode, rate and frame count of a QuickTime file."""
    fh.seek(0, _os.SEEK_END)
    size = fh.tell()
    fh.seek(0)
    moov = _find(fh, size, [b'moov'])
    if not moov:
        return None

    timecode = None
    picture  = None
    fh.seek(moov[0])
    for kind, body, stop in _atoms(fh, moov[1]):
        if kind != b'trak':
            continue
        got = _read_track(fh, body, stop)
        if not got:
            continue
        if got['kind'] == b'tmcd' and timecode is None:
            timecode = got
        elif got['kind'] == b'vide' and picture is None:
            picture = got
        fh.seek(stop)

    if picture is None:
        return None
    rate  = picture.get('rate') or 0.0
    count = picture.get('frames') or 0
    out = {'timecode': '', 'rate': float(rate), 'drop': False,
           'first': 1, 'last': int(count) if count else 1}
    if timecode is None or timecode.get('start') is None:
        return out

    tc_rate = timecode.get('tc_rate') or rate or 0.0
    if not tc_rate:
        return out
    out['drop']     = bool(timecode.get('drop'))
    out['timecode'] = _timecode(int(timecode['start']), tc_rate, out['drop'])
    return out


def _read_track(fh, body, stop):
    """Return one track's kind, rate, frame count and timecode start."""
    fh.seek(body)
    handler = _find(fh, stop, [b'mdia', b'hdlr'])
    if not handler:
        return None
    fh.seek(handler[0])
    head = fh.read(12)
    if len(head) < 12:
        return None
    kind = head[8:12]

    out = {'kind': kind, 'rate': 0.0, 'frames': 0, 'start': None,
           'tc_rate': 0.0, 'drop': False}

    fh.seek(body)
    mdhd = _find(fh, stop, [b'mdia', b'mdhd'])
    timescale = duration = 0
    if mdhd:
        fh.seek(mdhd[0])
        version = fh.read(1)[0]
        fh.read(3)
        if version == 1:
            fh.read(16)
            timescale = _struct.unpack('>I', fh.read(4))[0]
            duration  = _struct.unpack('>Q', fh.read(8))[0]
        else:
            fh.read(8)
            timescale = _struct.unpack('>I', fh.read(4))[0]
            duration  = _struct.unpack('>I', fh.read(4))[0]

    fh.seek(body)
    stts = _find(fh, stop, [b'mdia', b'minf', b'stbl', b'stts'])
    if stts and kind == b'vide':
        fh.seek(stts[0])
        fh.read(4)
        count = _struct.unpack('>I', fh.read(4))[0]
        frames = 0
        delta  = 0
        for _ in range(min(count, 4096)):
            n, d = _struct.unpack('>II', fh.read(8))
            frames += n
            delta = delta or d
        out['frames'] = frames
        if delta and timescale:
            out['rate'] = float(timescale) / float(delta)
    elif kind == b'vide' and timescale and duration:
        out['rate'] = 0.0

    if kind != b'tmcd':
        return out

    fh.seek(body)
    stsd = _find(fh, stop, [b'mdia', b'minf', b'stbl', b'stsd'])
    if stsd:
        fh.seek(stsd[0])
        fh.read(8)
        entry = fh.read(8)
        if len(entry) == 8 and entry[4:8] == b'tmcd':
            fh.read(6 + 2)
            fh.read(4)
            flags = _struct.unpack('>I', fh.read(4))[0]
            tc_timescale = _struct.unpack('>I', fh.read(4))[0]
            frame_duration = _struct.unpack('>I', fh.read(4))[0]
            byte = fh.read(1)
            fps_byte = byte[0] if byte else 0
            out['drop'] = bool(flags & _TC_DROP_FRAME)
            if frame_duration:
                out['tc_rate'] = float(tc_timescale) / float(frame_duration)
            elif fps_byte:
                out['tc_rate'] = float(fps_byte)

    fh.seek(body)
    offsets = _find(fh, stop, [b'mdia', b'minf', b'stbl', b'stco'])
    wide = False
    if not offsets:
        fh.seek(body)
        offsets = _find(fh, stop, [b'mdia', b'minf', b'stbl', b'co64'])
        wide = True
    if offsets:
        fh.seek(offsets[0])
        fh.read(4)
        count = _struct.unpack('>I', fh.read(4))[0]
        if count:
            where = (_struct.unpack('>Q', fh.read(8))[0] if wide
                     else _struct.unpack('>I', fh.read(4))[0])
            fh.seek(where)
            raw = fh.read(4)
            if len(raw) == 4:
                out['start'] = _struct.unpack('>I', raw)[0]
    return out

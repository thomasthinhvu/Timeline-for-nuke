"""Timeline canvas widget: painting, mouse interaction and editing gestures."""

try:
    from PySide6 import QtWidgets, QtCore, QtGui
    from PySide6.QtCore import Qt
except ImportError:
    from PySide2 import QtWidgets, QtCore, QtGui
    from PySide2.QtCore import Qt

import os, sys as _sys
_SMTL_DIR = os.path.dirname(os.path.abspath(__file__))
if _SMTL_DIR not in _sys.path:
    _sys.path.insert(0, _SMTL_DIR)

from smtl_constants import (
    _DOT_VIEW_X,
    _ICON_EDGE, _ICON_STEP, _CLIP_ICON_GAP,
    _DRAG_TOLERANCE_PX,
    _LAYER_H, _HEADER_H, _LABEL_W,
    _DEFAULT_ZOOM, _MIN_ZOOM, _MAX_ZOOM, _TRIM_HANDLE_PX, _TRIM_ROLL_PX,
    _MATCH_TAPE_W, _MATCH_TAPE_H,
    _FIT_MARGIN,
    _NO_WALL,
)
import smtl_theme as _theme
import smtl_log as _log
from smtl_widgets import _icon_from_svg as _svg_icon, is_ctrl, is_alt, is_shift
from smtl_models import (
    SMTLClip, resolve_overwrite, resolve_insert, close_gap,
    find_gap, close_span, clear_range, resolve_roll, resolve_ripple_trim,
    resolve_slip, resolve_slide,
    SMTLTransition, transition_anchors, prune_transitions,
    clamp_transition, fit_dissolve, transition_room,
    resolve_transition_drag, clip_handles,
    snapshot_transitions, restore_transitions, reanchor_transitions,
    resolve_shift_click,
    snap_targets, nearest_snap,
    layer_blocked, removal_target, removal_layers, range_layers,
    resolve_add_span, fit_span,
    clip_like, src_delta, tl_delta, match_seams,
)
from smtl_nuke import (
    _nuke_ok, _root_first_frame, _root_last_frame,
    _check_clip_offline, _node_span,
)


_SPLICE_CURSOR = None

def _get_splice_cursor():
    """Return a vertical-line cursor for splice mode."""
    global _SPLICE_CURSOR
    if _SPLICE_CURSOR is None:
        size = 28
        pix  = QtGui.QPixmap(size, size)
        pix.fill(Qt.transparent)
        p  = QtGui.QPainter(pix)
        cx = size // 2
        p.setPen(QtGui.QPen(QtGui.QColor(_theme.SPLICE_CURSOR_BG), 3,
                            Qt.SolidLine, Qt.FlatCap))
        p.drawLine(cx, 1, cx, size - 2)
        p.setPen(QtGui.QPen(QtGui.QColor(_theme.SPLICE_CURSOR_FG), 1,
                            Qt.SolidLine, Qt.FlatCap))
        p.drawLine(cx, 1, cx, size - 2)
        p.end()
        _SPLICE_CURSOR = QtGui.QCursor(pix, cx, size // 2)
    return _SPLICE_CURSOR


_TOOL_CURSORS = {}

_CLIP_ICONS = {}


def _clip_icon(slug, size):
    """icons/<slug>.svg as a pixmap `size` square, cached."""
    key = (slug, size)
    if key not in _CLIP_ICONS:
        path = os.path.join(_SMTL_DIR, 'icons', slug + '.svg')
        _CLIP_ICONS[key] = _svg_icon(path, size).pixmap(size, size)
    return _CLIP_ICONS[key]

def _get_tool_cursor(name):
    """Return the tool cursor named `name`, built from icons/cursor_<name>.svg."""
    if name not in _TOOL_CURSORS:
        cur  = None
        path = os.path.join(_SMTL_DIR, 'icons', 'cursor_%s.svg' % name)
        if os.path.exists(path):
            icon = _svg_icon(path, 24)
            if not icon.isNull():
                pix = icon.pixmap(24, 24)
                if not pix.isNull():
                    cur = QtGui.QCursor(pix, 12, 12)
        _TOOL_CURSORS[name] = cur or QtGui.QCursor(Qt.SizeHorCursor)
    return _TOOL_CURSORS[name]


class TimelineWidget(QtWidgets.QWidget):
    """Custom-painted timeline: layers on the left, clip bars on the right."""

    clip_selected       = QtCore.Signal(object)
    layer_activated     = QtCore.Signal(int)
    add_target_changed  = QtCore.Signal(int)
    cursor_moved       = QtCore.Signal(int)
    clip_dropped       = QtCore.Signal()
    clip_repositioned  = QtCore.Signal(object)
    clip_dragging      = QtCore.Signal()
    cursor_released    = QtCore.Signal()
    clip_right_clicked = QtCore.Signal(object, int, object)
    layer_lock_toggled = QtCore.Signal(int)
    layer_move_requested = QtCore.Signal(int, int)
    transition_changed = QtCore.Signal()
    transition_selected = QtCore.Signal()
    status_message     = QtCore.Signal(str)
    extend_requested   = QtCore.Signal(object, str, int)
    layer_solo_toggled = QtCore.Signal(int)
    layer_hide_toggled = QtCore.Signal(int)
    tl_bounds_changed  = QtCore.Signal()
    viewport_changed   = QtCore.Signal()
    split_requested    = QtCore.Signal(object, int)
    exit_sel_mode      = QtCore.Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._tl_start = _root_first_frame()
        self._tl_end   = _root_last_frame()

        self.layers      = []
        self.active_idx  = 0
        self._add_idx    = 0
        self._selected_gap = None
        self._sel_trans    = None
        self._trans_drag   = None
        self._trans_carry  = None
        self._trans_snap   = None
        self._trans_start_x = 0
        self._btn_layer_add    = None
        self._btn_layer_remove = None
        self.zoom       = _DEFAULT_ZOOM

        self._sel_clip     = None
        self._cursor_frame = self._tl_start

        self._dragging_cursor = False

        self._dragging_clip        = None
        self._drag_layer_idx       = 0
        self._drag_start_layer_idx = 0
        self._drag_clip_offset     = 0
        self._alt_drag_copied      = False

        self._selected_clips = set()
        self._freeze_nodes   = set()

        self._sel_anchor = None

        self._lasso_from = None
        self._lasso_to   = None
        self._drag_multi     = False
        self._drag_pending   = None
        self._drag_press_x   = 0
        self._drag_press_y   = 0
        self._drag_origins   = {}
        self._drag_anchor_ff = 0

        self._trimming_clip  = None
        self._trim_edge      = None
        self._trim_partner   = None
        self._trim_snapshot  = None
        self._trim_ripple    = False
        self._trim_track_snap = None

        self._slide_block    = None
        self._slide_layer    = 0
        self._slide_slip     = False
        self._slide_start_x  = 0
        self._slide_snap     = None
        self._trim_layer_idx = 0
        self._trim_src_min   = 0
        self._trim_src_max   = 0
        self._wall_hits      = None
        self._trim_clamped   = False
        self._trim_wanted    = None
        self._trim_orig_ff   = 0
        self._trim_orig_lf   = 0
        self._trim_orig_sf   = 0
        self._trim_orig_sl   = 0
        self._trim_start_x   = 0

        self._resize_layer_idx = None
        self._resize_start_y   = 0
        self._resize_start_h   = 0

        self._origin_frame = self._tl_start
        self._scroll_x     = 0

        self._pan_active       = False
        self._pan_start_x      = 0
        self._pan_start_scroll = 0

        self._zoom_active      = False
        self._zoom_start_x     = 0
        self._zoom_start_scale = _DEFAULT_ZOOM
        self._zoom_pivot_frame = self._tl_start

        self._mark_in  = None
        self._mark_out = None
        self._ghost_in  = None
        self._ghost_out = None

        self._tool_mode = 'edit'
        self._splice_x   = -1

        self.snap_active = True

        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMouseTracking(True)
        self.setMinimumHeight(_HEADER_H + _LAYER_H + 10)


    def set_layers(self, layers, active_idx, add_idx=None):
        """Swap in the layer model without moving the view."""
        self.layers      = layers
        self.active_idx  = active_idx
        if add_idx is not None:
            self._add_idx  = add_idx
        n = max(len(layers), 1)
        self.active_idx  = max(0, min(self.active_idx,  n - 1))
        self._add_idx    = max(0, min(self._add_idx,    n - 1))
        self._selected_gap = None
        self._selected_clips.clear()
        if self._sel_trans is not None:
            idx, tr = self._sel_trans
            if not (0 <= idx < len(self.layers)
                    and tr in self.layers[idx].transitions):
                self._sel_trans = None
        self._update_size()
        self.update()

    def set_timeline_start(self, frame):
        """Set the user-defined left edge of the timeline canvas."""
        self._tl_start     = frame if frame is not None else _root_first_frame()
        self._origin_frame = self._tl_start
        self._scroll_x     = 0
        self.tl_bounds_changed.emit()
        self.update()

    def fit_to_bounds(self):
        """Zoom and pan so the timeline, or the selection, fills the canvas."""
        canvas_w = self.width() - _LABEL_W
        first, last = fit_span(self.layers, self._tl_start, self._tl_end,
                               _FIT_MARGIN)
        span = max(1, last - first + 1)
        self.zoom      = max(_MIN_ZOOM, min(_MAX_ZOOM, canvas_w / float(span)))
        self._scroll_x = int((first - self._origin_frame) * self.zoom)
        self.viewport_changed.emit()
        self.update()


    def _update_size(self):
        total = (sum(l.height for l in self.layers)
                 if self.layers else _LAYER_H)
        self.setMinimumHeight(_HEADER_H + total + 16)

    def set_layer_buttons(self, btn_add, btn_remove):
        """Adopt the Add / Remove Layer buttons into the label column header."""
        self._btn_layer_add    = btn_add
        self._btn_layer_remove = btn_remove
        for b in (btn_add, btn_remove):
            b.setParent(self)
            b.show()
        self._layout_layer_buttons()

    def _layout_layer_buttons(self):
        """Place the layer buttons side by side in the header corner."""
        if getattr(self, '_btn_layer_add', None) is None:
            return
        pad, gap = 4, 4
        h = _HEADER_H - pad * 2
        w = (_LABEL_W - pad * 2 - gap) // 2
        self._btn_layer_add.setGeometry(pad, pad, w, h)
        self._btn_layer_remove.setGeometry(pad + w + gap, pad, w, h)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._layout_layer_buttons()


    def _frame_to_x(self, frame):
        """Convert a timeline frame to widget pixel x, accounting for pan."""
        return _LABEL_W + int((frame - self._origin_frame) * self.zoom) - self._scroll_x

    def _x_to_frame(self, x):
        """Convert widget pixel x to a timeline frame, accounting for pan."""
        return self._origin_frame + int((x - _LABEL_W + self._scroll_x) / max(self.zoom, 0.01))

    def _layer_y(self, idx):
        """Return the top y of a layer row; layer 0 is at the bottom."""
        y = _HEADER_H
        for i in range(len(self.layers) - 1, idx, -1):
            y += getattr(self.layers[i], 'height', _LAYER_H)
        return y

    def _layer_h(self, idx):
        """Return the pixel height of layer row idx."""
        return getattr(self.layers[idx], 'height', _LAYER_H)

    def _y_to_layer_idx(self, y):
        """Convert a pixel y inside the widget to a layer index."""
        cy = _HEADER_H
        for i in range(len(self.layers) - 1, -1, -1):
            lh = getattr(self.layers[i], 'height', _LAYER_H)
            if y < cy + lh:
                return i
            cy += lh
        return 0

    def _resize_layer_at(self, y):
        """Return the layer index whose bottom edge is within 4px of y, or None."""
        for i in range(len(self.layers)):
            bottom = self._layer_y(i) + self._layer_h(i)
            if abs(y - bottom) <= 4:
                return i
        return None


    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        w, h = self.width(), self.height()

        p.fillRect(0, 0, w, h, QtGui.QColor(_theme.SURFACE_BG))
        p.fillRect(0, 0, _LABEL_W, h, QtGui.QColor(_theme.PANEL_LOW_BG))

        if not self.layers:
            p.setPen(QtGui.QColor(_theme.HINT_FG))
            p.drawText(self.rect(), Qt.AlignCenter,
                       'Add layers and drag Read nodes here')
            p.end()
            return

        self._paint_ruler(p, w)

        for i, layer in enumerate(self.layers):
            self._paint_layer_bg(p, i, layer, w)

        p.setClipRect(_LABEL_W, _HEADER_H, w - _LABEL_W, h - _HEADER_H)
        for i, layer in enumerate(self.layers):
            y      = self._layer_y(i)
            lh     = self._layer_h(i)
            _muted = layer.hidden
            col    = (QtGui.QColor(_theme.CLIP_MUTED_ROW_BG) if _muted
                      else _theme.layer_colour(i))
            locked = layer.locked
            seams  = match_seams(layer)
            for clip in layer.clips:
                if clip is self._dragging_clip:
                    continue
                if (self._frame_to_x(clip.last_frame + 1) + 6 < _LABEL_W
                        or self._frame_to_x(clip.first_frame) > w):
                    continue
                self._paint_clip(p, clip, y, col, layer_locked=locked,
                                 layer_height=lh, layer_muted=_muted)
            self._paint_match_seams(p, seams, y, lh, locked)
        if self._dragging_clip is not None:
            ti  = self._drag_layer_idx
            ty  = self._layer_y(ti)
            tlh = self._layer_h(ti)
            tc  = _theme.layer_colour(ti)
            self._paint_clip(p, self._dragging_clip, ty, tc,
                             layer_locked=False, layer_height=tlh)
        p.setClipping(False)

        self._paint_transitions(p)

        self._paint_slip_ghosts(p)

        self._paint_selected_gap(p)

        self._paint_mark_overlay(p, w, h)
        self._paint_ghost_overlay(p, w, h)

        self._paint_cursor(p, h)

        if self._tool_mode == 'splice' and self._splice_x >= _LABEL_W:
            p.setPen(QtGui.QPen(QtGui.QColor(_theme.SPLICE_FG), 1))
            p.drawLine(self._splice_x, _HEADER_H, self._splice_x, h)

        if self._lasso_from is not None and self._lasso_to is not None:
            x0, y0 = self._lasso_from
            x1, y1 = self._lasso_to
            rect = QtCore.QRect(QtCore.QPoint(min(x0, x1), min(y0, y1)),
                                QtCore.QPoint(max(x0, x1), max(y0, y1)))
            fill = QtGui.QColor(_theme.LASSO_FILL)
            fill.setAlpha(_theme.LASSO_FILL_ALPHA)
            p.fillRect(rect, fill)
            pen = QtGui.QPen(QtGui.QColor(_theme.LASSO_LINE), 1, Qt.DashLine)
            pen.setDashPattern([_theme.LASSO_DASH, _theme.LASSO_DASH])
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            p.drawRect(rect)

        self._paint_label_column(p, h)

        p.setPen(QtGui.QColor(_theme.LINE))
        p.drawLine(_LABEL_W, 0, _LABEL_W, h)


        p.end()

    def _paint_ruler(self, p, w):
        p.fillRect(0, 0, w, _HEADER_H, QtGui.QColor(_theme.RULER_BG))
        p.setPen(QtGui.QColor(_theme.RULER_BASELINE_FG))
        p.drawLine(0, _HEADER_H - 1, w, _HEADER_H - 1)

        vis_first = self._x_to_frame(_LABEL_W)
        vis_last  = self._x_to_frame(w)

        raw_step = max(1, int(60.0 / self.zoom))
        for nice in [1, 2, 5, 10, 25, 50, 100, 200, 500, 1000]:
            if nice >= raw_step:
                step = nice
                break
        else:
            step = raw_step

        p.setPen(QtGui.QColor(_theme.RULER_TICK_FG))
        small_font = p.font()
        small_font.setPixelSize(10)
        p.setFont(small_font)

        frame = (vis_first // step) * step
        while frame <= vis_last + step:
            x = self._frame_to_x(frame)
            if _LABEL_W <= x <= w + 4:
                p.drawLine(x, _HEADER_H - 5, x, _HEADER_H)
                p.drawText(x + 2, _HEADER_H - 3, str(frame))
            frame += step

        for mk_frame, color, ghost in (
            (self._mark_in,   _theme.MARK_IN_FG,    False),
            (self._mark_out,  _theme.MARK_OUT_FG,   False),
            (self._ghost_in,  _theme.MARK_GHOST_FG, True),
            (self._ghost_out, _theme.MARK_GHOST_FG, True),
        ):
            if mk_frame is None:
                continue
            mx = self._frame_to_x(mk_frame)
            if not (_LABEL_W <= mx <= w + 4):
                continue
            col = QtGui.QColor(color)
            if ghost:
                col.setAlpha(_theme.MARK_GHOST_ALPHA)
            p.setPen(QtGui.QPen(col, _theme.MARK_LINE_W))
            p.drawLine(mx, 0, mx, _HEADER_H - 1)

    def _paint_transitions(self, p):
        """Draw each dissolve as a wedge across its join."""
        h = self.height()
        p.save()
        p.setClipRect(_LABEL_W, _HEADER_H, self.width() - _LABEL_W, h - _HEADER_H)
        for idx, layer in enumerate(self.layers):
            y  = self._layer_y(idx)
            lh = self._layer_h(idx)
            for tr in layer.transitions:
                x1 = self._frame_to_x(tr.first_frame)
                x2 = self._frame_to_x(tr.last_frame + 1)
                if x2 - x1 < 2:
                    continue
                top, bot = y + 3.0, y + lh - 3.0
                selected = (self._sel_trans is not None
                            and self._sel_trans[1] is tr)
                col = QtGui.QColor(_theme.TRANS_SEL_BG if selected
                                   else _theme.TRANS_BG)
                col.setAlpha(_theme.TRANS_SEL_ALPHA if selected
                             else _theme.TRANS_ALPHA)
                rect = QtCore.QRectF(x1, top, x2 - x1, bot - top)
                p.setPen(Qt.NoPen)
                p.setBrush(col)
                p.drawRect(rect)

                out_clip, inc_clip = tr.sides(layer.clips)
                line = QtGui.QColor(_theme.TRANS_FG)
                line.setAlpha(_theme.TRANS_LINE_ALPHA)
                p.setBrush(Qt.NoBrush)
                p.setPen(QtGui.QPen(line, 2.0 if selected else 1.0))
                p.drawRect(rect)
                if out_clip is not None:
                    p.drawLine(QtCore.QPointF(x1, top), QtCore.QPointF(x2, bot))
                if inc_clip is not None:
                    p.drawLine(QtCore.QPointF(x1, bot), QtCore.QPointF(x2, top))
        p.restore()

    def _transition_at(self, layer_idx, x, y):
        """Return the transition under a point, or None."""
        if not (0 <= layer_idx < len(self.layers)):
            return None
        ly, lh = self._layer_y(layer_idx), self._layer_h(layer_idx)
        if not (ly + 3 <= y <= ly + lh - 3):
            return None
        frame = self._x_to_frame(x)
        for tr in getattr(self.layers[layer_idx], 'transitions', []):
            if tr.first_frame <= frame <= tr.last_frame:
                return tr
        return None

    def _carry_transitions(self):
        """Re-anchor the carried layer's transitions onto their joins."""
        if self._trans_carry is None:
            return
        idx, snap = self._trans_carry
        if not (0 <= idx < len(self.layers)):
            return
        layer = self.layers[idx]
        restore_transitions(snap)
        reanchor_transitions(layer, snap)
        for tr in list(layer.transitions):
            clamp_transition(layer.clips, tr, layer.transitions)

    def _transition_grab(self, tr, x):
        """Return which part of a transition x is over: 'head', 'tail' or 'slide'."""
        x1 = self._frame_to_x(tr.first_frame)
        x2 = self._frame_to_x(tr.last_frame + 1)
        grab = min(_TRIM_HANDLE_PX, max(4, (x2 - x1) / 3.0))
        if abs(x - x1) <= grab:
            return 'head'
        if abs(x - x2) <= grab:
            return 'tail'
        return 'slide'

    def _drag_transition(self, x):
        """Apply a Ctrl-drag to the transition grabbed at press."""
        idx, tr, part = self._trans_drag
        before0, after0 = self._trans_snap
        delta = int(round((x - self._trans_start_x) / self.zoom))
        resolve_transition_drag(self.layers[idx].clips, tr, part,
                                before0, after0, delta,
                                self.layers[idx].transitions)
        self.update()

    def plan_transition(self, layer_idx=None, frame=None,
                        before=12, after=12):
        """Plan a dissolve without making it; return (at, before, after, why)."""
        idx = self._add_idx if layer_idx is None else layer_idx
        if not (0 <= idx < len(self.layers)):
            return None, 0, 0, 'No layer selected.'
        layer = self.layers[idx]
        if self._layer_blocked(layer):
            return None, 0, 0, 'Track is locked.'
        if frame is None:
            frame = self._cursor_frame

        anchors = transition_anchors(layer.clips)
        if not anchors:
            return None, 0, 0, 'Nothing on this layer to dissolve.'
        at = min(anchors, key=lambda a: abs(a - frame))

        others = [t for t in layer.transitions if t.at_frame != at]
        got_before, got_after, why = fit_dissolve(layer.clips, at, before,
                                                  after, others)
        return (at, got_before, got_after, why) if not why else (None, 0, 0, why)

    def add_transition(self, layer_idx=None, frame=None,
                       before=12, after=12, curve='linear'):
        """Add a dissolve on the join nearest `frame`; return (transition, message)."""
        at, got_before, got_after, why = self.plan_transition(
            layer_idx, frame, before, after)
        if why:
            return None, why
        idx   = self._add_idx if layer_idx is None else layer_idx
        layer = self.layers[idx]

        replaced = False
        for old in list(layer.transitions):
            if old.at_frame == at:
                layer.transitions.remove(old)
                if self._sel_trans is not None and self._sel_trans[1] is old:
                    self._sel_trans = None
                replaced = True

        wanted = before + after
        tr = SMTLTransition(at, got_before, got_after, curve)
        layer.transitions.append(tr)
        self._sel_trans = (idx, tr)
        self.update()
        msg = None
        if tr.length < wanted:
            room_before, room_after = transition_room(layer.clips, at,
                                                      layer.transitions)
            msg = (f'Dissolve at {at}: {tr.length} '
                   f'frame{"" if tr.length == 1 else "s"} '
                   f'(-{tr.before}/+{tr.after}) — asked for {wanted}, '
                   f'room was -{room_before}/+{room_after}.')
        elif replaced:
            msg = (f'Dissolve at {at} replaced: {tr.length} frames '
                   f'(-{tr.before}/+{tr.after}).')
        return tr, msg

    def remove_selected_transition(self):
        """Remove the selected dissolve; return True on success."""
        if self._sel_trans is None:
            return False
        idx, tr = self._sel_trans
        if 0 <= idx < len(self.layers):
            layer = self.layers[idx]
            if self._layer_blocked(layer):
                return False
            if tr in layer.transitions:
                layer.transitions.remove(tr)
        self._sel_trans = None
        self.update()
        return True

    def prune_all_transitions(self):
        """Prune and re-clamp every layer's transitions; return True if any changed."""
        changed = False
        for layer in self.layers:
            before = [(t.at_frame, t.length) for t in layer.transitions]
            prune_transitions(layer)
            if before != [(t.at_frame, t.length) for t in layer.transitions]:
                changed = True
        if self._sel_trans is not None:
            idx, tr = self._sel_trans
            if not (0 <= idx < len(self.layers)
                    and tr in self.layers[idx].transitions):
                self._sel_trans = None
        return changed

    def _paint_slip_ghosts(self, p):
        """Outline each slipping clip's full source range."""
        if not (self._slide_slip and self._slide_block):
            return
        h = self.height()
        p.save()
        p.setClipRect(_LABEL_W, _HEADER_H, self.width() - _LABEL_W, h - _HEADER_H)
        layer_idx = self._slide_layer
        if layer_idx is None or not (0 <= layer_idx < len(self.layers)):
            p.restore()
            return
        for clip in self._slide_block:
            head, tail = clip_handles(clip)
            if head <= 0 and tail <= 0:
                continue
            y  = self._layer_y(layer_idx)
            lh = self._layer_h(layer_idx)
            gx1 = self._frame_to_x(clip.first_frame - tl_delta(clip, head))
            gx2 = self._frame_to_x(clip.last_frame + 1 + tl_delta(clip, tail))
            rect = QtCore.QRectF(gx1, y + 2.5, max(gx2 - gx1, 1), lh - 5)

            pen = QtGui.QPen(QtGui.QColor(_theme.SLIP_GHOST_DIM), 1,
                             Qt.DashLine)
            pen.setDashPattern([4, 3])
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            p.drawRect(rect)

            p.setPen(QtGui.QPen(QtGui.QColor(_theme.SLIP_GHOST_FG), 1.5))
            if head > 0:
                p.drawLine(QtCore.QPointF(gx1, y + 2.5),
                           QtCore.QPointF(gx1, y + lh - 2.5))
            if tail > 0:
                p.drawLine(QtCore.QPointF(gx2, y + 2.5),
                           QtCore.QPointF(gx2, y + lh - 2.5))
        p.restore()

    def _paint_selected_gap(self, p):
        """Outline the selected gap."""
        if self._selected_gap is None:
            return
        idx, first, last = self._selected_gap
        if not (0 <= idx < len(self.layers)):
            return
        y   = self._layer_y(idx)
        lh  = self._layer_h(idx)
        x1  = self._frame_to_x(first)
        x2  = self._frame_to_x(last + 1)
        pad = self._bar_margin(lh)
        rect = QtCore.QRect(x1, y + pad, max(x2 - x1, 2), max(8, lh - pad * 2))
        p.setBrush(QtGui.QColor(*_theme.GAP_SELECTED_TINT))
        p.setPen(QtGui.QPen(QtGui.QColor(_theme.GAP_SELECTED_FG), 1,
                            Qt.DashLine))
        p.drawRect(rect)

    def _paint_mark_overlay(self, p, w, h):
        """Dim the area outside mark in/out."""
        mi, mo = self._mark_in, self._mark_out
        if mi is None and mo is None:
            return
        dim = QtGui.QColor(*_theme.MARK_DIM_TINT)
        if mi is not None:
            x_in = self._frame_to_x(mi)
            if x_in > _LABEL_W:
                p.fillRect(_LABEL_W, 0, x_in - _LABEL_W, h, dim)
        if mo is not None:
            x_out       = self._frame_to_x(mo + 1)
            right_start = max(_LABEL_W, x_out)
            if right_start < w:
                p.fillRect(right_start, 0, w - right_start, h, dim)

    def _paint_ghost_overlay(self, p, w, h):
        """Hatch the span a ghosted mark range covers."""
        if self._ghost_in is None and self._ghost_out is None:
            return
        gi = self._mark_in  if self._mark_in  is not None else self._ghost_in
        go = self._mark_out if self._mark_out is not None else self._ghost_out

        x1 = self._frame_to_x(gi) if gi is not None else _LABEL_W
        x2 = self._frame_to_x(go + 1) if go is not None else w
        x1 = max(x1, _LABEL_W)
        x2 = min(x2, w)
        if x2 <= x1:
            return

        col = QtGui.QColor(_theme.MARK_GHOST_FG)
        col.setAlpha(_theme.MARK_GHOST_HATCH_ALPHA)
        p.setPen(Qt.NoPen)
        p.setBrush(QtGui.QBrush(col, Qt.BDiagPattern))
        p.drawRect(QtCore.QRect(int(x1), 0, int(x2 - x1), h))
        p.setBrush(Qt.NoBrush)

    def _paint_layer_bg(self, p, idx, layer, w):
        """Paint a layer's row background, state tints and bottom divider."""
        y          = self._layer_y(idx)
        lh         = self._layer_h(idx)
        is_active  = (idx == self.active_idx)
        if is_active:
            row_bg = QtGui.QColor(_theme.VIEW_ROW_BG)
        else:
            row_bg = (QtGui.QColor(_theme.ROW_BG_EVEN) if idx % 2 == 0
                      else QtGui.QColor(_theme.ROW_BG_ODD))
        p.fillRect(0, y, w, lh, row_bg)
        if layer.locked:
            p.fillRect(_LABEL_W, y, w - _LABEL_W, lh, QtGui.QColor(*_theme.ROW_LOCKED_TINT))
        if layer.hidden:
            p.fillRect(_LABEL_W, y, w - _LABEL_W, lh, QtGui.QColor(*_theme.ROW_HIDDEN_TINT))
        p.setPen(QtGui.QColor(_theme.LINE_SUBTLE))
        p.drawLine(0, y + lh - 1, w, y + lh - 1)

    def _paint_label_column(self, p, h):
        """Paint the label column: background, view dot, name, S, M and padlock."""
        m        = self._label_metrics()
        _IC_LOCK = m['ic_lock']
        _IC_HIDE = m['ic_hide']
        _IC_S    = m['ic_s']
        _STEP    = m['step']
        _NAME_W  = m['name_w']

        any_solo = any(l.solo for l in self.layers)

        p.fillRect(0, 0, _LABEL_W, h, QtGui.QColor(_theme.PANEL_LOW_BG))
        for idx, layer in enumerate(self.layers):
            y           = self._layer_y(idx)
            lh          = self._layer_h(idx)
            cy          = y + lh // 2
            is_active   = (idx == self.active_idx)
            is_add_tgt  = (idx == self._add_idx)
            is_locked   = layer.locked
            is_solo     = layer.solo
            is_hidden   = layer.hidden

            if is_active:
                p.fillRect(0, y, _LABEL_W, lh, QtGui.QColor(_theme.VIEW_ROW_BG))
            if is_add_tgt:
                p.fillRect(0, y, _LABEL_W, lh, QtGui.QColor(_theme.ACCENT_BG))
            if is_locked:
                p.fillRect(0, y, _LABEL_W, lh,
                           QtGui.QColor(*_theme.ROW_LOCKED_TINT))
            p.setPen(QtGui.QColor(_theme.LINE_SUBTLE))
            p.drawLine(0, y + lh - 1, _LABEL_W, y + lh - 1)

            dot_r = m['dot_r']
            p.setOpacity(_theme.OPACITY_MUTED_ROW if is_hidden else 1.0)

            if is_active:
                p.setBrush(QtGui.QColor(_theme.VIEW_FG_DIM if any_solo
                                        else _theme.VIEW_FG))
                p.setPen(Qt.NoPen)
                p.drawEllipse(m['dot_x'] - dot_r, cy - dot_r,
                              dot_r * 2, dot_r * 2)
            else:
                p.setBrush(Qt.NoBrush)
                p.setPen(QtGui.QPen(QtGui.QColor(_theme.INDICATOR_DIM), 1.5))
                p.drawEllipse(m['dot_x'] - dot_r + 1, cy - dot_r + 1,
                              (dot_r - 1) * 2, (dot_r - 1) * 2)

            p.setOpacity(_theme.OPACITY_MUTED_ROW if is_hidden else 1.0)
            name_bright = is_active or is_add_tgt
            name_col = (QtGui.QColor(_theme.NAME_FG) if name_bright
                        else QtGui.QColor(_theme.NAME_FG_DIM))
            if is_locked:
                name_col = name_col.darker(130)
            p.setPen(name_col)
            name_font = QtGui.QFont(m['name_font'])
            name_font.setBold(name_bright)
            p.setFont(name_font)
            p.drawText(QtCore.QRect(m['name_x'], y, _NAME_W, lh),
                       Qt.AlignVCenter | Qt.AlignLeft,
                       QtGui.QFontMetrics(name_font).elidedText(
                           layer.name, Qt.ElideRight, _NAME_W))

            p.setOpacity(_theme.OPACITY_MUTED_ROW if is_hidden else 1.0)
            s_font = QtGui.QFont(m['icon_font'])
            s_font.setBold(is_solo)
            p.setFont(s_font)
            p.setPen(QtGui.QColor(
                _theme.SOLO_FG if is_solo else _theme.SOLO_FG_DIM))
            p.drawText(QtCore.QRect(_IC_S - _STEP // 2, y, _STEP, lh),
                       Qt.AlignCenter, 'S')

            p.setOpacity(1.0)
            m_font = QtGui.QFont(m['icon_font'])
            m_font.setBold(is_hidden)
            p.setFont(m_font)
            p.setPen(QtGui.QColor(
                _theme.HIDE_FG if is_hidden else _theme.HIDE_FG_DIM))
            p.drawText(QtCore.QRect(_IC_HIDE - _STEP // 2, y, _STEP, lh),
                       Qt.AlignCenter, 'M')

            p.setOpacity(1.0)
            lock_col  = (QtGui.QColor(_theme.LOCK_FG) if is_locked
                         else QtGui.QColor(_theme.LOCK_FG_DIM))
            lock_fill = lock_col if is_locked else Qt.NoBrush
            bw, bh_lock    = m['lock_w'], m['lock_h']
            lk_shw, lk_shh = m['shackle_w'], m['shackle_h']
            bx      = _IC_LOCK - bw // 2
            by_lock = cy - bh_lock // 2 + 2
            sx      = _IC_LOCK - lk_shw // 2
            sy      = by_lock - lk_shh + (0 if is_locked else -2)
            p.setBrush(lock_fill)
            p.setPen(QtGui.QPen(lock_col, 1.5))
            p.drawRoundedRect(bx, by_lock, bw, bh_lock, 2, 2)
            p.setBrush(Qt.NoBrush)
            p.setPen(QtGui.QPen(lock_col, 2.0))
            p.drawArc(sx, sy, lk_shw, lk_shh, 0, 180 * 16)

    @staticmethod
    def _advance(fm, text):
        """Return the width of `text` in this font."""
        return int(fm.horizontalAdvance(text))

    def _label_metrics(self):
        """Return label column sizes and positions derived from the widget font."""
        self.ensurePolished()
        base = self.font()
        px   = _theme.PANEL_FONT_PX

        name_font = QtGui.QFont(base)
        name_font.setPixelSize(px - 2)
        icon_font = QtGui.QFont(base)
        icon_font.setPixelSize(px)

        fm_icon = QtGui.QFontMetrics(icon_font)
        cap  = max(6, int(round(fm_icon.capHeight())))
        lock_w = int(round(cap * 0.95))
        cell = max(self._advance(fm_icon, 'S'),
                   self._advance(fm_icon, 'M'), lock_w)
        step = max(_ICON_STEP, cell + 10)
        edge = max(_ICON_EDGE, cell // 2 + 6)

        fm_name = QtGui.QFontMetrics(name_font)
        dot_r   = max(4, int(round(fm_name.height() * 0.36)))
        dot_x   = max(_DOT_VIEW_X, dot_r + 8)
        name_x  = dot_x + dot_r + 10

        ic_lock = _LABEL_W - edge
        ic_hide = ic_lock - step
        ic_s    = ic_hide - step
        return {
            'name_font': name_font, 'icon_font': icon_font,
            'dot_r': dot_r, 'dot_x': dot_x, 'dot_hit': name_x - 4,
            'name_x': name_x, 'name_w': max(20, ic_s - step // 2 - 8 - name_x),
            'step': step, 'ic_lock': ic_lock, 'ic_hide': ic_hide,
            'ic_s': ic_s,
            'lock_w': lock_w,
            'lock_h': max(5, int(round(cap * 0.62))),
            'shackle_w': max(4, int(round(cap * 0.72))),
            'shackle_h': max(4, int(round(cap * 0.55))),
        }

    def _paint_match_seams(self, p, seams, layer_y, layer_height, locked):
        """Draw splicer tape across each match-edit seam."""
        if not seams:
            return
        w   = _MATCH_TAPE_W
        h   = max(6, min(_MATCH_TAPE_H, layer_height - self._bar_margin(layer_height) * 2 - 4))
        cy  = layer_y + layer_height / 2.0 - h / 2.0
        p.save()
        p.setOpacity(_theme.OPACITY_MATCH_TAPE
                     * (_theme.OPACITY_LOCKED_ROW if locked else 1.0))
        p.setPen(QtGui.QPen(QtGui.QColor(_theme.MATCH_EDIT_TAPE_FG), 1))
        p.setBrush(QtGui.QColor(_theme.MATCH_EDIT_TAPE_BG))
        for frame, (left, right) in seams.items():
            if self._dragging_clip in (left, right):
                continue
            x = self._frame_to_x(frame)
            p.drawRoundedRect(QtCore.QRectF(x - w / 2.0, cy, w, h), 1.5, 1.5)
        p.restore()

    def _paint_clip(self, p, clip, layer_y, base_col,
                    layer_locked=False, layer_height=_LAYER_H,
                    layer_muted=False):
        x1 = self._frame_to_x(clip.first_frame)
        x2 = self._frame_to_x(clip.last_frame + 1)
        cw = max(x2 - x1, 6)
        margin = self._bar_margin(layer_height)
        cy = layer_y + margin
        ch = max(8, layer_height - margin * 2)

        is_dragging  = (clip is self._dragging_clip)
        is_waiting   = clip.is_placeholder
        is_offline   = clip.offline and not is_waiting
        is_stale     = clip.stale and not is_offline and not is_waiting
        is_disabled  = clip.disabled
        in_multi_sel = (clip in self._selected_clips)

        if is_disabled:
            col = QtGui.QColor(_theme.CLIP_DISABLED_BG)
        elif is_waiting:
            col = QtGui.QColor(_theme.CLIP_UNCONFORMED_BG)
        elif is_offline:
            col = QtGui.QColor(_theme.CLIP_OFFLINE_BG)
        elif is_stale:
            col = QtGui.QColor(_theme.CLIP_STALE_BG)
        else:
            col = QtGui.QColor(base_col if layer_muted
                               else (clip.colour or base_col))

        if clip.selected or is_dragging or in_multi_sel:
            col = col.lighter(150)

        if is_dragging:
            p.setOpacity(_theme.OPACITY_DRAGGING)
        elif is_disabled:
            p.setOpacity(_theme.OPACITY_DISABLED)
        elif is_offline:
            p.setOpacity(_theme.OPACITY_OFFLINE)
        elif layer_locked:
            p.setOpacity(_theme.OPACITY_LOCKED_ROW)

        border = (col.lighter(170) if (clip.selected or is_dragging or in_multi_sel)
                  else col.lighter(130))
        pen    = QtGui.QPen(
            border,
            2.0 if is_dragging else (1.5 if (clip.selected or in_multi_sel) else 1.0),
        )
        if is_dragging:
            pen.setStyle(Qt.DashLine)
        p.setBrush(col)
        p.setPen(pen)
        p.drawRoundedRect(x1, cy, cw, ch, 3, 3)


        if in_multi_sel and not is_dragging and cw > 8:
            p.setOpacity(1.0)
            p.setPen(QtGui.QPen(QtGui.QColor(_theme.CLIP_BRACKET_FG), 2))
            tick = min(6, ch // 3)
            p.drawLine(x1 + 1, cy,        x1 + 1, cy + tick)
            p.drawLine(x1 + 1, cy + ch,    x1 + 1, cy + ch - tick)
            p.drawLine(x2 - 2, cy,        x2 - 2, cy + tick)
            p.drawLine(x2 - 2, cy + ch,    x2 - 2, cy + ch - tick)

        if is_disabled and cw > 6:
            p.setOpacity(_theme.OPACITY_STRIKE)
            p.setPen(QtGui.QPen(QtGui.QColor(_theme.CLIP_STRIKE_FG), 1.5))
            mid_y = cy + ch // 2
            p.drawLine(x1 + 2, mid_y, x1 + cw - 2, mid_y)

        if cw > 24:
            if clip.selected or is_dragging or in_multi_sel:
                txt_col = QtGui.QColor(_theme.CLIP_LABEL_SEL_FG)
            elif is_disabled:
                txt_col = QtGui.QColor(_theme.CLIP_DISABLED_FG)
            elif is_waiting:
                txt_col = QtGui.QColor(_theme.CLIP_UNCONFORMED_FG)
            elif is_offline:
                txt_col = QtGui.QColor(_theme.CLIP_OFFLINE_FG)
            elif is_stale:
                txt_col = QtGui.QColor(_theme.CLIP_STALE_FG)
            elif clip.colour and not layer_muted:
                txt_col = QtGui.QColor(_theme.readable_fg(clip.colour))
            else:
                txt_col = QtGui.QColor(_theme.CLIP_LABEL_FG)
            p.setPen(txt_col)
            lbl_font = p.font()
            lbl_font.setPixelSize(11)
            lbl_font.setBold(clip.selected or is_dragging or in_multi_sel)
            p.setFont(lbl_font)
            clip_rect = QtCore.QRect(x1 + 5, cy, max(cw - 8, 1), ch)
            metrics   = QtGui.QFontMetrics(lbl_font)
            icon = ('+_freeze' if clip.speed == 0
                    or clip.node_name in self._freeze_nodes
                    else 'retime' if clip.speed != 1 else None)
            if icon:
                size = metrics.height()
                if cw > size + 8:
                    p.drawPixmap(x1 + 5, cy + (ch - size) // 2,
                                 _clip_icon(icon, size))
                    clip_rect.setLeft(clip_rect.left() + size
                                      + _CLIP_ICON_GAP)
            elided    = metrics.elidedText(clip.display_label, Qt.ElideRight,
                                           clip_rect.width())
            p.drawText(clip_rect, Qt.AlignVCenter | Qt.AlignLeft, elided)

        if clip.src_first < clip.orig_src_first or clip.src_last > clip.orig_src_last:
            media_x1 = self._frame_to_x(
                clip.first_frame
                + tl_delta(clip, clip.orig_src_first - clip.src_first))
            media_x2 = self._frame_to_x(
                clip.first_frame
                + tl_delta(clip, clip.orig_src_last - clip.src_first) + 1)
            hatch = QtGui.QColor(_theme.BEYOND_MEDIA_FG)
            hatch.setAlpha(_theme.BEYOND_MEDIA_ALPHA)
            p.setPen(Qt.NoPen)
            p.setBrush(QtGui.QBrush(hatch, Qt.FDiagPattern))
            if media_x1 > x1:
                p.drawRect(QtCore.QRectF(x1, cy, media_x1 - x1, ch))
            if media_x2 < x1 + cw:
                p.drawRect(QtCore.QRectF(media_x2, cy, x1 + cw - media_x2, ch))
            p.setBrush(Qt.NoBrush)

        if clip.missing or clip.arrived:
            p.setPen(Qt.NoPen)

            def _bar(lo, hi):
                gx1 = self._frame_to_x(
                    clip.first_frame + tl_delta(clip, lo - clip.src_first))
                gx2 = self._frame_to_x(
                    clip.first_frame + tl_delta(clip, hi + 1 - clip.src_first))
                gx1, gx2 = max(gx1, x1), min(gx2, x1 + cw)
                if gx2 > gx1:
                    p.drawRect(QtCore.QRectF(gx1, cy, gx2 - gx1, ch))

            amber = QtGui.QColor(_theme.ARRIVED_FRAMES_BG)
            amber.setAlpha(_theme.ARRIVED_FRAMES_ALPHA)
            p.setBrush(amber)
            for lo, hi in clip.arrived:
                _bar(lo, hi)
            red = QtGui.QColor(_theme.MISSING_FRAMES_BG)
            red.setAlpha(_theme.MISSING_FRAMES_ALPHA)
            p.setBrush(red)
            for lo, hi in clip.missing:
                _bar(lo, hi)
            p.setBrush(Qt.NoBrush)

        if (self._slide_slip and self._slide_block
                and clip in self._slide_block and cw > 62):
            p.setOpacity(1.0)
            src_font = p.font()
            src_font.setPixelSize(10)
            src_font.setBold(True)
            p.setFont(src_font)
            p.setPen(QtGui.QColor(_theme.CLIP_LABEL_SEL_FG))
            p.drawText(QtCore.QRect(x1 + 4, cy, max(cw - 8, 1), ch),
                       Qt.AlignVCenter | Qt.AlignRight,
                       '%d-%d' % (clip.src_first, clip.src_last))

        badge = ('!', _theme.CLIP_OFFLINE_BADGE) if is_offline else (
                ('?', _theme.CLIP_STALE_BADGE) if is_stale else None)
        if badge is not None and cw > 14:
            p.setOpacity(1.0)
            badge_font = p.font()
            badge_font.setPixelSize(9)
            badge_font.setBold(True)
            p.setFont(badge_font)
            p.setPen(QtGui.QColor(badge[1]))
            p.drawText(QtCore.QRect(x1 + cw - 13, cy + 1, 11, ch - 2),
                       Qt.AlignCenter, badge[0])

        p.setOpacity(1.0)

    def _paint_cursor(self, p, h):
        """Draw the playhead, full height including the ruler."""
        x = self._frame_to_x(self._cursor_frame)
        if x < _LABEL_W:
            return
        p.setPen(QtGui.QPen(QtGui.QColor(_theme.CURSOR_FG), 1.5))
        p.drawLine(x, 0, x, h)


    @staticmethod
    def _layer_blocked(layer):
        """Return True when a layer refuses edits (locked or muted)."""
        return layer_blocked(layer)


    def _resolve_collisions(self, layer_idx, arrivals, mode='overwrite'):
        """Resolve overlaps after clips land on a layer; return the result or None."""
        if not (0 <= layer_idx < len(self.layers)):
            return None
        arrivals = [c for c in arrivals if c is not None]
        if not arrivals:
            return None
        clips = self.layers[layer_idx].clips

        if mode == 'splice':
            result  = resolve_insert(clips, arrivals)
            changed = bool(result['split'] or result['shifted'])
        else:
            protected = set(arrivals)
            result = {'removed': [], 'trimmed': [], 'split': []}
            for clip in arrivals:
                if clip not in clips:
                    continue
                r = resolve_overwrite(clips, clip, protected=protected)
                for k in result:
                    result[k].extend(r[k])
            changed = bool(result['removed'] or result['trimmed'] or result['split'])

        if changed:
            self._selected_clips = {c for c in self._selected_clips if c in clips}
            return result
        return None

    def _bar_margin(self, layer_height):
        """Return the pixels a clip bar is inset from the top and bottom of its row."""
        return max(3, min(6, layer_height // 8))

    def _in_clip_bar(self, layer_idx, y):
        """Return True if y is on the clip bar rather than its resize handles."""
        if not (0 <= layer_idx < len(self.layers)):
            return False
        lh, ly = self._layer_h(layer_idx), self._layer_y(layer_idx)
        margin = self._bar_margin(lh)
        return (ly + margin) <= y <= (ly + lh - margin)

    def _clip_at(self, layer_idx, x, y):
        """Return the clip under a pointer position, or None."""
        if not self._in_clip_bar(layer_idx, y):
            return None
        frame = self._x_to_frame(x)
        for clip in self.layers[layer_idx].clips:
            if clip.first_frame <= frame <= clip.last_frame:
                return clip
        return None

    def _clear_selection(self, keep=None):
        """Clear the clip selection, optionally selecting `keep` alone."""
        self._selected_clips.clear()
        for layer in self.layers:
            for c in layer.clips:
                c.selected = False
        if keep is not None:
            self._selected_clips = {keep}
            keep.selected = True
        self._sel_clip = keep
        self._sel_anchor = keep

    def _toggle_clips(self, clips):
        """Toggle each clip in or out of the selection."""
        for c in clips:
            if c in self._selected_clips:
                self._selected_clips.discard(c)
            else:
                self._selected_clips.add(c)
        for lyr in self.layers:
            for c in lyr.clips:
                c.selected = c in self._selected_clips

    def _clips_in_rect(self, x0, y0, x1, y1):
        """Return every clip the rectangle touches."""
        lo_x, hi_x = sorted((x0, x1))
        lo_y, hi_y = sorted((y0, y1))
        out = []
        for idx, layer in enumerate(self.layers):
            top = self._layer_y(idx)
            bot = top + self._layer_h(idx)
            if bot < lo_y or top > hi_y:
                continue
            for c in layer.clips:
                cx0 = self._frame_to_x(c.first_frame)
                cx1 = self._frame_to_x(c.last_frame + 1)
                if cx1 >= lo_x and cx0 <= hi_x:
                    out.append(c)
        return out

    def _announce_selection(self):
        """Emit the current selection and repaint."""
        self._sel_clip = next(iter(self._selected_clips), None)
        self._clear_gap_selection()
        self.clip_selected.emit(self._sel_clip)
        self.update()

    def _clear_gap_selection(self):
        """Clear any selected gap; return True if one existed."""
        if self._selected_gap is not None:
            self._selected_gap = None
            return True
        return False

    def _select_layer(self, layer_idx):
        """Make layer_idx the selected (add-target) layer."""
        if layer_idx == self._add_idx or not (0 <= layer_idx < len(self.layers)):
            return
        self._add_idx = layer_idx
        self.add_target_changed.emit(layer_idx)
        self.update()

    def _set_cursor(self, x):
        """Move the cursor to the frame under pixel x, snapping when enabled."""
        frame = self._x_to_frame(x)
        frame = self._apply_snap(frame)
        if frame != self._cursor_frame:
            self._cursor_frame = frame
            self.cursor_moved.emit(frame)
            self.update()


    _SNAP_THRESHOLD_PX = 20

    def _snap_frames(self, exclude_clips=None, include_cursor=False):
        """Return the frames an edge can snap to."""
        return snap_targets(
            self.layers,
            exclude = exclude_clips or (),
            bounds  = (self._tl_start, self._tl_end),
            cursor  = self._cursor_frame if include_cursor else None,
            marks   = (self._mark_in, self._mark_out),
        )

    def _apply_snap(self, frame, exclude_clips=None, include_cursor=False):
        """Return frame snapped to the nearest edit point within the pixel threshold."""
        if not self.snap_active:
            return frame
        snap_frames = self._snap_frames(exclude_clips=exclude_clips,
                                        include_cursor=include_cursor)
        best_px  = self._SNAP_THRESHOLD_PX + 1
        best_frm = frame
        frm_x    = self._frame_to_x(frame)
        for sf in snap_frames:
            px = abs(self._frame_to_x(sf) - frm_x)
            if px < best_px:
                best_px  = px
                best_frm = sf
        return best_frm

    def _snap_delta(self, first, last, exclude_clips=None, include_cursor=True):
        """Return the offset that snaps either end of a span to a nearby cut."""
        if not self.snap_active:
            return 0
        return nearest_snap(
            self._snap_frames(exclude_clips=exclude_clips,
                              include_cursor=include_cursor),
            first, last, self.zoom, self._SNAP_THRESHOLD_PX)

    def _start_zoom(self, x):
        """Begin a zoom gesture pivoting on the frame under pixel x."""
        self._zoom_active      = True
        self._pan_active       = False
        self._zoom_start_x     = x
        self._zoom_start_scale = self.zoom
        self._zoom_pivot_frame = self._x_to_frame(x)

    def _selected_run(self):
        """Return (layer_idx, clips) if the selection is one gapless run, else None."""
        found = None
        for idx, layer in enumerate(self.layers):
            hits = [c for c in layer.clips
                    if c in self._selected_clips or c.selected]
            if not hits:
                continue
            if found is not None:
                return None
            found = (idx, sorted(hits, key=lambda c: c.first_frame))
        if found is None:
            return None
        run = found[1]
        for a, b in zip(run, run[1:]):
            if a.last_frame + 1 != b.first_frame:
                return None
        return found


    def _note_wall_hit(self, clip, edge):
        """Count a trim stopped at the media edge; return the tally."""
        if self._wall_hits is not None and self._wall_hits[:2] == (clip, edge):
            self._wall_hits = (clip, edge, self._wall_hits[2] + 1)
        else:
            self._wall_hits = (clip, edge, 1)
        return self._wall_hits[2]

    def apply_extend(self, clip, edge, wanted):
        """Extend a clip edge to the wanted source frame; return True if it grew."""
        if edge == 'head':
            delta = wanted - clip.src_first
            if delta >= 0:
                return False
            clip.src_first    = wanted
            clip.first_frame += tl_delta(clip, delta)
        else:
            delta = wanted - clip.src_last
            if delta <= 0:
                return False
            clip.src_last    = wanted
            clip.last_frame += tl_delta(clip, delta)
        lyr_idx = next((i for i, l in enumerate(self.layers)
                        if clip in l.clips), None)
        if lyr_idx is not None:
            self._resolve_collisions(lyr_idx, [clip])
        self._wall_hits = None
        self._update_size()
        self.update()
        return True

    def _trim_target_at(self, layer_idx, x):
        """Return (kind, clip, partner) for a trim at x on a layer, or None."""
        if not (0 <= layer_idx < len(self.layers)):
            return None
        clips = sorted(self.layers[layer_idx].clips, key=lambda c: c.first_frame)

        best = None
        for c in clips:
            for kind, edge_x in (('head', self._frame_to_x(c.first_frame)),
                                 ('tail', self._frame_to_x(c.last_frame + 1))):
                d = abs(x - edge_x)
                if d <= _TRIM_HANDLE_PX and (best is None or d < best[0]):
                    best = (d, kind, c)
        if best is None:
            return None

        _, kind, clip = best
        for left, right in zip(clips, clips[1:]):
            if left.last_frame + 1 != right.first_frame:
                continue
            if (clip is left and kind == 'tail') or (clip is right and kind == 'head'):
                cut_x = self._frame_to_x(right.first_frame)
                if abs(x - cut_x) <= _TRIM_ROLL_PX:
                    return 'both', left, right
                if x < cut_x:
                    return 'tail', left, None
                return 'head', right, None
        return kind, clip, None

    def _do_sel_mode_exit(self):
        """Switch from Sel L/R to Edit mode and signal the panel."""
        self._tool_mode = 'edit'
        self.exit_sel_mode.emit()


    def _show_layer_menu(self, layer_idx, global_pos):
        """Show the layer context menu at global_pos for the given layer."""
        layer = self.layers[layer_idx]
        menu  = QtWidgets.QMenu(self)
        menu.setStyleSheet(_theme.menu_style())
        act_rename = menu.addAction('Rename…')
        menu.addSeparator()
        act_up   = menu.addAction('Move Up')
        act_down = menu.addAction('Move Down')
        menu.addSeparator()
        _locked = layer.locked
        act_rename.setEnabled(not _locked)
        act_up.setEnabled(not _locked and layer_idx < len(self.layers) - 1)
        act_down.setEnabled(not _locked and layer_idx > 0)
        act_solo = menu.addAction('Solo')
        act_solo.setCheckable(True)
        act_solo.setChecked(layer.solo)
        act_mute = menu.addAction('Mute')
        act_mute.setCheckable(True)
        act_mute.setChecked(layer.hidden)
        act_lock = menu.addAction('Lock')
        act_lock.setCheckable(True)
        act_lock.setChecked(layer.locked)

        chosen = menu.exec_(global_pos)

        if chosen == act_rename:
            dlg = QtWidgets.QInputDialog(self)
            dlg.setWindowTitle('Rename Track')
            dlg.setLabelText('Track name:')
            dlg.setTextValue(layer.name)
            dlg.setInputMode(QtWidgets.QInputDialog.TextInput)
            dlg.resize(320, 120)
            if dlg.exec_() == QtWidgets.QDialog.Accepted:
                new_name = dlg.textValue().strip()
                if new_name:
                    layer.name = new_name
                    self.update()
                    self.tl_bounds_changed.emit()

        elif chosen == act_up:
            self.layer_move_requested.emit(layer_idx, 1)

        elif chosen == act_down:
            self.layer_move_requested.emit(layer_idx, -1)

        elif chosen == act_solo:
            self._toggle_solo(layer_idx)

        elif chosen == act_mute:
            self._toggle_mute(layer_idx)

        elif chosen == act_lock:
            layer.locked = not layer.locked
            self.layer_lock_toggled.emit(layer_idx)
            self.update()

    def _toggle_solo(self, layer_idx):
        """Toggle solo on a layer; solo and mute are mutually exclusive."""
        layer    = self.layers[layer_idx]
        was_solo = layer.solo
        for lyr in self.layers:
            lyr.solo = False
        if not was_solo:
            layer.solo   = True
            layer.hidden = False
        self.layer_solo_toggled.emit(layer_idx)
        self.layer_hide_toggled.emit(layer_idx)
        self.update()

    def _toggle_mute(self, layer_idx):
        """Toggle mute on a layer; mute and solo are mutually exclusive."""
        layer    = self.layers[layer_idx]
        new_mute = not layer.hidden
        layer.hidden = new_mute
        if new_mute:
            layer.solo = False
        self.layer_hide_toggled.emit(layer_idx)
        self.layer_solo_toggled.emit(layer_idx)
        self.update()


    def mousePressEvent(self, event):
        btn = event.button()
        x   = event.pos().x()
        y   = event.pos().y()

        if btn == Qt.MiddleButton:
            if event.buttons() & Qt.LeftButton:
                self._start_zoom(x)
            else:
                self._pan_active       = True
                self._pan_start_x      = x
                self._pan_start_scroll = self._scroll_x
            return

        if btn == Qt.LeftButton and (event.buttons() & Qt.MiddleButton):
            self._pan_active = False
            self._start_zoom(x)
            return

        if btn == Qt.RightButton and x < _LABEL_W and y >= _HEADER_H:
            layer_idx = self._y_to_layer_idx(y)
            if 0 <= layer_idx < len(self.layers):
                self._show_layer_menu(layer_idx,
                                      self.mapToGlobal(QtCore.QPoint(x, y)))
            return

        if btn == Qt.RightButton and x >= _LABEL_W and y >= _HEADER_H:
            layer_idx = self._y_to_layer_idx(y)
            if 0 <= layer_idx < len(self.layers):
                clip = self._clip_at(layer_idx, x, y)
                if clip is not None:
                    self.clip_right_clicked.emit(
                        clip, layer_idx,
                        self.mapToGlobal(QtCore.QPoint(x, y)),
                    )
            return

        if btn != Qt.LeftButton:
            return

        if is_ctrl(event.modifiers()) and is_shift(event.modifiers()):
            self._lasso_from = (x, y)
            self._lasso_to   = (x, y)
            return

        if self._tool_mode == 'splice' and x >= _LABEL_W and y >= _HEADER_H:
            layer_idx = self._y_to_layer_idx(y)
            if (0 <= layer_idx < len(self.layers)
                    and not self._layer_blocked(self.layers[layer_idx])):
                f_raw = (x - _LABEL_W + self._scroll_x) / max(self.zoom, 0.01)
                frame = self._origin_frame + int(f_raw + 0.5) - 1
                for clip in self.layers[layer_idx].clips:
                    if clip.duration < 2:
                        continue
                    x1 = self._frame_to_x(clip.first_frame)
                    x2 = self._frame_to_x(clip.last_frame + 1)
                    if x1 <= x < x2:
                        clamped = max(clip.first_frame, min(clip.last_frame - 1, frame))
                        self.split_requested.emit(clip, clamped)
                        break
            return

        if self._tool_mode in ('sel_left', 'sel_right') and x >= _LABEL_W and y >= _HEADER_H:
            layer_idx = self._y_to_layer_idx(y)
            if not (0 <= layer_idx < len(self.layers)):
                return

            frame = self._x_to_frame(x)
            mods  = event.modifiers()

            hit = self._clip_at(layer_idx, x, y)

            if hit is None or self._layer_blocked(self.layers[layer_idx]):
                self.update()
                return

            is_right = (self._tool_mode == 'sel_right')

            new_sel = set()
            for c in self.layers[layer_idx].clips:
                if is_right:
                    if c.first_frame >= hit.first_frame:
                        new_sel.add(c)
                else:
                    if c.first_frame <= hit.first_frame:
                        new_sel.add(c)

            if is_shift(mods):
                if new_sel and new_sel <= self._selected_clips:
                    self._selected_clips -= new_sel
                else:
                    self._selected_clips |= new_sel
            else:
                self._selected_clips.clear()
                self._selected_clips |= new_sel

            for lyr in self.layers:
                for c in lyr.clips:
                    c.selected = c in self._selected_clips

            self._sel_clip = next(iter(new_sel), None) if new_sel else None
            self.clip_selected.emit(self._sel_clip)
            self.update()
            return

        slide_hit = None
        if self._tool_mode == 'slide' and x >= _LABEL_W and y >= _HEADER_H:
            layer_idx = self._y_to_layer_idx(y)
            if (0 <= layer_idx < len(self.layers)
                    and not self._layer_blocked(self.layers[layer_idx])):
                slide_hit = self._clip_at(layer_idx, x, y)

        if slide_hit is not None:
            hit = slide_hit
            if hit not in self._selected_clips:
                self._clear_selection(keep=hit)
                self._clear_gap_selection()
                self._select_layer(layer_idx)
                self.clip_selected.emit(hit)

            run = self._selected_run()
            if run is None:
                self.update()
                return

            self._slide_layer, self._slide_block = run
            self._slide_slip    = is_shift(event.modifiers())
            self._slide_start_x = x
            self._slide_snap    = [
                (c, c.first_frame, c.last_frame, c.src_first, c.src_last)
                for c in self.layers[self._slide_layer].clips
            ]
            self._trans_carry   = (self._slide_layer,
                                   snapshot_transitions(
                                       self.layers[self._slide_layer]))
            self.update()
            return

        if y < _HEADER_H:
            self._set_cursor(x)
            self._dragging_cursor = True
            return

        ri = self._resize_layer_at(y)
        if ri is not None:
            self._resize_layer_idx = ri
            self._resize_start_y   = y
            self._resize_start_h   = self._layer_h(ri)
            return

        layer_idx = self._y_to_layer_idx(y)

        if x < _LABEL_W:
            if 0 <= layer_idx < len(self.layers):
                _m       = self._label_metrics()
                _half    = _m['step'] // 2
                _ic_lock = _m['ic_lock']
                _ic_hide = _m['ic_hide']
                _ic_s    = _m['ic_s']
                if x >= _ic_lock - _half:
                    layer = self.layers[layer_idx]
                    layer.locked = not layer.locked
                    self.layer_lock_toggled.emit(layer_idx)
                    self.update()
                elif x >= _ic_hide - _half:
                    self._toggle_mute(layer_idx)
                elif x >= _ic_s - _half:
                    self._toggle_solo(layer_idx)
                elif x <= _m['dot_hit']:
                    self.layer_activated.emit(layer_idx)
                    self.update()
                else:
                    self._select_layer(layer_idx)
            return

        if x >= _LABEL_W and y >= _HEADER_H and self._tool_mode in ('edit', 'trim'):
            t_idx = self._y_to_layer_idx(y)
            t_hit = self._transition_at(t_idx, x, y)
            if (t_hit is not None and self._tool_mode == 'trim'
                    and is_ctrl(event.modifiers())
                    and not self._layer_blocked(self.layers[t_idx])):
                self._sel_trans     = (t_idx, t_hit)
                self._trans_drag    = (t_idx, t_hit,
                                       self._transition_grab(t_hit, x))
                self._trans_snap    = (t_hit.before, t_hit.after)
                self._trans_start_x = x
                self._select_layer(t_idx)
                self.clip_selected.emit(None)
                self.transition_selected.emit()
                self.update()
                return
            if t_hit is not None and self._tool_mode == 'edit':
                self._clear_selection()
                self._clear_gap_selection()
                self._sel_trans = (t_idx, t_hit)
                self._select_layer(t_idx)
                self.clip_selected.emit(None)
                self.transition_selected.emit()
                self.update()
                return

        cx = self._frame_to_x(self._cursor_frame)
        if abs(x - cx) <= 6:
            self._set_cursor(x)
            self._dragging_cursor = True
            return

        if 0 <= layer_idx < len(self.layers):
            frame      = self._x_to_frame(x)
            _in_bar    = self._in_clip_bar(layer_idx, y)
            mods_press = event.modifiers()
            layer_lock = self._layer_blocked(self.layers[layer_idx])

            if self._press_trim_handle(x, layer_idx, _in_bar,
                                       mods_press, layer_lock):
                return
            self._press_clip_body(event, x, y, frame, layer_idx, layer_lock)

    def _press_trim_handle(self, x, layer_idx, _in_bar, mods_press, layer_lock):
        """Start a trim from a left-press on a clip edge; return True if taken."""
        if _in_bar and not layer_lock and self._tool_mode == 'trim':
            target = self._trim_target_at(layer_idx, x)

            if target is not None:
                trim_edge, trim_hit, partner = target
                self._trimming_clip  = trim_hit
                self._trim_edge      = trim_edge
                self._trim_partner   = partner
                self._trim_ripple = (is_shift(mods_press)
                                     and trim_edge != 'both')
                self._trim_track_snap = [
                    (c, c.first_frame, c.last_frame, c.src_first, c.src_last)
                    for c in self.layers[layer_idx].clips
                ] if self._trim_ripple else None
                self._trans_carry = (layer_idx,
                                     snapshot_transitions(self.layers[layer_idx]))
                self._trim_snapshot  = (
                    (trim_hit.first_frame, trim_hit.last_frame,
                     trim_hit.src_first, trim_hit.src_last),
                    (partner.first_frame, partner.last_frame,
                     partner.src_first, partner.src_last)
                ) if partner is not None else None
                self._trim_layer_idx = layer_idx
                through = is_alt(mods_press)
                self._trim_src_min = (
                    -_NO_WALL if (through
                                  or trim_hit.src_first < trim_hit.orig_src_first)
                    else trim_hit.orig_src_first)
                self._trim_src_max = (
                    _NO_WALL if (through
                                 or trim_hit.src_last > trim_hit.orig_src_last)
                    else trim_hit.orig_src_last)
                if through:
                    self.status_message.emit(
                        f'{trim_hit.display_label}: trimming past its media.')
                self._trim_clamped = False
                self._trim_wanted  = None
                self._trim_orig_ff   = trim_hit.first_frame
                self._trim_orig_lf   = trim_hit.last_frame
                self._trim_orig_sf   = trim_hit.src_first
                self._trim_orig_sl   = trim_hit.src_last
                self._trim_start_x   = x
                self._clear_selection(keep=trim_hit)
                if partner is not None:
                    self._selected_clips.add(partner)
                    partner.selected = True
                self._sel_clip       = trim_hit
                self.clip_selected.emit(trim_hit)
                self.update()
                return True

    def _press_clip_body(self, event, x, y, frame, layer_idx, layer_lock):
        """Handle a left-press on a clip body or on empty track."""
        hit = self._clip_at(layer_idx, x, y)

        if hit:
            mods      = event.modifiers()
            frame_off = self._x_to_frame(x) - hit.first_frame
            self._sel_trans = None

            if is_shift(mods):
                span, anchor = resolve_shift_click(
                    self.layers[layer_idx].clips, self._sel_anchor, hit)
                self._toggle_clips(span)
                self._select_layer(layer_idx)
                self._announce_selection()
                self._sel_anchor = anchor
                return

            if is_alt(mods) and self._tool_mode != 'trim':
                self._clear_selection()
                copy = clip_like(hit, hit.first_frame, hit.last_frame,
                                 hit.src_first, hit.src_last)
                copy.selected = True
                self.layers[layer_idx].clips.append(copy)
                self._sel_clip             = copy
                self._dragging_clip        = copy
                self._drag_layer_idx       = layer_idx
                self._drag_start_layer_idx = layer_idx
                self._drag_clip_offset     = frame_off
                self._alt_drag_copied      = True
                self._select_layer(layer_idx)
                self.clip_selected.emit(copy)
            else:
                if hit not in self._selected_clips:
                    self._clear_selection(keep=hit)

                hit.selected = True
                self._sel_clip = hit
                self._clear_gap_selection()
                self._select_layer(layer_idx)
                self.clip_selected.emit(hit)

                if not layer_lock and self._tool_mode != 'trim':
                    self._drag_pending         = hit
                    self._drag_press_x         = x
                    self._drag_press_y         = y
                    self._drag_layer_idx       = layer_idx
                    self._drag_start_layer_idx = layer_idx
                    self._drag_clip_offset     = frame_off

                    if len(self._selected_clips) > 1:
                        self._drag_multi     = True
                        self._drag_anchor_ff = hit.first_frame
                        self._drag_origins   = {}
                        for li, lyr in enumerate(self.layers):
                            if self._layer_blocked(lyr):
                                continue
                            for c in lyr.clips:
                                if c in self._selected_clips:
                                    self._drag_origins[id(c)] = (
                                        c, c.first_frame, c.last_frame, li)
            self.update()
        else:
            self._clear_selection()
            self._sel_trans = None

            gap = None
            if not self._layer_blocked(self.layers[layer_idx]):
                gap = find_gap(self.layers[layer_idx].clips, frame,
                               track_first=self._tl_start)

            if gap is not None:
                self._selected_gap = (layer_idx, gap[0], gap[1])
                self._select_layer(layer_idx)
                self.clip_selected.emit(None)
                self.update()
            else:
                self._selected_gap = None
                self._set_cursor(x)
                self._dragging_cursor = True

    def mouseMoveEvent(self, event):
        x, y    = event.pos().x(), event.pos().y()
        buttons = event.buttons()
        held    = buttons & Qt.LeftButton

        if self._lasso_from is not None and held:
            self._lasso_to = (x, y)
            self.update()
            return

        if self._zoom_active and (buttons & Qt.MiddleButton):
            dx       = x - self._zoom_start_x
            new_zoom = max(_MIN_ZOOM, min(_MAX_ZOOM,
                           self._zoom_start_scale * (1.008 ** dx)))
            self.zoom      = new_zoom
            self._scroll_x = (
                _LABEL_W
                + int((self._zoom_pivot_frame - self._origin_frame) * self.zoom)
                - self._zoom_start_x
            )
            self._update_size()
            self.viewport_changed.emit()
            self.update()
            return

        if self._pan_active and (buttons & Qt.MiddleButton) and not held:
            dx             = x - self._pan_start_x
            self._scroll_x = self._pan_start_scroll - dx
            self.viewport_changed.emit()
            self.update()
            return

        if self._resize_layer_idx is not None:
            dy    = y - self._resize_start_y
            new_h = max(_LAYER_H, self._resize_start_h + dy)
            self.layers[self._resize_layer_idx].height = new_h
            self._update_size()
            self.update()
            return

        if held and self._trans_drag is not None:
            self._drag_transition(x)
            return

        if held and self._slide_block is not None:
            delta = int(round((x - self._slide_start_x) / self.zoom))
            for c, ff, lf, sf, sl in self._slide_snap:
                c.first_frame, c.last_frame = ff, lf
                c.src_first,   c.src_last   = sf, sl
            if self._slide_slip:
                resolve_slip(self._slide_block, -delta)
            else:
                grp_ff = min(c.first_frame for c in self._slide_block) + delta
                grp_lf = max(c.last_frame  for c in self._slide_block) + delta
                delta += self._snap_delta(grp_ff, grp_lf,
                                          exclude_clips=set(self._slide_block))
                resolve_slide(self.layers[self._slide_layer].clips,
                              self._slide_block, delta,
                              track_first=self._tl_start)
            self._carry_transitions()
            self._update_size()
            self.update()
            self.clip_dragging.emit()
            return

        if held and self._trimming_clip is not None:
            clip  = self._trimming_clip
            dx    = x - self._trim_start_x
            delta = int(round(dx / self.zoom))

            if self._trim_ripple:
                for c, ff, lf, sf, sl in self._trim_track_snap:
                    c.first_frame, c.last_frame = ff, lf
                    c.src_first,   c.src_last   = sf, sl
                resolve_ripple_trim(self.layers[self._trim_layer_idx].clips,
                                    clip, self._trim_edge, delta)
                self._carry_transitions()
                self._update_size()
                self.update()
                return

            if self._trim_edge == 'both':
                right = self._trim_partner
                (l_ff, l_lf, l_sf, l_sl), (r_ff, r_lf, r_sf, r_sl) = self._trim_snapshot
                clip.first_frame,  clip.last_frame  = l_ff, l_lf
                clip.src_first,    clip.src_last    = l_sf, l_sl
                right.first_frame, right.last_frame = r_ff, r_lf
                right.src_first,   right.src_last   = r_sf, r_sl
                resolve_roll(clip, right, delta)
                self._carry_transitions()
                self._update_size()
                self.update()
                return

            src_move = src_delta(clip, delta)
            if self._trim_edge == 'head':
                self._trim_wanted  = self._trim_orig_sf + src_move
                self._trim_clamped = self._trim_wanted < self._trim_src_min
                new_sf       = max(self._trim_src_min, self._trim_wanted)
                actual_src   = new_sf - self._trim_orig_sf
                new_ff       = min(self._trim_orig_ff + tl_delta(clip, actual_src),
                                   self._trim_orig_lf)
                new_sf       = self._trim_orig_sf + src_delta(
                    clip, new_ff - self._trim_orig_ff)
                snapped_ff   = self._apply_snap(new_ff, exclude_clips={clip},
                                                include_cursor=True)
                if snapped_ff != new_ff:
                    new_sf = self._trim_orig_sf + src_delta(
                        clip, snapped_ff - self._trim_orig_ff)
                    new_sf = max(self._trim_src_min, min(self._trim_src_max, new_sf))
                    new_ff = snapped_ff
                clip.src_first   = new_sf
                clip.first_frame = new_ff
            else:
                self._trim_wanted  = self._trim_orig_sl + src_move
                self._trim_clamped = self._trim_wanted > self._trim_src_max
                new_sl       = min(self._trim_src_max, self._trim_wanted)
                actual_src   = new_sl - self._trim_orig_sl
                new_lf       = max(self._trim_orig_lf + tl_delta(clip, actual_src),
                                   self._trim_orig_ff)
                new_sl       = self._trim_orig_sl + src_delta(
                    clip, new_lf - self._trim_orig_lf)
                snapped_lf = self._apply_snap(new_lf + 1, exclude_clips={clip},
                                              include_cursor=True) - 1
                if snapped_lf != new_lf and snapped_lf >= self._trim_orig_ff:
                    new_sl = self._trim_orig_sl + src_delta(
                        clip, snapped_lf - self._trim_orig_lf)
                    new_sl = max(self._trim_src_min, min(self._trim_src_max, new_sl))
                    new_lf = self._trim_orig_lf + tl_delta(
                        clip, new_sl - self._trim_orig_sl)
                clip.src_last   = new_sl
                clip.last_frame = new_lf

            self._carry_transitions()
            self._update_size()
            self.update()
            return

        if held and self._drag_pending is not None and self._dragging_clip is None:
            if (is_ctrl(event.modifiers()) or
                    abs(x - self._drag_press_x) >= _DRAG_TOLERANCE_PX or
                    abs(y - self._drag_press_y) >= _DRAG_TOLERANCE_PX):
                self._dragging_clip = self._drag_pending
                self._drag_pending  = None
                self._drag_clip_offset = (self._x_to_frame(x)
                                          - self._dragging_clip.first_frame)
            else:
                return

        if held and self._dragging_clip is not None:
            clip = self._dragging_clip

            if self._drag_multi and self._drag_origins:
                dragged_set = {c for (c, *_) in self._drag_origins.values()}
                new_anchor  = self._x_to_frame(x) - self._drag_clip_offset
                delta       = new_anchor - self._drag_anchor_ff
                origins  = list(self._drag_origins.values())
                grp_ff   = min(o[1] for o in origins) + delta
                grp_lf   = max(o[2] for o in origins) + delta
                if not is_shift(event.modifiers()):
                    delta += self._snap_delta(grp_ff, grp_lf,
                                              exclude_clips=dragged_set)
                for _id, (c, orig_ff, orig_lf, _li) in self._drag_origins.items():
                    dur           = orig_lf - orig_ff
                    c.first_frame = orig_ff + delta
                    c.last_frame  = c.first_frame + dur
                self._update_size()
                self.update()
                self.clip_dragging.emit()
                return

            duration  = clip.duration
            new_first = self._x_to_frame(x) - self._drag_clip_offset
            if not is_shift(event.modifiers()):
                new_first += self._snap_delta(new_first, new_first + duration - 1,
                                              exclude_clips={clip})
            clip.first_frame = new_first
            clip.last_frame  = new_first + duration - 1

            if y >= _HEADER_H:
                new_idx = self._y_to_layer_idx(y)
                new_idx = max(0, min(new_idx, len(self.layers) - 1))
                if (new_idx != self._drag_layer_idx
                        and not self._layer_blocked(self.layers[new_idx])):
                    self._drag_layer_idx = new_idx

            self._update_size()
            self.update()
            self.clip_dragging.emit()
            return

        if held and self._dragging_cursor:
            self._set_cursor(x)
            return


        if self._tool_mode == 'splice' and x >= _LABEL_W and y >= _HEADER_H:
            layer_idx = self._y_to_layer_idx(y)
            over_clip = False
            if 0 <= layer_idx < len(self.layers):
                frame = self._x_to_frame(x)
                for clip in self.layers[layer_idx].clips:
                    if clip.first_frame < frame < clip.last_frame:
                        over_clip = True
                        break
            if over_clip:
                if self._splice_x != x:
                    self._splice_x = x
                    self.update()
                self.setCursor(_get_splice_cursor())
            else:
                if self._splice_x != -1:
                    self._splice_x = -1
                    self.update()
                self.setCursor(Qt.ArrowCursor)
            return

        if self._splice_x != -1:
            self._splice_x = -1
            self.update()

        if self._resize_layer_at(y) is not None:
            self.setCursor(Qt.SizeVerCursor)
            return
        cx = self._frame_to_x(self._cursor_frame)
        if abs(x - cx) <= 5 and x >= _LABEL_W:
            self.setCursor(Qt.SizeHorCursor)
            return
        if y >= _HEADER_H and x >= _LABEL_W:
            layer_idx = self._y_to_layer_idx(y)
            if 0 <= layer_idx < len(self.layers):
                mods    = QtWidgets.QApplication.keyboardModifiers()
                if self._clip_at(layer_idx, x, y) is not None:
                    if self._tool_mode == 'slide':
                        self.setCursor(_get_tool_cursor(
                            'slip' if is_shift(mods) else 'slide'))
                        return

                    if self._tool_mode == 'trim' and is_ctrl(mods):
                        tr = self._transition_at(layer_idx, x, y)
                        if tr is not None:
                            part = self._transition_grab(tr, x)
                            self.setCursor(_get_tool_cursor(
                                'slide' if part == 'slide' else 'trim_' + part))
                            return

                    if self._tool_mode == 'trim':
                        target = self._trim_target_at(layer_idx, x)
                        if target is not None:
                            kind = target[0]
                            if is_shift(mods) and kind != 'both':
                                kind += '_ripple'
                            self.setCursor(_get_tool_cursor('trim_' + kind))
                            return
                    if self._tool_mode != 'trim':
                        self.setCursor(Qt.DragCopyCursor if is_alt(mods)
                                       else Qt.SizeAllCursor)
                        return
        self.setCursor(Qt.ArrowCursor)

    def mouseReleaseEvent(self, event):
        if self._lasso_from is not None:
            x0, y0 = self._lasso_from
            x1, y1 = self._lasso_to or self._lasso_from
            self._lasso_from = self._lasso_to = None
            self._sel_anchor = None
            caught = self._clips_in_rect(x0, y0, x1, y1)
            if caught:
                self._toggle_clips(caught)
                self._announce_selection()
            else:
                self.update()
            return

        if event.button() == Qt.MiddleButton:
            self._pan_active  = False
            self._zoom_active = False
            return

        if event.button() == Qt.LeftButton:
            if self._trans_drag is not None:
                idx, tr, _part = self._trans_drag
                self._trans_drag = None
                self._trans_snap = None
                self.update()
                if tr.length < 1 and tr in self.layers[idx].transitions:
                    self.layers[idx].transitions.remove(tr)
                    self._sel_trans = None
                self.transition_changed.emit()
                return

            if self._slide_block is not None:
                lyr_idx = self._slide_layer
                slipped = self._slide_slip
                block   = self._slide_block
                self._slide_block = None
                self._slide_snap  = None
                self._slide_slip  = False
                self._trans_carry = None
                touched = block if slipped else list(self.layers[lyr_idx].clips)
                self.update()
                self.clip_repositioned.emit(
                    frozenset((lyr_idx, c) for c in touched))
                return

            if self._trimming_clip is not None:
                clip    = self._trimming_clip
                partner = self._trim_partner
                edge    = self._trim_edge
                ripple  = self._trim_ripple
                lyr_idx = self._trim_layer_idx
                self._trimming_clip = None
                self._trim_edge     = None
                self._trim_partner  = None
                self._trim_snapshot = None
                self._trim_ripple   = False
                self._trim_track_snap = None
                self._trans_carry   = None
                if ripple:
                    touched = list(self.layers[lyr_idx].clips)
                else:
                    touched = [clip] if partner is None else [clip, partner]

                if (self._trim_clamped and edge in ('head', 'tail')
                        and not ripple):
                    if self._note_wall_hit(clip, edge) >= 2:
                        self.extend_requested.emit(clip, edge,
                                                   int(self._trim_wanted))
                    else:
                        self.status_message.emit(
                            f'{clip.display_label}: end of media. '
                            f'Trim again to extend past it.')
                elif not ripple:
                    self._wall_hits = None
                self._trim_clamped = False

                if edge != 'both' and not ripple:
                    self._resolve_collisions(lyr_idx, [clip])
                self.update()
                self.clip_repositioned.emit(
                    frozenset((lyr_idx, c) for c in touched))
                return

            if self._resize_layer_idx is not None:
                self._resize_layer_idx = None
                self.tl_bounds_changed.emit()
                self.update()
                return

            if self._zoom_active:
                self._zoom_active = False
                return

            dragged_clip      = self._dragging_clip
            was_dragging_clip = dragged_clip is not None
            was_dragging_csr  = self._dragging_cursor
            self._drag_pending = None
            was_multi_drag    = self._drag_multi
            layer_changed     = (self._drag_layer_idx != self._drag_start_layer_idx)
            final_layer_idx   = self._drag_layer_idx
            was_alt_copy      = self._alt_drag_copied

            self._dragging_clip   = None
            self._dragging_cursor = False
            self._alt_drag_copied = False
            self._drag_multi      = False

            if (was_alt_copy and dragged_clip is not None
                    and self._layer_blocked(self.layers[final_layer_idx])):
                lyr = self.layers[final_layer_idx]
                if dragged_clip in lyr.clips:
                    lyr.clips.remove(dragged_clip)
                self._drag_origins.clear()
                self._clear_selection()
                self.status_message.emit(
                    f'Track "{lyr.name}" refuses edits — '
                    f'drag the copy onto another layer.')
                self.update()
                self.clip_selected.emit(None)
                return

            if was_multi_drag and self._drag_origins:
                moved = frozenset((li, c) for _, (c, _, _, li) in self._drag_origins.items())
                self._drag_origins.clear()
                for li in {li for li, _ in moved}:
                    self._resolve_collisions(li, [c for l, c in moved if l == li])
                self.update()
                self.clip_repositioned.emit(moved)
            else:
                self._drag_origins.clear()
                if was_dragging_clip and layer_changed and dragged_clip is not None:
                    src = self._drag_start_layer_idx
                    if dragged_clip in self.layers[src].clips:
                        self.layers[src].clips.remove(dragged_clip)
                    self.layers[final_layer_idx].clips.append(dragged_clip)

                if was_dragging_clip and dragged_clip is not None:
                    self._resolve_collisions(final_layer_idx, [dragged_clip])

                self.update()
                if was_dragging_clip:
                    if layer_changed or was_alt_copy:
                        self.clip_dropped.emit()
                    else:
                        self.clip_repositioned.emit(
                            frozenset([(final_layer_idx, dragged_clip)]))
                elif was_dragging_csr:
                    self.cursor_released.emit()

    def leaveEvent(self, event):
        """Hide the splice cut-line when the mouse leaves the widget."""
        if self._splice_x != -1:
            self._splice_x = -1
            self.update()
        super().leaveEvent(event)

    def wheelEvent(self, event):
        """Zoom around the pointer on Ctrl+scroll."""
        if is_ctrl(event.modifiers()):
            event.accept()
            delta = event.angleDelta().y()
            mx     = int(event.position().x())
            pivot  = self._x_to_frame(mx)
            factor = 1.15 if delta > 0 else 1.0 / 1.15
            self.zoom      = max(_MIN_ZOOM, min(_MAX_ZOOM, self.zoom * factor))
            self._scroll_x = (
                _LABEL_W + int((pivot - self._origin_frame) * self.zoom) - mx
            )
            self._update_size()
            self.viewport_changed.emit()
            self.update()
        else:
            event.ignore()
            super().wheelEvent(event)


    def dragEnterEvent(self, event):
        if event.mimeData().hasText() or event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        event.acceptProposedAction()

    def dropEvent(self, event):
        text = ''
        if event.mimeData().hasText():
            text = event.mimeData().text().strip()
        elif event.mimeData().hasUrls():
            text = event.mimeData().urls()[0].toLocalFile()
        if not text:
            event.ignore()
            return
        y         = event.pos().y()
        layer_idx = max(0, min(self._y_to_layer_idx(y), len(self.layers) - 1))
        self._try_add_by_name(text, layer_idx)
        event.acceptProposedAction()


    def enterEvent(self, event):
        """Take keyboard focus when the pointer arrives."""
        try:
            app = QtWidgets.QApplication.instance()
            focused = app.focusWidget() if app is not None else None
            if not isinstance(focused, (QtWidgets.QLineEdit,
                                        QtWidgets.QAbstractSpinBox,
                                        QtWidgets.QTextEdit)):
                self.setFocus(Qt.MouseFocusReason)
        except Exception as e:
            _log.note(f'timeline focus on hover: {e}', _log.WARN)
        super(TimelineWidget, self).enterEvent(event)

    def event(self, event):
        """Claim the panel's own keys before Qt picks a shortcut."""
        if (event.type() == QtCore.QEvent.ShortcutOverride
                and self._own_shortcut(event) is not None):
            event.accept()
            return True
        return super(TimelineWidget, self).event(event)

    def _own_shortcut(self, event):
        """The panel's shortcut on this timeline for this key, or None."""
        combo = (event.keyCombination() if hasattr(event, 'keyCombination')
                 else int(event.modifiers()) | event.key())
        seq = QtGui.QKeySequence(combo)
        for sc in self.children():
            if sc.metaObject().className() == 'QShortcut' and sc.key() == seq:
                return sc
        return None

    def keyPressEvent(self, event):
        """Handle the arrow keys, Escape and the panel's claimed shortcuts."""
        key = event.key()
        if key == Qt.Key_Left:
            self._step_frame(-1)
            event.accept()
        elif key == Qt.Key_Right:
            self._step_frame(1)
            event.accept()
        elif key == Qt.Key_Escape:
            if self._tool_mode in ('sel_left', 'sel_right'):
                self._do_sel_mode_exit()
                event.accept()
            else:
                event.ignore()
        else:
            sc = self._own_shortcut(event)
            if sc is not None:
                sc.activated.emit()
                event.accept()
            else:
                event.ignore()

    def _step_frame(self, delta):
        """Step the Nuke viewer by delta frames."""
        if not _nuke_ok():
            return
        try:
            import nuke
            nuke.frame(nuke.frame() + delta)
        except Exception as e:
            print(f'[SMTL] Step frame error: {e}')

    def _try_add_by_name(self, text, layer_idx):
        if not _nuke_ok():
            return
        try:
            import nuke
            node = nuke.toNode(text)
            if node is None:
                print(f'[SMTL] No node named "{text}" found in DAG')
                return
            if node.Class() != 'Read':
                print(f'[SMTL] "{text}" is a {node.Class()}, not a Read node')
                return
            self.add_read(node, layer_idx)
        except Exception as e:
            print(f'[SMTL] Drop error: {e}')


    def clip_under_cursor(self):
        """Return (layer_idx, clip) for the selected clip under the playhead, or None."""
        cur = self._cursor_frame
        for idx, layer in enumerate(self.layers):
            for c in layer.clips:
                if (c in self._selected_clips or c.selected) \
                        and c.first_frame <= cur <= c.last_frame:
                    return idx, c
        idx = self._add_idx
        if 0 <= idx < len(self.layers):
            for c in self.layers[idx].clips:
                if c.first_frame <= cur <= c.last_frame:
                    return idx, c
        return None

    def add_read(self, node, layer_idx=None, mode='overwrite',
                 at_frame=None, max_last=None, duration=None):
        """Add a Read node to a layer as a clip and return it."""
        if not self.layers:
            return
        if layer_idx is None:
            layer_idx = self._add_idx
        layer_idx = max(0, min(layer_idx, len(self.layers) - 1))

        if self._layer_blocked(self.layers[layer_idx]):
            reason = 'muted' if getattr(self.layers[layer_idx], 'hidden', False) else 'locked'
            print(f'[SMTL] Track "{self.layers[layer_idx].name}" is {reason} — skipping add')
            return

        name = node.name()
        label, src_first, src_last, is_still = _node_span(node)
        src_last, duration, full_first, full_last = resolve_add_span(
            src_first, src_last, is_still, duration)
        tl_start = self._cursor_frame if at_frame is None else int(at_frame)
        tl_end   = tl_start + duration - 1

        if max_last is not None:
            if tl_start > max_last:
                return None
            if tl_end > max_last:
                tl_end   = max_last
                src_last = src_first + (tl_end - tl_start)

        clip = SMTLClip(name, label, tl_start, tl_end,
                        src_first=src_first, src_last=src_last)
        clip.orig_src_first = full_first
        clip.orig_src_last  = full_last
        clip.offline = _check_clip_offline(clip)
        self.layers[layer_idx].clips.append(clip)
        self._resolve_collisions(layer_idx, [clip], mode=mode)
        self._cursor_frame = tl_end + 1
        self._update_size()
        self.update()
        print(f'[SMTL] Added {name} → {self.layers[layer_idx].name}  '
              f'tl={tl_start}-{tl_end}  src={src_first}-{src_last}')
        return clip

    def removal_target(self, prefer_range=False):
        """Return what a Lift or Extract will act on."""
        return removal_target(
            self.layers,
            selected     = self._selected_clips,
            sel_clip     = self._sel_clip,
            gap          = self._selected_gap,
            marks        = (self._mark_in, self._mark_out),
            prefer_range = prefer_range,
        )

    def selection(self):
        """Every selected clip, in layer and track order — the one answer."""
        out = [c for layer in self.layers for c in layer.clips
               if c in self._selected_clips or c.selected]
        if (not out and self._sel_clip is not None
                and any(self._sel_clip in layer.clips for layer in self.layers)):
            out = [self._sel_clip]
        return out

    def removal_layers(self):
        """Which layers a clip-driven removal would touch."""
        return removal_layers(self.layers, self._selected_clips, self._sel_clip)

    def has_marked_range(self):
        """Return True when both in and out marks are set."""
        return self._mark_in is not None and self._mark_out is not None

    def remove_selected_clip(self, extract=False, prefer_range=False):
        """Lift or extract the selection, gap or marked range; True if done."""
        target = self.removal_target(prefer_range=prefer_range)
        if target is None:
            return False

        if target == 'clips':
            per_layer = {}
            for idx in self.removal_layers():
                layer = self.layers[idx]
                per_layer[idx] = [c for c in layer.clips
                                  if c in self._selected_clips or c.selected]

            for idx, removed in per_layer.items():
                layer = self.layers[idx]
                layer.clips = [c for c in layer.clips if c not in removed]
                if extract:
                    close_gap(layer.clips, removed)

            self._clear_selection()
            self._update_size()
            self.update()
            self.clip_selected.emit(None)
            return True

        if target == 'gap':
            if not extract:
                return False
            idx, first, last = self._selected_gap
            if 0 <= idx < len(self.layers) and not self._layer_blocked(self.layers[idx]):
                close_span(self.layers[idx].clips, first, last)
            self._selected_gap = None
            self._update_size()
            self.update()
            self.clip_selected.emit(None)
            return True

        first = min(self._mark_in, self._mark_out)
        last  = max(self._mark_in, self._mark_out)
        targets = range_layers(self.layers, self._selected_clips,
                               self._sel_clip, self._add_idx)
        if not targets:
            return False

        if not any(c.first_frame <= last and c.last_frame >= first
                   for i in targets for c in self.layers[i].clips):
            return False

        for i in targets:
            clips = self.layers[i].clips
            clear_range(clips, first, last)
            if extract:
                close_span(clips, first, last)
        self._clear_selection()
        self._selected_gap = None
        self._update_size()
        self.update()
        self.clip_selected.emit(None)
        return True

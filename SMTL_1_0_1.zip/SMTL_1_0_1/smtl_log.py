"""In-memory log of panel status messages."""

import time as _time

INFO  = 'info'
WARN  = 'warn'
ERROR = 'error'

_RANK = {INFO: 0, WARN: 1, ERROR: 2}

_entries = []
_MAX = 500


def note(message, kind=INFO):
    """Add a line to the log and return the entry."""
    message = str(message).strip()
    if not message:
        return None
    if _entries and _entries[-1]['message'] == message and _entries[-1]['kind'] == kind:
        _entries[-1]['count'] += 1
        _entries[-1]['at'] = _time.time()
        return _entries[-1]
    entry = {'at': _time.time(), 'kind': kind, 'message': message, 'count': 1}
    _entries.append(entry)
    del _entries[:-_MAX]
    return entry


def entries(kind=None):
    """Return every entry, oldest first, or only those of one kind."""
    if kind is None:
        return list(_entries)
    return [e for e in _entries if e['kind'] == kind]


def worst():
    """Return the most serious kind present, or None when the log is empty."""
    if not _entries:
        return None
    return max((e['kind'] for e in _entries), key=lambda k: _RANK.get(k, 0))


def count(kind=None):
    """Return the number of entries, counting repeats."""
    return sum(e['count'] for e in entries(kind))


def clear():
    """Empty the log."""
    del _entries[:]


def as_text(clock=None):
    """Return the whole log as plain text."""
    fmt = clock or (lambda at: _time.strftime('%H:%M:%S', _time.localtime(at)))
    lines = []
    for e in _entries:
        tail = f'  (x{e["count"]})' if e['count'] > 1 else ''
        lines.append(f'{fmt(e["at"])}  {e["kind"]:<5}  {e["message"]}{tail}')
    return '\n'.join(lines)

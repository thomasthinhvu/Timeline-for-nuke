"""Write a timeline as an OTIO document."""

import json as _json
import re as _re

from smtl_constants import _NO_MEDIA, __version__
from smtl_models import timecode_to_frames


SCHEMA_TIMELINE   = 'Timeline.1'
SCHEMA_STACK      = 'Stack.1'
SCHEMA_TRACK      = 'Track.1'
SCHEMA_CLIP       = 'Clip.2'
SCHEMA_GAP        = 'Gap.1'
SCHEMA_TRANSITION = 'Transition.1'
SCHEMA_RATIONAL   = 'RationalTime.1'
SCHEMA_RANGE      = 'TimeRange.1'
SCHEMA_EXTERNAL   = 'ExternalReference.1'
SCHEMA_SEQUENCE   = 'ImageSequenceReference.1'
SCHEMA_FREEZE     = 'FreezeFrame.1'
SCHEMA_WARP       = 'LinearTimeWarp.1'

META_KEY = 'SMTL'


class MediaFacts(object):
    """What the caller found out about one clip's media."""

    __slots__ = ('path', 'start_tc', 'start_frame', 'rate', 'available',
                 'node', 'hold')

    def __init__(self, path='', start_tc='', start_frame=0, rate=0.0,
                 available=None, node='', hold=None):
        self.path        = str(path or '')
        self.start_tc    = str(start_tc or '')
        self.start_frame = int(start_frame or 0)
        self.rate        = float(rate or 0.0)
        self.available   = available
        self.node        = str(node or '')
        self.hold        = hold


def _stated_rate(rate):
    """Return a rate rounded to three decimals."""
    rate = float(rate or 0.0)
    return round(rate, 3)


def _rational(value, rate):
    return {'OTIO_SCHEMA': SCHEMA_RATIONAL,
            'rate': _stated_rate(rate), 'value': float(value)}


def _range(start, duration, rate):
    return {'OTIO_SCHEMA': SCHEMA_RANGE,
            'start_time': _rational(start, rate),
            'duration':   _rational(duration, rate)}


def _at_rate(frame, from_rate, to_rate):
    """Return a frame converted from one rate to another."""
    if not from_rate or not to_rate or abs(from_rate - to_rate) < 1e-6:
        return int(frame)
    return int(round(int(frame) * float(to_rate) / float(from_rate)))


def _gap(duration, rate):
    return {'OTIO_SCHEMA': SCHEMA_GAP, 'name': '', 'metadata': {},
            'effects': [], 'markers': [], 'enabled': True,
            'source_range': _range(0, duration, rate)}


def _transition(before, after, rate):
    """Return an OTIO dissolve dict from before and after offsets."""
    return {'OTIO_SCHEMA': SCHEMA_TRANSITION, 'name': '', 'metadata': {},
            'transition_type': 'SMPTE_Dissolve',
            'in_offset':  _rational(before, rate),
            'out_offset': _rational(after,  rate)}


def _src_rate(clip, facts):
    """The clip's own rate, or its media's when the clip was cut here."""
    return clip.src_rate or (facts.rate if facts is not None else 0.0)


def _rate_ratio(clip, rate, facts=None):
    """Return the part of a clip's speed due to the rate mismatch."""
    src_rate = _src_rate(clip, facts)
    if not src_rate or not rate or abs(src_rate - rate) < 1e-6:
        return 1.0
    return float(src_rate) / float(rate)


def _effects(clip, rate, facts=None):
    """Return the OTIO speed effects for a clip, if any."""
    speed = clip.speed / _rate_ratio(clip, rate, facts)
    if abs(speed - 1.0) < 1e-9:
        return []
    schema = SCHEMA_FREEZE if speed == 0 else SCHEMA_WARP
    return [{'OTIO_SCHEMA': schema, 'name': '', 'metadata': {},
             'effect_name': 'FreezeFrame' if speed == 0
                            else 'LinearTimeWarp',
             'time_scalar': float(speed)}]


def _media_clock(facts):
    """Return the offset from a Read frame to the media's own clock."""
    if facts is None:
        return None
    start = int(getattr(facts, 'start_frame', 0) or 0)
    tc    = str(getattr(facts, 'start_tc', '') or '')
    rate  = float(getattr(facts, 'rate', 0.0) or 0.0)
    at = 0
    if tc and rate > 0:
        try:
            at = int(timecode_to_frames(tc, rate, ';' in tc))
        except Exception:
            at = 0
    return at - start


def _on_clock(frame, clock):
    """Return a Read frame on the media's clock, unchanged when unknown."""
    return frame if clock is None else frame + clock


_PRINTF_RE = _re.compile(
    r'^(?P<base>.*)/(?P<prefix>[^/]*?)%(?:0(?P<pad>\d+))?d(?P<suffix>[^/]*)$')


def _media(clip, facts, rate, notes):
    """Return the OTIO media reference, or None where there is none."""
    if facts is not None and facts.path:
        avail = None
        if facts.available:
            clock = _media_clock(facts)
            first, last = facts.available
            avail = _range(_on_clock(first, clock), last - first + 1,
                           facts.rate or rate)
        seq = _PRINTF_RE.match(facts.path)
        if seq and facts.available:
            return {'DEFAULT_MEDIA': {
                'OTIO_SCHEMA': SCHEMA_SEQUENCE,
                'metadata': {}, 'name': clip.label or '',
                'available_range': avail,
                'available_image_bounds': None,
                'target_url_base': seq.group('base'),
                'name_prefix': seq.group('prefix'),
                'name_suffix': seq.group('suffix'),
                'start_frame': facts.available[0],
                'frame_step': 1,
                'rate': _stated_rate(facts.rate or rate),
                'frame_zero_padding': int(seq.group('pad') or 0),
                'missing_frame_policy': 'error',
            }}
        return {'DEFAULT_MEDIA': {
            'OTIO_SCHEMA': SCHEMA_EXTERNAL,
            'metadata': {}, 'name': clip.label or '',
            'available_range': avail,
            'available_image_bounds': None,
            'target_url': facts.path,
        }}
    if clip.node_name and clip.node_name != _NO_MEDIA:
        notes.append('%s is %r, which has no file — exported with no media '
                     'reference' % (clip.display_label, clip.node_name))
    else:
        notes.append('%s has no Read yet — exported with no media reference'
                     % clip.display_label)
    return None


def _clip(clip, facts, rate, notes):
    held = facts is not None and facts.hold is not None
    src  = facts.hold if held else clip.src_first
    out = {
        'OTIO_SCHEMA': SCHEMA_CLIP,
        'name': clip.display_label or '',
        'metadata': {},
        'source_range': _range(_at_rate(_on_clock(src,
                                                  _media_clock(facts)),
                                        _src_rate(clip, facts), rate),
                               clip.last_frame - clip.first_frame + 1,
                               rate),
        'effects': ([{'OTIO_SCHEMA': SCHEMA_FREEZE, 'name': '',
                      'metadata': {}, 'effect_name': 'FreezeFrame',
                      'time_scalar': 0.0}] if held
                    else _effects(clip, rate, facts)),
        'markers': [],
        'enabled': not clip.disabled,
    }
    refs = _media(clip, facts, rate, notes)
    if refs is not None:
        out['media_references'] = refs
        out['active_media_reference_key'] = 'DEFAULT_MEDIA'

    mine = {}
    node = (facts.node if facts is not None else '') or clip.node_name
    if node and node != _NO_MEDIA:
        mine['node'] = node
    if clip.src_reel:
        mine['reel'] = clip.src_reel
    if clip.src_tc:
        mine['source_timecode'] = clip.src_tc
    if mine:
        out['metadata'][META_KEY] = mine
    return out


def build(layers, first_frame, rate, media=None, name='', script=''):
    """Return (document, notes) for the whole timeline as OTIO."""
    media = media or {}
    notes = []
    tracks = []

    for layer in layers:
        children = []
        at = int(first_frame)
        for clip in sorted(layer.clips, key=lambda c: c.first_frame):
            if clip.first_frame > at:
                children.append(_gap(clip.first_frame - at, rate))
            head = next((t for t in layer.transitions
                         if t.at_frame == clip.first_frame), None)
            if head is not None:
                children.append(_transition(head.before, head.after, rate))
            children.append(_clip(clip, media.get(clip.clip_id), rate, notes))
            tail = next((t for t in layer.transitions
                         if t.at_frame == clip.last_frame + 1), None)
            if tail is not None and not any(c.first_frame == clip.last_frame + 1
                                            for c in layer.clips):
                children.append(_transition(tail.before, tail.after, rate))
            at = clip.last_frame + 1

        tracks.append({
            'OTIO_SCHEMA': SCHEMA_TRACK,
            'name': layer.name or '',
            'source_range': None, 'effects': [], 'markers': [],
            'enabled': not layer.hidden,
            'kind': 'Video',
            'children': children,
            'metadata': {META_KEY: {'locked': bool(layer.locked),
                                    'solo':   bool(layer.solo)}},
        })

    mine = {'version': __version__}
    if script:
        mine['script'] = script
    else:
        notes.append('the script has no name, so the export cannot say '
                     'where it came from')

    return ({
        'OTIO_SCHEMA': SCHEMA_TIMELINE,
        'name': str(name or ''),
        'metadata': {META_KEY: mine},
        'global_start_time': _rational(first_frame, rate),
        'tracks': {
            'OTIO_SCHEMA': SCHEMA_STACK,
            'name': '', 'metadata': {}, 'source_range': None,
            'effects': [], 'markers': [], 'enabled': True,
            'children': tracks,
        },
    }, notes)


def to_json(document, indent=4):
    """Return the document as indented JSON text."""
    return _json.dumps(document, indent=indent)

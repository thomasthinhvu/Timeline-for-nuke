"""Tooltip text for every panel widget, keyed by name."""

import smtl_log as _log


TIPS = {

    'overwrite': """
Add at the marks or playhead, over what's there. Ctrl: playhead.
""",
    'splice_in': """
Add at the marks or playhead and ripple. Ctrl: playhead.
""",
    'replace': """
Replace the clip's source with the selected node.
""",
    'lift': """
Remove, leaving a gap (Z). No selection: the marked range.
""",
    'extract': """
Remove and close the gap (X). No selection: the marked range.
""",

    'add_track': """
Add a track.
""",
    'remove_track': """
Remove the selected track.
""",

    '+_freeze': """
Freeze the frame at the playhead.
""",
    'retime': """
Set clip speed. Right-click: TimeWarp, OFlow or Kronos.
""",
    '+_dissolve': """
{shape}
Add a dissolve at the nearest cut. Shift-click for an S curve. Ctrl-click for options.
""",
    '+_s_dissolve': None,

    'edit': """
Select and move clips (Y).
""",
    'trim': """
Trim clip edges (U). Shift: ripple. Ctrl: dissolve. Alt: past the media.
""",
    'ripple': """
Trim and ripple the track.
""",
    'slide': """
Move clips along the track.
""",
    'slip': """
Move the picture inside the clip.
""",
    'splice': """
Cut a clip at the pointer.
""",
    'sel_l': """
Select all clips to the left of the click.
""",
    'sel_r': """
Select all clips to the right of the click.
""",
    'snap': """
Snap to cuts, marks and playhead.
""",
    'ui_freeze': """
Stop the timeline following playback.
""",

    '◀': """
Play backwards (J). Plays within the marks.
""",
    '▶': """
Play (L). Plays within the marks.
""",
    'spin_cursor': """
Playhead frame. Accepts +/- offsets and expressions.
""",
    'edit_rec_tc': """
Record timecode. Type to jump; +/- for an offset.
""",

    'spin_clip_frame': """
Source frame at the playhead.
""",
    'edit_src_tc': """
Source timecode at the playhead.
""",
    'tc': """
Show frames as timecode.
""",

    'spin_mark_in': """
Mark in (I). Shift+I clears, Alt+I ghosts.
""",
    'spin_mark_out': """
Mark out (O). Shift+O clears, Alt+O ghosts.
""",
    'spin_view_start': """
Visible range start.
""",
    'spin_view_end': """
Visible range end.
""",
    'spin_start': """
Project first frame.
""",
    'spin_end': """
Project last frame.
""",
    'fit': """
Fit the timeline, or the selection.
""",

    'combo_merge_op': """
Merge operation for the selected clips.
""",
    'spin_merge_mix': """
Mix for the selected clips.
""",

    'import': """
Import an edit onto the selected track.
""",
    'export': """
Export the timeline as OTIO.
""",
    'conform': """
Find and link media for unlinked clips.
""",
    'reconform': """
Restore the clip to its edit and find its media again.
""",

    'otioz_extract': """
Extract the OTIOZ media and conform to it.
""",
    'otioz_beside': """
Extract next to the OTIOZ.
""",
    'otioz_path': """
Extraction folder.
""",
    'otioz_reference': """
Also import the OTIOZ media as a locked track below.
""",

    'relink_viewer': """
Point the viewer at SMTL_Group.
""",
    'rebuild': """
Reload the timeline and rebuild SMTL_Group.
""",
    'reset': """
Delete all clips, tracks and SMTL_Group.
""",
    'refresh': """
Re-read the selected clips' sources. No selection: all.
""",
    'log': """
Status messages. Amber: unread warnings.
""",

    'label': """
Click to type. Middle-drag to adjust; Shift coarse, Alt fine.
""",
    'btn_dec': """
Decrease.
""",
    'btn_inc': """
Increase.
""",
    'orig': """
No file path in this edit. Search a folder and match on timecode.
""",
}

TIPS['+_s_dissolve'] = TIPS['+_dissolve']


def tip(key, **fields):
    """Return the tooltip for `key`, or '' with a log warning if there is none."""
    text = TIPS.get(key)
    if text is None:
        _log.note('[SMTL] no tooltip for %r — renamed, or never written?'
                  % (key,), _log.WARN)
        return ''
    text = text.strip()
    if fields:
        try:
            text = text.format(**fields)
        except (KeyError, IndexError, ValueError):
            pass
    return text


def apply(owner):
    """Set each widget on `owner` to the tooltip filed under its attribute name."""
    for name, widget in list(vars(owner).items()):
        if not name.startswith('_') or not hasattr(widget, 'setToolTip'):
            continue
        key = name.lstrip('_')
        text = TIPS.get(key)
        if text:
            widget.setToolTip(text.strip())

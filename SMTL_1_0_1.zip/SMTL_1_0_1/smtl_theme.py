"""Colours, metrics and QSS stylesheets for SMTL."""


WELL_BG            = '#1a1a1a'
PANEL_LOW_BG       = '#202020'
SURFACE_BG         = '#252525'
SURFACE_ALT_BG     = '#272727'
CHROME_BG          = '#2a2a2a'
ACTIVE_BG          = '#2e2e2e'
FIELD_BG           = '#333333'
LINE_SUBTLE        = FIELD_BG
LINE               = '#3a3a3a'


TEXT_HI            = '#ffffff'
TEXT_STRONG        = '#e0e0e0'
TEXT_BRIGHT        = '#cccccc'
TEXT               = '#aaaaaa'
TEXT_MUTED         = '#888888'
TEXT_DIM           = '#666666'
HINT_FG            = '#505050'
DISABLED_FG        = '#585858'


ACCENT_BG          = '#3a6a8a'
ACCENT_FG          = '#cce0f0'

FOCUS_FG           = '#6a9fd8'


VIEW_FG            = '#f0c040'
VIEW_FG_DIM        = DISABLED_FG
EDIT_FG            = '#50e050'
VIEW_ROW_BG        = ACTIVE_BG

NAME_FG            = TEXT_STRONG
NAME_FG_DIM        = TEXT_MUTED
INDICATOR_DIM      = LINE

SOLO_FG            = EDIT_FG
SOLO_FG_DIM        = '#404040'
HIDE_FG            = '#cc3333'
HIDE_FG_DIM        = SOLO_FG_DIM
LOCK_FG            = '#e08800'
LOCK_FG_DIM        = DISABLED_FG


LAYER_COLOURS = [
    '#3a7fa8',
    '#396d90',
    '#375c79',
    '#334d63',
]


ROW_BG_EVEN        = SURFACE_ALT_BG
ROW_BG_ODD         = SURFACE_BG
ROW_LOCKED_TINT    = (90, 50, 0, 30)
ROW_HIDDEN_TINT    = (0, 0, 0, 40)


RULER_BG           = WELL_BG
RULER_BASELINE_FG  = LINE
RULER_TICK_FG      = '#aaaaaa'

CURSOR_FG          = '#ff8800'
MIXED_FG            = '#8a8a8a'

LASSO_LINE          = '#88bbee'
LASSO_FILL          = '#88bbee'
LASSO_FILL_ALPHA    = 40
LASSO_DASH          = 4

SPLICE_FG           = '#ff8844'
SPLICE_CURSOR_FG    = TEXT_HI
SPLICE_CURSOR_BG    = WELL_BG

MARK_IN_FG         = '#40c060'
MARK_OUT_FG        = '#cc4444'
MARK_LINE_W        = 2
MARK_DIM_TINT      = (0, 0, 0, 100)

MARK_GHOST_FG      = TEXT_HI
MARK_GHOST_ALPHA   = 190
MARK_GHOST_HATCH_ALPHA = 120

CLIP_LABEL_FG      = TEXT_STRONG
CLIP_LABEL_SEL_FG  = TEXT_HI
CLIP_BRACKET_FG    = TEXT_HI
MATCH_EDIT_TAPE_BG = '#d8d2c4'
MATCH_EDIT_TAPE_FG = '#3a352c'
CLIP_STRIKE_FG     = TEXT
BEYOND_MEDIA_FG    = '#000000'
BEYOND_MEDIA_ALPHA = 170

TRANS_BG           = '#c8a13a'
TRANS_FG           = TEXT_HI
TRANS_SEL_BG       = '#e8c25a'

OPACITY_MUTED_ROW  = 0.35
OPACITY_DRAGGING   = 0.72
OPACITY_DISABLED   = 0.40
OPACITY_OFFLINE    = 0.85
OPACITY_LOCKED_ROW = 0.45
OPACITY_STRIKE     = 0.60
OPACITY_MATCH_TAPE = 0.50


TRANS_ALPHA        = 90
TRANS_SEL_ALPHA    = 130
TRANS_LINE_ALPHA   = 170
SLIP_GHOST_FG      = TEXT_HI
SLIP_GHOST_DIM     = '#8a8a8a'
CLIP_DISABLED_BG   = '#484848'
CLIP_DISABLED_FG   = TEXT_DIM
CLIP_OFFLINE_BG    = '#7a2020'
CLIP_OFFLINE_FG    = '#ffaaaa'
CLIP_OFFLINE_BADGE = '#ff5555'
MISSING_FRAMES_BG  = CLIP_OFFLINE_BADGE
MISSING_FRAMES_ALPHA = 210

CLIP_UNCONFORMED_BG = '#3f4348'
CLIP_UNCONFORMED_FG = '#9aa3ab'

CLIP_STALE_BG      = '#be8e1f'
CLIP_STALE_FG      = '#241b06'
CLIP_STALE_BADGE   = '#3d2e08'
ARRIVED_FRAMES_BG    = CLIP_STALE_BG
ARRIVED_FRAMES_ALPHA = 210
CLIP_MUTED_ROW_BG  = DISABLED_FG

CLIP_TINTS = [
    '#bb5858',
    '#9f6c41',
    '#827835',
    '#378737',
    '#368479',
    '#4d78b6',
    '#9360be',
    '#b85196',
]
CLIP_LABEL_DARK_FG = '#1c1c1c'

GAP_SELECTED_FG    = TEXT_HI
GAP_SELECTED_TINT  = (255, 255, 255, 28)


BTN_BG             = CLIP_DISABLED_BG
BTN_FG             = TEXT_BRIGHT
BTN_HOVER_BG       = DISABLED_FG
SEPARATOR_BG       = BTN_HOVER_BG
BTN_HOVER_FG       = BTN_FG
BTN_PRESSED_BG     = LINE
BTN_CHECKED_BG     = ACCENT_BG
BTN_CHECKED_FG     = ACCENT_FG

DANGER_BG          = HIDE_FG
DANGER_FG          = BTN_FG
DANGER_HOVER_BG    = '#e04444'
DANGER_PRESSED_BG  = '#a82828'

ATTENTION_BG       = '#8a6a1c'
ATTENTION_FG       = BTN_FG
ATTENTION_HOVER_BG = '#a8832a'
ATTENTION_PRESSED_BG = '#6b5216'

LINK_BG            = '#2f7d32'
LINK_FG            = BTN_FG
LINK_HOVER_BG      = '#3a9a3e'
LINK_PRESSED_BG    = '#245f27'

FIELD_CURSOR_FG    = '#ccaa44'
FIELD_CURSOR_LINE  = '#5a4a22'
FIELD_CLIP_FG      = '#7799bb'
FIELD_MARK_LINE    = LINE
FIELD_CLIP_LINE    = '#2a3a4a'

MENU_SEL_BG        = '#3a6fa8'
MENU_CHECKED_FG    = '#4fa0e0'


OFFLINE_CONST_RGBA = (0.071, 0.0, 0.0, 1.0)


def panel_style():
    """Return the global QSS for the SMTL panel widget."""
    return f"""
QWidget {{
    background-color: {CHROME_BG};
    color: {TEXT_BRIGHT};
    font-size:{PANEL_FONT_PX}px;
}}
QPushButton {{
    background-color: {BTN_BG};
    color: {BTN_FG};
    border: none;
    border-radius: 3px;
    padding: {BUTTON_PAD_V}px {BUTTON_PAD_H}px;
    font-size:{PANEL_FONT_PX}px;
}}
QPushButton:hover   {{ background-color: {BTN_HOVER_BG}; }}
QPushButton:pressed {{ background-color: {BTN_PRESSED_BG}; }}
QPushButton:disabled {{ color: {DISABLED_FG}; background-color: {BTN_PRESSED_BG}; }}
QToolButton:disabled {{ color: {DISABLED_FG}; background-color: {BTN_PRESSED_BG}; }}
QLabel {{ color: {TEXT}; }}
QScrollBar:horizontal {{
    background: {PANEL_LOW_BG};
    height: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {BTN_HOVER_BG};
    border-radius: 4px;
    min-width: 20px;
}}
QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal {{ width: 0; }}
QScrollBar:vertical {{
    background: {PANEL_LOW_BG};
    width: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical {{
    background: {BTN_HOVER_BG};
    border-radius: 4px;
    min-height: 20px;
}}
QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical {{ height: 0; }}
QFrame[frameShape="5"] {{ color: {LINE}; }}
"""


def push_button_style(variant='default'):
    """Return the QSS for a toolbar QPushButton in the given variant."""
    if variant == 'attention':
        return (
            f'QPushButton {{ background:{ATTENTION_BG}; color:{ATTENTION_FG};'
            f'    border:none; border-radius:3px; padding:{BUTTON_PAD_V}px {BUTTON_PAD_H}px;'
            f'    font-size:{PANEL_FONT_PX}px; }}'
            f'QPushButton:hover   {{ background:{ATTENTION_HOVER_BG}; }}'
            f'QPushButton:pressed {{ background:{ATTENTION_PRESSED_BG}; }}'
        )
    if variant == 'link':
        return (
            f'QPushButton {{ background:{LINK_BG}; color:{LINK_FG};'
            f'    border:none; border-radius:3px; padding:{BUTTON_PAD_V}px {BUTTON_PAD_H}px;'
            f'    font-size:{PANEL_FONT_PX}px; }}'
            f'QPushButton:hover   {{ background:{LINK_HOVER_BG}; }}'
            f'QPushButton:pressed {{ background:{LINK_PRESSED_BG}; }}'
        )
    if variant == 'danger':
        return (
            f'QPushButton {{ background:{DANGER_BG}; color:{DANGER_FG};'
            f'    border:none; border-radius:3px; padding:{BUTTON_PAD_V}px {BUTTON_PAD_H}px;'
            f'    font-size:{PANEL_FONT_PX}px; }}'
            f'QPushButton:hover   {{ background:{DANGER_HOVER_BG}; }}'
            f'QPushButton:pressed {{ background:{DANGER_PRESSED_BG}; }}'
        )
    return (
        f'QPushButton {{ background:{BTN_BG}; color:{BTN_FG};'
        f'    border:none; border-radius:3px; padding:{BUTTON_PAD_V}px {BUTTON_PAD_H}px;'
        f'    font-size:{PANEL_FONT_PX}px; }}'
        f'QPushButton:hover   {{ background:{BTN_HOVER_BG}; }}'
        f'QPushButton:pressed {{ background:{BTN_PRESSED_BG}; }}'
        f'QPushButton:disabled {{ background:{BTN_PRESSED_BG};'
        f'    color:{DISABLED_FG}; }}'
    )


def mode_button_style():
    """Return the QSS for the checkable tool-mode QToolButtons."""
    return (
        f'QToolButton {{ background:{BTN_BG}; border:none; border-radius:3px;'
        f'    padding:{BUTTON_PAD_V}px {BUTTON_PAD_H}px; font-size:{PANEL_FONT_PX}px; color:{BTN_FG}; }}'
        f'QToolButton:hover   {{ background:{BTN_HOVER_BG}; color:{BTN_HOVER_FG}; }}'
        f'QToolButton:pressed {{ background:{BTN_PRESSED_BG}; }}'
        f'QToolButton:checked {{ background:{BTN_CHECKED_BG}; color:{BTN_CHECKED_FG}; }}'
        f'QToolButton:disabled {{ background:{BTN_PRESSED_BG}; color:{DISABLED_FG}; }}'
        f'QToolButton:checked:disabled {{ background:{BTN_PRESSED_BG};'
        f'    color:{DISABLED_FG}; }}'
    )


def spin_style(variant='default'):
    """Return the QSS for a toolbar QSpinBox in the given variant."""
    if variant == 'mark_in':
        fg, line, focus_fg, focus_line = (
            MARK_IN_FG, FIELD_MARK_LINE, MARK_IN_FG, MARK_IN_FG)
        extra = ' font-weight:bold;'
    elif variant == 'mark_out':
        fg, line, focus_fg, focus_line = (
            MARK_OUT_FG, FIELD_MARK_LINE, MARK_OUT_FG, MARK_OUT_FG)
        extra = ' font-weight:bold;'
    elif variant == 'cursor':
        fg, line, focus_fg, focus_line = (
            FIELD_CURSOR_FG, FIELD_CURSOR_LINE, '#ffcc55', '#aa8833')
        extra = ' font-weight:bold;'
    elif variant == 'clip':
        fg, line, focus_fg, focus_line = (
            FIELD_CLIP_FG, FIELD_CLIP_LINE, FIELD_CLIP_FG, FIELD_CLIP_LINE)
        extra = ' font-weight:bold;'
    elif variant == 'view':
        fg, line, focus_fg, focus_line = (
            DISABLED_FG, CHROME_BG, TEXT_MUTED, DISABLED_FG)
        extra = ''
    else:
        fg, line, focus_fg, focus_line = (
            TEXT_MUTED, LINE, TEXT_BRIGHT, TEXT_DIM)
        extra = ''
    return (
        f'QSpinBox {{ background:{WELL_BG}; color:{fg}; border:1px solid {line};'
        f'           border-radius:2px; padding:0 4px; font-size:{PANEL_FONT_PX}px;{extra} }}'
        f'QSpinBox:focus {{ border-color:{focus_line}; color:{focus_fg}; }}'
        f'QSpinBox:disabled {{ color:{DISABLED_FG}; border-color:{PANEL_LOW_BG}; }}'
        f'QSpinBox::up-button, QSpinBox::down-button {{ width:0; }}'
    )


LOG_BG             = '#000000'
LOG_INFO_FG        = '#33dd55'
LOG_WARN_FG        = '#ffb000'
LOG_ERROR_FG       = '#ff4438'
LOG_TIME_FG        = '#557755'


def log_kind_fg(kind):
    """Return the colour for a log line of the given kind."""
    return {'warn': LOG_WARN_FG, 'error': LOG_ERROR_FG}.get(kind, LOG_INFO_FG)


def line_edit_style(variant='clip'):
    """Return the QSS for a read-only timecode QLineEdit."""
    if variant == 'cursor':
        fg, line = FIELD_CURSOR_FG, FIELD_CURSOR_LINE
    else:
        fg, line = FIELD_CLIP_FG, FIELD_CLIP_LINE
    return (
        f'QLineEdit {{ background:{WELL_BG}; color:{fg}; border:1px solid {line};'
        f'            border-radius:2px; padding:0 4px; font-size:{PANEL_FONT_PX}px;'
        f'            font-weight:bold; }}'
        f'QLineEdit:disabled {{ color:{DISABLED_FG}; border-color:{PANEL_LOW_BG}; }}'
    )


def log_window_style():
    """Return the QSS for the log window."""
    return (
        f'QDialog {{ background:{CHROME_BG}; }}'
        f'QPlainTextEdit {{ background:{LOG_BG}; color:{LOG_INFO_FG};'
        f'    border:1px solid {LINE};'
        f'    font-family:"Menlo","DejaVu Sans Mono",monospace; font-size:{PANEL_FONT_PX}px; }}'
        f'QLabel {{ color:{TEXT_DIM}; font-size:{PANEL_FONT_PX}px; }}'
        f'QRadioButton {{ color:{TEXT_MUTED}; font-size:{PANEL_FONT_PX}px; }}'
        f'QRadioButton:checked {{ color:{TEXT_BRIGHT}; }}'
    )


def toolbar_label_style():
    """Return the QSS for the S: / E: toolbar labels."""
    return f'color:{TEXT_DIM}; font-size:{PANEL_FONT_PX}px;'


def status_style():
    """Return the QSS for the status bar."""
    return (f'color:{TEXT_DIM}; font-size:14px; padding:2px 4px;'
            f'qproperty-alignment: AlignCenter;')


def credit_style():
    """Return the QSS for the credit line."""
    return (f'QLabel {{ color:{TEXT_DIM}; font-size:{PANEL_FONT_PX}px; padding:2px 4px; }}'
            f'QLabel:hover {{ color:{TEXT}; }}')


def credit_markup(text, url):
    """Return the credit as rich text with the URL as a link."""
    shown = url.split('://', 1)[-1].rstrip('/')
    return (f'<span style="color:{TEXT_DIM};">{text} &middot; '
            f'<a href="{url}" style="color:{TEXT_DIM};">{shown}</a></span>')


def scroll_area_style():
    """Return the QSS for the timeline scroll area."""
    return f'QScrollArea {{ background:{SURFACE_BG}; }}'


def merge_bar_style():
    """Return the QSS for the merge bar row."""
    return (
        f'QLabel           {{ color:{TEXT_MUTED}; font-size:{PANEL_FONT_PX}px; }}'
        f'QLabel:disabled  {{ color:{DISABLED_FG}; }}'
        f'QComboBox {{ background:{FIELD_BG}; color:{TEXT_BRIGHT};'
        f'    border:1px solid {BTN_BG}; border-radius:3px;'
        f'    padding:2px 4px; font-size:{PANEL_FONT_PX}px; }}'
        f'QComboBox:disabled {{ background:{PANEL_LOW_BG}; color:{DISABLED_FG};'
        f'    border:1px solid {ACTIVE_BG}; }}'
    )


def layer_colour(idx):
    """Return the bar colour for layer `idx`."""
    return LAYER_COLOURS[idx % len(LAYER_COLOURS)]


_READABLE_FG_CACHE = {}


def readable_fg(bg):
    """Return a label colour readable on background `bg`."""
    bg = (bg or '').strip()
    key = bg
    hit = _READABLE_FG_CACHE.get(key)
    if hit is not None:
        return hit
    if not bg.startswith('#') or len(bg) not in (4, 7):
        return CLIP_LABEL_FG
    if len(bg) == 4:
        bg = '#' + ''.join(ch * 2 for ch in bg[1:])
    try:
        rgb = [int(bg[i:i + 2], 16) for i in (1, 3, 5)]
    except ValueError:
        return CLIP_LABEL_FG

    def _linear(v):
        v /= 255.0
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4

    r, g, b = (_linear(v) for v in rgb)
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    lstar = 116 * (y ** (1.0 / 3.0)) - 16 if y > 0.008856 else 903.3 * y
    out = CLIP_LABEL_DARK_FG if lstar > 56.0 else CLIP_LABEL_FG
    _READABLE_FG_CACHE[key] = out
    return out


def menu_style():
    """Return the QSS for the layer context menu."""
    return (
        f'QMenu {{ background:{CHROME_BG}; border:1px solid {BTN_BG};'
        f'    color:{TEXT_BRIGHT}; font-size:{PANEL_FONT_PX}px; }}'
        f'QMenu::item {{ padding:5px 20px 5px 10px; }}'
        f'QMenu::item:selected {{ background:{MENU_SEL_BG}; }}'
        f'QMenu::item:checked  {{ color:{MENU_CHECKED_FG}; }}'
        f'QMenu::item:disabled {{ color:{DISABLED_FG}; }}'
        f'QMenu::item:checked:disabled {{ color:{DISABLED_FG}; }}'
        f'QMenu::separator {{ height:1px; background:{BTN_BG}; margin:3px 0; }}'
    )


def combo_mixed_style(mixed):
    """Return the QSS for the merge Operation combo, greyed when mixed."""
    fg = MIXED_FG if mixed else TEXT_BRIGHT
    return f'QComboBox {{ color:{fg}; }}'


def drag_widget_style(part='label'):
    """Return the QSS for a part of DragDoubleWidget."""
    if part == 'mixed':
        return (
            f'QLabel {{ background:{FIELD_BG}; color:{MIXED_FG};'
            f'    border:1px solid {BTN_BG}; border-radius:3px;'
            f'    padding:2px 6px; font-size:{PANEL_FONT_PX}px; }}'
        )
    if part == 'arrow':
        return (
            f'QToolButton {{ background:{LINE}; color:{TEXT}; border:none;'
            f'    border-radius:2px; font-size:9px; padding:0; }}'
            f'QToolButton:hover   {{ background:{BTN_HOVER_BG}; color:{TEXT_HI}; }}'
            f'QToolButton:pressed {{ background:{CHROME_BG}; }}'
        )
    if part == 'edit':
        return (
            f'QLineEdit {{ background:{WELL_BG}; color:{FIELD_CURSOR_FG};'
            f'    border:1px solid {FIELD_CURSOR_LINE}; border-radius:3px;'
            f'    padding:2px 6px; font-size:{PANEL_FONT_PX}px;'
            f'    font-weight:bold; }}'
            f'QLineEdit:focus {{ border-color:{FIELD_CURSOR_FG}; }}'
        )
    if part == 'active':
        return (
            f'QLabel {{ background:{LINE}; color:{TEXT_HI};'
            f'    border:1px solid {FOCUS_FG}; border-radius:3px;'
            f'    padding:2px 6px; font-size:{PANEL_FONT_PX}px; }}'
        )
    return (
        f'QLabel {{ background:{FIELD_BG}; color:{TEXT_BRIGHT};'
        f'    border:1px solid {BTN_BG}; border-radius:3px;'
        f'    padding:2px 6px; font-size:{PANEL_FONT_PX}px; }}'
    )


def vline_style():
    """Return the QSS for the toolbar vertical separators."""
    return f'background:{SEPARATOR_BG}; border:none;'


PANEL_FONT_PX      = 12

BUTTON_PAD_V       = 4
BUTTON_PAD_H       = 10

BUTTON_ICON_MARGIN = 1

BUTTON_ICON_SIDE_PAD = 4

BUTTON_ICON_DISABLED = 0.45

DIALOG_FONT_PX     = PANEL_FONT_PX

INDICATOR_LINE     = '#808080'
INDICATOR_MARK     = '#99a8b4'
INDICATOR_HOVER    = '#999999'


def _tick_url():
    """Return the path to the checkbox tick SVG, writing it if needed."""
    global _TICK_PATH
    if _TICK_PATH is None:
        import os as _os
        import tempfile as _tempfile
        path = _os.path.join(_tempfile.gettempdir(), 'smtl_tick.svg')
        try:
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(
                    '<svg xmlns="http://www.w3.org/2000/svg" '
                    'width="11" height="11" viewBox="0 0 11 11">'
                    '<path d="M2 5.6 L4.3 8 L9 2.6" fill="none" '
                    'stroke="%s" stroke-width="2" stroke-linecap="round" '
                    'stroke-linejoin="round"/></svg>' % INDICATOR_MARK)
            _TICK_PATH = path.replace('\\', '/')
        except Exception:
            _TICK_PATH = ''
    return _TICK_PATH


_TICK_PATH = None


def dialog_style():
    """Return the QSS for a modal dialogue."""
    size = f'{DIALOG_FONT_PX}px'
    tick = _tick_url()
    return f"""
QWidget {{
    background-color: {CHROME_BG};
    color: {TEXT_BRIGHT};
    font-size: {size};
}}
QLabel {{ color: {TEXT}; }}
QRadioButton {{ font-size: {size}; padding: 2px 0; }}
QRadioButton::indicator, QCheckBox::indicator {{
    width: 11px; height: 11px;
    border: 1px solid {INDICATOR_LINE};
    background-color: {WELL_BG};
}}
QRadioButton::indicator {{ border-radius: 6px; }}
QCheckBox::indicator  {{ border-radius: 2px; }}
QRadioButton::indicator:hover, QCheckBox::indicator:hover {{
    border: 1px solid {INDICATOR_HOVER}; }}
QRadioButton::indicator:checked {{
    background-color: {INDICATOR_MARK};
    border: 1px solid {INDICATOR_LINE};
}}
QCheckBox::indicator:checked {{
    image: url("{tick}");
    background-color: {WELL_BG};
    border: 1px solid {INDICATOR_LINE};
}}
QRadioButton::indicator:disabled, QCheckBox::indicator:disabled {{
    border: 1px solid {LINE};
    background-color: {PANEL_LOW_BG};
}}
QRadioButton::indicator:checked:disabled {{
    background-color: {DISABLED_FG};
    border: 1px solid {DISABLED_FG};
}}
QCheckBox::indicator:checked:disabled {{
    image: url("{tick}");
    background-color: {PANEL_LOW_BG};
    border: 1px solid {LINE};
}}
QHeaderView::section {{
    background-color: {PANEL_LOW_BG};
    color: {TEXT};
    font-weight: bold;
    border: none;
    border-right: 1px solid {LINE};
    padding: 2px 6px;
}}
QTableWidget {{
    background-color: {SURFACE_BG};
    border: 1px solid {LINE};
    gridline-color: {LINE};
}}
QCheckBox:disabled, QRadioButton:disabled,
QLabel:disabled, QComboBox:disabled,
QLineEdit:disabled, QAbstractSpinBox:disabled {{ color: {DISABLED_FG}; }}
QComboBox:disabled, QLineEdit:disabled, QAbstractSpinBox:disabled {{
    background-color: {WELL_BG};
    border: 1px solid {LINE_SUBTLE};
}}
QPushButton:disabled {{ background-color: {BTN_PRESSED_BG};
                        color: {DISABLED_FG}; }}
QPushButton {{
    background-color: {BTN_BG};
    color: {BTN_FG};
    border: none;
    border-radius: 3px;
    padding: 5px 14px;
    font-size: {size};
}}
QPushButton:hover   {{ background-color: {BTN_HOVER_BG}; }}
QPushButton:pressed {{ background-color: {BTN_PRESSED_BG}; }}
QComboBox, QLineEdit, QAbstractSpinBox {{
    background-color: {FIELD_BG};
    color: {TEXT_BRIGHT};
    border: 1px solid {LINE};
    border-radius: 3px;
    padding: 3px 6px;
    font-size: {size};
}}
QComboBox QAbstractItemView {{
    background-color: {FIELD_BG};
    color: {TEXT_BRIGHT};
    selection-background-color: {ACCENT_BG};
    selection-color: {ACCENT_FG};
}}
"""


def dialog_error_style():
    """Return the QSS for a dialogue's validation error line."""
    return f'color:{LOG_ERROR_FG}; font-size:{DIALOG_FONT_PX}px;'

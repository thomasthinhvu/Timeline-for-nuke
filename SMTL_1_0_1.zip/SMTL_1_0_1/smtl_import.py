"""Build SMTL clips from a parsed cut."""

import os as _os

from smtl_constants import _NO_MEDIA
from smtl_models import (
    SMTLClip, SMTLTransition, fit_dissolve, RETIME_TIMEWARP,
)
import smtl_parse as _parse


class ImportResult(object):
    """Clips, transitions and notes produced by an import."""

    __slots__ = ('clips', 'transitions', 'offset', 'notes', 'ignored',
                 'rate', 'first_frame', 'last_frame')

    def __init__(self):
        self.clips        = []
        self.transitions  = []
        self.offset       = 0
        self.notes        = []
        self.ignored      = {}
        self.rate         = 24.0
        self.first_frame  = 0
        self.last_frame   = 0

    def __repr__(self):
        return ('ImportResult(%d clips, %d transitions, %d-%d)'
                % (len(self.clips), len(self.transitions),
                   self.first_frame, self.last_frame))


class BundleChoice(object):
    __slots__ = ('extract', 'beside', 'where', 'reference')

    def __init__(self, extract=False, beside=False, where='',
                 reference=False):
        self.extract   = bool(extract)
        self.beside    = bool(beside)
        self.where     = str(where or '')
        self.reference = bool(reference) and self.extract

    def folder(self, bundle_path):
        """Return the folder for extracted media, or None when none is wanted."""
        if not self.extract:
            return None
        room = (_os.path.dirname(_os.path.abspath(bundle_path))
                if self.beside or not self.where
                else _os.path.abspath(_os.path.expanduser(self.where)))
        stem = _os.path.splitext(_os.path.basename(bundle_path))[0]
        return _os.path.join(room, stem) if stem else room


BUNDLE_NONE = BundleChoice()


def point_at_extracted(clips, extracted):
    """Repoint clips' relative bundle paths at the extracted files."""
    by_name = {_os.path.basename(k): v for k, v in (extracted or {}).items()}
    for clip in clips:
        landed = by_name.get(_os.path.basename(clip.src_path or ''))
        if landed:
            clip.src_path = landed


def build_clips(cut, first_frame, track_id=None):
    """Build the picture of a cut as placeholder clips landing at first_frame."""
    out = ImportResult()
    out.rate    = cut.rate
    out.ignored = dict(cut.ignored)
    out.notes.extend(cut.notes)

    anchor = cut.start()
    if anchor is None:
        out.notes.append('nothing in the file to import')
        return out
    out.offset = int(first_frame) - anchor

    events = [e for e in cut.events if e.kind == _parse.VIDEO]
    if track_id is not None:
        events = [e for e in events if e.track_id == track_id]
    if not events:
        out.notes.append('no picture events — nothing to build')
        return out

    events = sorted(events, key=lambda e: (e.rec_first, e.rec_last))


    for ev in events:
        clip = SMTLClip(
            node_name   = _NO_MEDIA,
            label       = _label_for(ev),
            first_frame = ev.rec_first + out.offset,
            last_frame  = ev.rec_last  + out.offset,
            src_first   = ev.src_first,
            src_last    = ev.src_last,
        )
        clip.speed = ev.speed
        if clip.speed != 1.0:
            clip.retime_node = RETIME_TIMEWARP
        clip.src_reel     = ev.reel
        clip.src_name     = ev.source_name or ev.name
        clip.src_path     = ev.path
        clip.src_tc       = ev.src_tc
        clip.src_frame    = ev.src_frame
        clip.src_rate     = ev.src_rate
        out.clips.append(clip)

    for ev, clip in zip(events, out.clips):
        for tr, at_frame in ((ev.transition, clip.first_frame),
                             (ev.tail_transition, clip.last_frame + 1)):
            _place_transition(out, tr, ev, clip, at_frame)

    out.first_frame = min(c.first_frame for c in out.clips)
    out.last_frame  = max(c.last_frame  for c in out.clips)

    n_audio = out.ignored.get('audio', 0)
    if n_audio:
        out.notes.append('%d audio event%s read and not built — SMTL has no '
                         'audio' % (n_audio, '' if n_audio == 1 else 's'))
    return out


def _place_transition(out, tr, ev, clip, at_frame):
    """Add one transition to the result, or report that it does not fit."""
    if tr is None:
        return
    if tr.kind != 'dissolve':
        out.notes.append(
            'event %s: %s is not a dissolve — SMTL has one transition, so '
            'it was left off' % (ev.number, tr.kind))
        return
    grant_handle(out.clips, at_frame, tr.before, tr.after, out.notes)
    before, after, _why = fit_dissolve(out.clips, at_frame, tr.before,
                                       tr.after, out.transitions)
    if (before, after) != (tr.before, tr.after):
        out.notes.append(
            'event %s: dissolve %d/%d did not fit and became %d/%d'
            % (ev.number, tr.before, tr.after, before, after))
    if before or after:
        out.transitions.append(SMTLTransition(at_frame, before, after))


def grant_handle(clips, at_frame, before, after, notes):
    """Extend clip handles either side of a dissolve so it can be spent."""
    inc = next((c for c in clips if c.first_frame == at_frame), None)
    out = next((c for c in clips if c.last_frame == at_frame - 1), None)
    if out is not None and after > 0:
        room = out.orig_src_last - out.src_last
        if room < after:
            out.orig_src_last += (after - room)
            notes.append(
                'granted %d frame%s of tail handle to %r so the dissolve at '
                '%d can be spent — the file asked for it, so the media is '
                'assumed to run on'
                % (after - room, '' if after - room == 1 else 's',
                   out.label[:40], at_frame))
    if inc is not None and before > 0:
        room = inc.src_first - inc.orig_src_first
        if room < before:
            inc.orig_src_first -= (before - room)
            notes.append(
                'granted %d frame%s of head handle to %r so the dissolve at '
                '%d can be spent'
                % (before - room, '' if before - room == 1 else 's',
                   inc.label[:40], at_frame))


def _label_for(event):
    """Return the bar label for a clip with no node."""
    if event.name:
        return event.name
    reel = (event.reel or '').strip()
    if reel.upper() not in _parse.NULL_REELS:
        return reel
    return 'Event %s' % event.number


def build_tracks(cut, first_frame):
    """Return one import result per declared track, or one for the whole cut."""
    if not cut.tracks:
        return [(None, build_clips(cut, first_frame))]
    out = []
    for track in cut.tracks:
        res = build_clips(cut, first_frame, track_id=track['id'])
        if res.clips:
            out.append((track, res))
    return out

"""Reusable Qt widgets and dialogs for the SMTL panel."""

import os
import re as _re
import sys as _sys

_SMTL_DIR = os.path.dirname(os.path.abspath(__file__))
if _SMTL_DIR not in _sys.path:
    _sys.path.insert(0, _SMTL_DIR)

import smtl_theme as _theme
import smtl_tips as _tips
from smtl_constants import (_DLG_MARGIN, _DLG_SPACING, _DLG_GROUP_GAP,
                            _DLG_INDENT, _DLG_FIELD_W, _DLG_FIELD_H)
from smtl_models import (parse_start_entry, frames_to_timecode,
                         timecode_to_frames,
                         is_drop_frame_rate)

try:
    from PySide6 import QtWidgets, QtCore, QtGui
    from PySide6.QtCore import Qt
except ImportError:
    from PySide2 import QtWidgets, QtCore, QtGui
    from PySide2.QtCore import Qt


_SELECT_REASONS = (Qt.MouseFocusReason, Qt.TabFocusReason,
                   Qt.BacktabFocusReason, Qt.ShortcutFocusReason)


def arrived_at_field(event):
    """Return True when a focus-in event means the user came to type here."""
    return event.reason() in _SELECT_REASONS


class ExprSpinBox(QtWidgets.QSpinBox):
    """QSpinBox that evaluates arithmetic expressions on commit."""

    _ALLOWED  = _re.compile(r'^[\d\s\+\-\*\/\(%\)]*$')
    _RELATIVE = _re.compile(r'^([+-])\s*(\d+)$')

    def __init__(self, parent=None):
        super().__init__(parent)
        self._select_armed = False
        self.lineEdit().installEventFilter(self)

    def focusInEvent(self, event):
        """Select the value when the user arrives at the field."""
        super().focusInEvent(event)
        self._select_armed = arrived_at_field(event)
        if self._select_armed:
            self.lineEdit().selectAll()

    def eventFilter(self, obj, event):
        """Reselect the value on the line edit's first mouse release."""
        if (self._select_armed
                and event.type() == QtCore.QEvent.MouseButtonRelease
                and obj is self.lineEdit()):
            self._select_armed = False
            self.lineEdit().selectAll()
        return super().eventFilter(obj, event)

    def mouseReleaseEvent(self, event):
        """Reselect the value on the first release in the spin box margin."""
        super().mouseReleaseEvent(event)
        if self._select_armed:
            self._select_armed = False
            self.lineEdit().selectAll()

    def focusOutEvent(self, event):
        self._select_armed = False
        super().focusOutEvent(event)

    def validate(self, text: str, pos: int):
        """Accept expression characters; reject everything else."""
        if not text or self._ALLOWED.match(text):
            return (QtGui.QValidator.Acceptable, text, pos)
        return (QtGui.QValidator.Invalid, text, pos)

    def valueFromText(self, text: str) -> int:
        """Evaluate expression and return int, clamped to spinbox range."""
        s = text.strip()
        if not s:
            return self.value()
        try:
            m = self._RELATIVE.match(s)
            if m:
                offset = int(m.group(1) + m.group(2))
                raw = self.value() + offset
            else:
                raw = int(round(float(eval(s, {'__builtins__': {}}, {}))))
            return max(self.minimum(), min(self.maximum(), raw))
        except Exception:
            return self.value()

    def textFromValue(self, value: int) -> str:
        return str(value)


class DragDoubleWidget(QtWidgets.QWidget):
    """Compact numeric field with middle-drag, step buttons and click-to-edit."""

    value_changed = QtCore.Signal(float)

    _STEP_NORMAL = 0.005
    _STEP_COARSE = 0.05
    _STEP_FINE   = 0.001

    def __init__(self, value=1.0, min_val=0.0, max_val=1.0, decimals=2, parent=None):
        super().__init__(parent)
        self._value    = max(float(min_val), min(float(max_val), float(value)))
        self._min      = float(min_val)
        self._max      = float(max_val)
        self._decimals = decimals
        self._drag_active  = False
        self._drag_start_x = 0
        self._drag_start_v = 0.0
        self._editing      = False
        self._mixed        = False

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._label = QtWidgets.QLabel(self._fmt())
        self._label.setAlignment(Qt.AlignCenter)
        self._label.setStyleSheet(_theme.drag_widget_style('label'))
        self._label.setToolTip(_tips.tip('label'))

        _arrow_style = _theme.drag_widget_style('arrow')

        self._btn_dec = QtWidgets.QToolButton()
        self._btn_dec.setText('◀')
        self._btn_dec.setFixedSize(14, 24)
        self._btn_dec.setStyleSheet(_arrow_style)
        self._btn_dec.setToolTip(_tips.tip('btn_dec'))
        self._btn_dec.setAutoRepeat(True)
        self._btn_dec.setAutoRepeatDelay(400)
        self._btn_dec.setAutoRepeatInterval(80)
        self._btn_dec.clicked.connect(self._step_dec)

        self._btn_inc = QtWidgets.QToolButton()
        self._btn_inc.setText('▶')
        self._btn_inc.setFixedSize(14, 24)
        self._btn_inc.setStyleSheet(_arrow_style)
        self._btn_inc.setToolTip(_tips.tip('btn_inc'))
        self._btn_inc.setAutoRepeat(True)
        self._btn_inc.setAutoRepeatDelay(400)
        self._btn_inc.setAutoRepeatInterval(80)
        self._btn_inc.clicked.connect(self._step_inc)

        layout.addWidget(self._btn_dec)
        layout.addWidget(self._label)

        self._edit = QtWidgets.QLineEdit(self._fmt())
        self._edit.setAlignment(Qt.AlignCenter)
        self._edit.setStyleSheet(_theme.drag_widget_style('edit'))
        self._edit.hide()
        self._edit.editingFinished.connect(self._commit_edit)
        self._edit.installEventFilter(self)
        layout.addWidget(self._edit)
        layout.addWidget(self._btn_inc)

        self.setFixedHeight(24)
        widest = max(text_width(self._label, self._fmt_of(-0.0 - 8.0 / 9),
                                _DRAG_FIELD_CHROME),
                     text_width(self._label, '—', _DRAG_FIELD_CHROME))
        for part in (self._label, self._edit):
            part.setFixedWidth(widest)
        self.setFixedWidth(max(_DRAG_MIN_W,
                               widest + self._btn_dec.width()
                               + self._btn_inc.width()))


    def value(self):
        return self._value

    def setValue(self, v):
        clamped = max(self._min, min(self._max, float(v)))
        was_mixed = self._mixed
        self._mixed = False
        if clamped == self._value and not was_mixed:
            return
        self._value = clamped
        if not self._drag_active:
            self._label.setStyleSheet(_theme.drag_widget_style('label'))
        self._label.setText(self._fmt())
        if not self._editing:
            self._edit.setText(self._fmt())

    def setMixed(self):
        """Show a dash to mark disagreeing values."""
        self._mixed = True
        self._label.setStyleSheet(_theme.drag_widget_style('mixed'))
        self._label.setText('—')


    def _fmt(self):
        return self._fmt_of(self._value)

    def _fmt_of(self, value):
        """Return a value formatted to the widget's decimals."""
        return f'{value:.{self._decimals}f}'

    def _start_edit(self):
        """Swap the label for the edit field and select its text."""
        self._editing = True
        self._edit.setText(self._fmt())
        self._label.hide()
        self._edit.show()
        self._edit.setFocus()
        self._edit.selectAll()

    def _end_edit(self):
        """Hide the edit field and show the label."""
        self._editing = False
        self._edit.hide()
        self._label.show()

    def _commit_edit(self):
        if not self._editing:
            return
        try:
            v   = float(self._edit.text())
            old = self._value
            self.setValue(v)
            if self._value != old:
                self.value_changed.emit(self._value)
        except ValueError:
            pass
        self._end_edit()


    def _step_dec(self):
        old, was_mixed = self._value, self._mixed
        self.setValue(self._value - self._STEP_NORMAL)
        if self._value != old or was_mixed:
            self.value_changed.emit(self._value)

    def _step_inc(self):
        old, was_mixed = self._value, self._mixed
        self.setValue(self._value + self._STEP_NORMAL)
        if self._value != old or was_mixed:
            self.value_changed.emit(self._value)


    def mousePressEvent(self, event):
        if event.button() == Qt.MiddleButton:
            self._drag_active  = True
            self._drag_start_x = event.pos().x()
            self._drag_start_v = self._value
            self.setCursor(Qt.SizeHorCursor)
            self._label.setStyleSheet(_theme.drag_widget_style('active'))
            event.accept()
        elif event.button() == Qt.LeftButton:
            if not self._editing:
                self._start_edit()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_active and (event.buttons() & Qt.MiddleButton):
            dx   = event.pos().x() - self._drag_start_x
            mods = event.modifiers()
            if mods & Qt.ShiftModifier:
                step = self._STEP_COARSE
            elif mods & Qt.AltModifier:
                step = self._STEP_FINE
            else:
                step = self._STEP_NORMAL
            old, was_mixed = self._value, self._mixed
            self.setValue(self._drag_start_v + dx * step)
            if self._value != old or was_mixed:
                self.value_changed.emit(self._value)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MiddleButton:
            self._drag_active = False
            self.setCursor(Qt.ArrowCursor)
            self._label.setStyleSheet(_theme.drag_widget_style('label'))
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def eventFilter(self, obj, event):
        if obj is self._edit and event.type() == QtCore.QEvent.KeyPress:
            if event.key() == Qt.Key_Escape:
                self._editing = False
                self._end_edit()
                return True
        return super().eventFilter(obj, event)


class PlainDoubleSpinBox(QtWidgets.QDoubleSpinBox):
    """Double spin box that hides trailing zeros."""

    def textFromValue(self, value):
        text = '%.*f' % (self.decimals(), value)
        if '.' in text:
            text = text.rstrip('0').rstrip('.')
        return text or '0'


class StickyMenu(QtWidgets.QMenu):
    """QMenu whose checkable items do not close it."""

    def mouseReleaseEvent(self, event):
        act = self.activeAction()
        if act is not None and act.isEnabled() and act.isCheckable():
            act.trigger()
            return
        super(StickyMenu, self).mouseReleaseEvent(event)


def _vline():
    """Return a vertical separator line widget, 2px wide."""
    f = QtWidgets.QFrame()
    f.setFrameShape(QtWidgets.QFrame.VLine)
    f.setFixedWidth(2)
    f.setStyleSheet(_theme.vline_style())
    return f


def _icon_states(pix):
    """Return a QIcon with a custom greyed disabled state."""
    icon = QtGui.QIcon(pix)
    img  = pix.toImage().convertToFormat(QtGui.QImage.Format_ARGB32)
    fade = float(_theme.BUTTON_ICON_DISABLED)
    for y in range(img.height()):
        for x in range(img.width()):
            col = img.pixelColor(x, y)
            if not col.alpha():
                continue
            lum = (0.299 * col.red() + 0.587 * col.green()
                   + 0.114 * col.blue())
            grey = max(0, min(255, int(round(lum * fade))))
            img.setPixelColor(x, y, QtGui.QColor(grey, grey, grey,
                                                 col.alpha()))
    icon.addPixmap(QtGui.QPixmap.fromImage(img), QtGui.QIcon.Disabled)
    return icon


def _icon_from_png(path, size=20):
    """Load a PNG file and return a QIcon scaled to size × size px."""
    pix = QtGui.QPixmap(path)
    if pix.isNull():
        return QtGui.QIcon(pix)
    pix = pix.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    return _icon_states(pix)


def is_ctrl(mods):
    """Return True for Ctrl (Cmd on macOS)."""
    return bool(mods & Qt.ControlModifier)


def is_alt(mods):
    """Return True for Alt / Option."""
    return bool(mods & Qt.AltModifier)


def is_shift(mods):
    """Return True for Shift."""
    return bool(mods & Qt.ShiftModifier)


def held(*_unused):
    """Return the keyboard modifiers currently held."""
    try:
        return QtWidgets.QApplication.keyboardModifiers()
    except Exception:
        return Qt.NoModifier


def _icon_from_svg(path, size=20):
    """Render an SVG file to a QIcon, or an empty QIcon on failure."""
    try:
        try:
            from PySide6.QtSvg import QSvgRenderer
        except ImportError:
            from PySide2.QtSvg import QSvgRenderer
        renderer = QSvgRenderer(path)
        if not renderer.isValid():
            return QtGui.QIcon()
        pix = QtGui.QPixmap(size, size)
        pix.fill(Qt.transparent)
        painter = QtGui.QPainter(pix)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        box = QtCore.QSizeF(renderer.defaultSize())
        if box.width() > 0 and box.height() > 0:
            box.scale(size, size, Qt.KeepAspectRatio)
            renderer.render(painter, QtCore.QRectF(
                (size - box.width()) / 2.0, (size - box.height()) / 2.0,
                box.width(), box.height()))
        else:
            renderer.render(painter)
        painter.end()
        return _icon_states(pix)
    except Exception:
        return QtGui.QIcon()


class TimecodeEdit(QtWidgets.QLineEdit):
    """Line edit that emits `committed` with its text on Enter or focus-out."""

    committed = QtCore.Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._settled = ''
        self._select_armed = False

    def focusInEvent(self, event):
        """Select the text when the user arrives at the field."""
        super().focusInEvent(event)
        self._select_armed = arrived_at_field(event)
        if self._select_armed:
            self.selectAll()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if self._select_armed:
            self._select_armed = False
            self.selectAll()

    def setText(self, text):
        """Set the text and remember it for Escape."""
        self._settled = text
        super().setText(text)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            event.accept()
            self.setModified(False)
            self.clearFocus()
            self.committed.emit(self.text())
            return
        if event.key() == Qt.Key_Escape:
            event.accept()
            super().setText(self._settled)
            self.setModified(False)
            self.clearFocus()
            return
        super().keyPressEvent(event)

    def focusOutEvent(self, event):
        """Commit typed text on focus-out."""
        typed = self.isModified()
        self._select_armed = False
        super().focusOutEvent(event)
        if typed:
            self.setModified(False)
            self.committed.emit(self.text())


def text_width(widget, sample, extra=0):
    """Pixels needed to show `sample` in `widget`'s own font, plus `extra`."""
    widget.ensurePolished()
    return int(widget.fontMetrics().horizontalAdvance(sample)) + int(extra)


_ICON_QSS_MARK = '/* smtl-icon */'

_QT_SIZE_MAX = 16777215

_FACE_PROP = '_smtl_face'

_FIXED_PROP = '_smtl_icon_fixed'

_MARK_PROP = '_smtl_face_mark'

_MARK_REACH = 0.34
_MARK_GAP   = 1


def set_face_mark(btn, before, after, custom=False):
    """Set or clear the dissolve mark drawn under a button's icon."""
    btn.setProperty(_MARK_PROP,
                    None if before is None else
                    [int(before), int(after), 1 if custom else 0])


def _draw_face_mark(pix, before, after, custom):
    """Paint the mark along the bottom of an icon pixmap, in place."""
    w, h  = pix.width(), pix.height()
    thick = max(2, int(round(h * 0.11)))
    y     = h - thick
    cx    = w / 2.0
    reach = w * _MARK_REACH
    widest = float(max(before, after, 1))
    gap   = _MARK_GAP if (before and after) else 0

    p = QtGui.QPainter(pix)
    p.setRenderHint(QtGui.QPainter.Antialiasing, False)
    p.setPen(QtCore.Qt.NoPen)
    p.setBrush(QtGui.QColor(_theme.CLIP_OFFLINE_BADGE if custom
                            else _theme.TEXT_BRIGHT))
    if after > 0:
        left = reach * (after / widest)
        p.drawRect(QtCore.QRectF(cx - gap - left, y, left, thick))
    if before > 0:
        right = reach * (before / widest)
        p.drawRect(QtCore.QRectF(cx + gap, y, right, thick))
    p.end()


def _face_icon(btn, icons_dir, slug, size):
    """Return the button's icon with its face mark, or None."""
    icon = _load_icon(icons_dir, slug, size)
    mark = btn.property(_MARK_PROP)
    if icon is None or not mark:
        return icon
    before, after, custom = int(mark[0]), int(mark[1]), bool(int(mark[2]))
    if before <= 0 and after <= 0:
        return icon
    pix = icon.pixmap(size, size)
    _draw_face_mark(pix, before, after, custom)
    return _icon_states(pix)


def _load_icon(icons_dir, slug, size):
    """Return the SVG or PNG icon for `slug` at `size`, or None."""
    for ext, loader in (('.svg', _icon_from_svg), ('.png', _icon_from_png)):
        path = os.path.join(icons_dir, slug + ext)
        if os.path.exists(path):
            icon = loader(path, size)
            if not icon.isNull():
                return icon
    return None


def _fit_icon_button(btn):
    """Square an icon button to its height and re-render its icon."""
    face = btn.property(_FACE_PROP)
    if not face:
        return
    icons_dir, slug = face[0], face[1]
    edge  = max(int(btn.height()), int(btn.minimumHeight()))
    size  = max(8, edge - 2 * _theme.BUTTON_ICON_MARGIN)
    width = edge + 2 * _theme.BUTTON_ICON_SIDE_PAD
    if btn.iconSize().height() == size and btn.width() == width:
        return
    icon = _face_icon(btn, icons_dir, slug, size)
    if icon is None:
        return
    btn.setIcon(icon)
    btn.setIconSize(QtCore.QSize(size, size))
    btn.setFixedWidth(width)


class _IconFitter(QtCore.QObject):
    """Event filter that refits icon buttons on resize."""

    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.Resize:
            try:
                _fit_icon_button(obj)
            except Exception:
                pass
        return False


_ICON_FITTER = None


def _icon_fitter():
    """Return the shared icon fitter, creating it on first use."""
    global _ICON_FITTER
    if _ICON_FITTER is None:
        _ICON_FITTER = _IconFitter()
    return _ICON_FITTER


def _without_icon_rule(qss):
    """Return a stylesheet with the icon padding rule removed."""
    at = qss.find(_ICON_QSS_MARK)
    return qss if at < 0 else qss[:at]


def icon_padding_qss(btn):
    """Return the padding rule for an icon-only button."""
    return _ICON_QSS_MARK + ' %s { padding:0px; }' % (
        btn.metaObject().className(),)


def set_button_style(btn, qss):
    """Set a button's stylesheet, keeping its icon padding."""
    btn.setStyleSheet(qss + (icon_padding_qss(btn) if not btn.text() and
                             not btn.icon().isNull() else ''))


def button_icon_px(btn):
    """Return the icon size in px that fills this button."""
    btn.ensurePolished()
    row = btn.fontMetrics().height() + 2 * _theme.BUTTON_PAD_V
    return max(12, row - 2 * _theme.BUTTON_ICON_MARGIN)


def _tip_html(head, body):
    """Return tooltip HTML with a bold heading line."""
    def clean(text):
        return (str(text).replace('&', '&amp;').replace('<', '&lt;')
                .replace('>', '&gt;').replace('\n', '<br>'))
    head = clean(head)
    body = clean(str(body).strip())
    return '<b>%s</b><br>%s' % (head, body) if body else '<b>%s</b>' % head


def apply_button_face(btn, label, icons_dir, tip=None, size=None):
    """Give a button its icon if one exists, else its text label."""
    slug = label.strip().lower().replace(' ', '_')
    if size is None:
        size = button_icon_px(btn)
    icon = _face_icon(btn, icons_dir, slug, size)

    base = _without_icon_rule(btn.styleSheet() or '')

    if icon is not None:
        btn.setIcon(icon)
        btn.setIconSize(QtCore.QSize(size, size))
        btn.setText('')
        cls  = btn.metaObject().className()
        floor = size + 2 * _theme.BUTTON_ICON_MARGIN
        btn.setProperty(_FACE_PROP, [str(icons_dir), slug])
        btn.setProperty(_FIXED_PROP, True)
        btn.setStyleSheet(base + _ICON_QSS_MARK + ' %s { padding:0px; }' % cls)
        btn.setMinimumHeight(floor)
        btn.setMaximumHeight(_QT_SIZE_MAX)
        btn.setFixedWidth(floor + 2 * _theme.BUTTON_ICON_SIDE_PAD)
        pol = btn.sizePolicy()
        pol.setVerticalPolicy(QtWidgets.QSizePolicy.Ignored)
        btn.setSizePolicy(pol)
        btn.removeEventFilter(_icon_fitter())
        btn.installEventFilter(_icon_fitter())
        _fit_icon_button(btn)
    else:
        btn.setIcon(QtGui.QIcon())
        btn.setText(label)
        btn.setStyleSheet(base)
        btn.setProperty(_FACE_PROP, None)
        btn.removeEventFilter(_icon_fitter())
        if btn.property(_FIXED_PROP):
            btn.setProperty(_FIXED_PROP, None)
            pol = btn.sizePolicy()
            pol.setVerticalPolicy(QtWidgets.QSizePolicy.Fixed)
            btn.setSizePolicy(pol)
            btn.setMinimumSize(0, 0)
            btn.setMaximumSize(_QT_SIZE_MAX, _QT_SIZE_MAX)
            btn.updateGeometry()

    tip = (tip if tip is not None else _tips.tip(slug)) or ''
    tip = tip.strip()
    btn.setToolTip(_tip_html(label, tip if tip != label else ''))


RATE_CHOICES = (
    (23.976, None,  '23.976'),
    (24.0,   None,  '24'),
    (25.0,   None,  '25'),
    (29.97,  False, '29.97 NDF'),
    (29.97,  True,  '29.97 DF'),
    (30.0,   None,  '30'),
    (47.952, None,  '47.952'),
    (48.0,   None,  '48'),
    (50.0,   None,  '50'),
    (59.94,  False, '59.94 NDF'),
    (59.94,  True,  '59.94 DF'),
    (60.0,   None,  '60'),
    (119.88, None,  '119.88'),
    (120.0,  None,  '120'),
)


_DRAG_MIN_W        = 80
_DRAG_FIELD_CHROME = 18


def _indented(widget):
    """Return an indented row layout holding a widget."""
    row = QtWidgets.QHBoxLayout()
    row.setContentsMargins(_DLG_INDENT, 0, 0, 0)
    row.addWidget(widget)
    row.addStretch()
    return row


def _punctuated(text):
    """Return a bare-digit timecode entry with colons inserted."""
    packed = ''.join(str(text or '').split())
    if not packed.isdigit():
        return packed
    parts, rest = [], packed
    while rest:
        parts.insert(0, rest[-2:])
        rest = rest[:-2]
    return ':'.join(parts)


class ImportOptionsDialog(QtWidgets.QDialog):
    """Dialog asking an import's frame rate and start timecode."""

    def __init__(self, script_rate, edl_tc, script_tc, parent=None,
                 stated_rate=None, what='EDL', drop=None, bundle=None):
        super(ImportOptionsDialog, self).__init__(parent)
        self._script_rate = float(stated_rate or script_rate)
        self._stated_rate = stated_rate
        self._edl_tc      = str(edl_tc)
        self._script_tc   = str(script_tc)
        self.setWindowTitle('SMTL — import')
        self.setStyleSheet(_theme.dialog_style())

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(_DLG_MARGIN, _DLG_MARGIN,
                               _DLG_MARGIN, _DLG_MARGIN)
        lay.setSpacing(_DLG_SPACING)

        self._otioz_box = None
        if bundle:
            self._otioz_box = QtWidgets.QWidget()
            zip_lay = QtWidgets.QVBoxLayout(self._otioz_box)
            zip_lay.setContentsMargins(0, 0, 0, 0)
            zip_lay.setSpacing(_DLG_SPACING)

            self._zip_extract = QtWidgets.QCheckBox('Extract media to')
            self._zip_extract.setToolTip(_tips.tip('otioz_extract'))
            zip_lay.addWidget(self._zip_extract)

            where = QtWidgets.QWidget()
            row = QtWidgets.QHBoxLayout(where)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(_DLG_SPACING)
            self._zip_beside = QtWidgets.QCheckBox('Same folder as the otioz')
            self._zip_beside.setChecked(True)
            self._zip_beside.setToolTip(_tips.tip('otioz_beside'))
            row.addWidget(self._zip_beside)
            self._zip_path = QtWidgets.QLineEdit(self)
            self._zip_path.setFixedWidth(_DLG_FIELD_W)
            self._zip_path.setFixedHeight(_DLG_FIELD_H)
            self._zip_path.setToolTip(_tips.tip('otioz_path'))
            self._zip_path.setPlaceholderText('folder')
            row.addWidget(self._zip_path)
            self._zip_browse = QtWidgets.QPushButton('Browse')
            self._zip_browse.clicked.connect(self._browse_extract)
            row.addWidget(self._zip_browse)
            row.addStretch()
            zip_lay.addLayout(_indented(where))

            zip_lay.addWidget(QtWidgets.QLabel(bundle))

            self._zip_ref = QtWidgets.QCheckBox('Use media as reference')
            self._zip_ref.setToolTip(_tips.tip('otioz_reference'))
            zip_lay.addWidget(self._zip_ref)

            def _gate(*_a):
                on = self._zip_extract.isChecked()
                self._zip_beside.setEnabled(on)
                where = on and not self._zip_beside.isChecked()
                self._zip_path.setEnabled(where)
                self._zip_browse.setEnabled(where)
                self._zip_ref.setEnabled(on)
                if not on:
                    self._zip_ref.setChecked(False)
            self._zip_extract.toggled.connect(_gate)
            self._zip_beside.toggled.connect(_gate)
            _gate()
            lay.addWidget(self._otioz_box)
            lay.addSpacing(_DLG_GROUP_GAP)

        agreed = (stated_rate is not None
                  and abs(float(stated_rate) - float(script_rate)) < 1e-6)

        self._rate_box = QtWidgets.QWidget()
        rate_lay = QtWidgets.QVBoxLayout(self._rate_box)
        rate_lay.setContentsMargins(0, 0, 0, 0)
        rate_lay.setSpacing(_DLG_SPACING)

        if stated_rate is None:
            said = ('FPS not defined in %s.  Script is %g fps.'
                    % (what, script_rate))
            match_label = 'Match script'
        else:
            said = ('%s states %g fps.  Script is %g fps.'
                    % (what, stated_rate, script_rate))
            match_label = 'Match %s import (recommended)' % what
        rate_lay.addWidget(QtWidgets.QLabel(said))

        self._rate_match = QtWidgets.QRadioButton(match_label)
        self._rate_match.setChecked(True)
        self._rate_set   = QtWidgets.QRadioButton('Set')
        self._rate_group = QtWidgets.QButtonGroup(self)
        self._rate_group.setExclusive(True)
        self._rate_group.addButton(self._rate_match)
        self._rate_group.addButton(self._rate_set)
        rate_lay.addWidget(self._rate_match)
        rate_lay.addWidget(self._rate_set)

        self._rate_combo = QtWidgets.QComboBox()
        self._rate_combo.setEditable(True)
        self._rate_combo.setFixedWidth(_DLG_FIELD_W)
        self._rate_combo.setFixedHeight(_DLG_FIELD_H)
        for value, is_df, label in RATE_CHOICES:
            self._rate_combo.addItem(label, (value, is_df))
        if drop is not None:
            model = self._rate_combo.model()
            for row, (_v, is_df, _l) in enumerate(RATE_CHOICES):
                if is_df is not None and bool(is_df) != bool(drop):
                    item = model.item(row)
                    if item is not None:
                        item.setEnabled(False)
        self._select_rate(float(stated_rate or script_rate), drop)
        rate_lay.addLayout(_indented(self._rate_combo))

        self._rate_combo.currentIndexChanged.connect(
            lambda _i: (self._rate_set.setChecked(True), self._revalidate()))
        self._rate_combo.editTextChanged.connect(
            lambda _t: (self._rate_set.setChecked(True), self._revalidate()))
        self._rate_group.buttonToggled.connect(lambda *_a: self._revalidate())

        lay.addWidget(self._rate_box)
        if agreed:
            self._rate_box.hide()
        else:
            lay.addSpacing(_DLG_GROUP_GAP)

        lay.addWidget(QtWidgets.QLabel(
            'Start timecode.  %s is %s, script is %s.'
            % (what, edl_tc, script_tc)))

        self._tc_edl    = QtWidgets.QRadioButton('Match %s' % what)
        self._tc_script = QtWidgets.QRadioButton('Match script')
        self._tc_set    = QtWidgets.QRadioButton('Set')
        self._tc_edl.setChecked(True)
        self._tc_group  = QtWidgets.QButtonGroup(self)
        self._tc_group.setExclusive(True)
        for b in (self._tc_edl, self._tc_script, self._tc_set):
            self._tc_group.addButton(b)
            lay.addWidget(b)

        self._tc_edit = QtWidgets.QLineEdit(self)
        self._tc_edit.setText(edl_tc)
        self._tc_edit.setFixedWidth(_DLG_FIELD_W)
        self._tc_edit.setFixedHeight(_DLG_FIELD_H)
        self._tc_edit.textEdited.connect(
            lambda _t: self._tc_set.setChecked(True))
        self._tc_edit.editingFinished.connect(self._show_tc_for_frames)
        self._tc_edit.installEventFilter(self)
        lay.addLayout(_indented(self._tc_edit))

        self._error = QtWidgets.QLabel('')
        self._error.setStyleSheet(_theme.dialog_error_style())
        self._error.hide()
        lay.addSpacing(_DLG_SPACING)
        lay.addWidget(self._error)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

        lay.setSizeConstraint(QtWidgets.QLayout.SetFixedSize)


    def _select_rate(self, rate, drop):
        """Select the list entry for a rate, matching drop-frame where it applies."""
        best = 0
        for row, (value, is_df, _l) in enumerate(RATE_CHOICES):
            if abs(value - float(rate)) > 1e-6:
                continue
            best = row
            if is_df is None or drop is None or bool(is_df) == bool(drop):
                break
        self._rate_combo.setCurrentIndex(best)

    def rate(self):
        """Return the chosen frame rate."""
        if not self._rate_set.isChecked():
            return float(self._script_rate)
        data = self._rate_combo.currentData()
        if data is not None and self._rate_combo.currentText() == \
                self._rate_combo.itemText(self._rate_combo.currentIndex()):
            return float(data[0])
        m = _re.search(r'[\d.]+', self._rate_combo.currentText())
        return float(m.group(0)) if m else float(self._script_rate)

    def drop(self):
        """Return whether the chosen rate is drop-frame."""
        if self._rate_set.isChecked():
            data = self._rate_combo.currentData()
            if data is not None and data[1] is not None:
                text = self._rate_combo.currentText()
                if text == self._rate_combo.itemText(
                        self._rate_combo.currentIndex()):
                    return bool(data[1])
        return is_drop_frame_rate(self.rate())

    def start_frames(self):
        """Return the accepted start in frames, or None."""
        return getattr(self, '_frames', None)

    def start_tc(self):
        """Return the chosen start timecode text."""
        if self._tc_set.isChecked():
            return self._tc_edit.text()
        if self._tc_script.isChecked():
            return self._script_tc
        return self._edl_tc


    def eventFilter(self, obj, event):
        """Convert on Return in the start field and swallow the key."""
        if (obj is self._tc_edit
                and event.type() == QtCore.QEvent.KeyPress
                and event.key() in (Qt.Key_Return, Qt.Key_Enter)):
            self._show_tc_for_frames()
            return True
        return super(ImportOptionsDialog, self).eventFilter(obj, event)

    def _fill_from(self):
        """Return the frame count partial entries fill from, or None."""
        try:
            return timecode_to_frames(self._edl_tc, self.rate(), self.drop())
        except Exception:
            return None


    def _browse_extract(self):
        """Browse for the media extraction folder."""
        try:
            import nuke
            got = nuke.getFilename('SMTL — where to extract the media')
        except Exception:
            got = ''
        if got:
            import os
            self._zip_path.setText(got if os.path.isdir(got)
                                   else os.path.dirname(got))

    def extract_media(self):
        """Return whether to extract the bundle's media."""
        return bool(self._otioz_box is not None
                    and self._zip_extract.isChecked())

    def extract_beside(self):
        """Return whether to extract into the bundle's folder."""
        return bool(self.extract_media() and self._zip_beside.isChecked())

    def extract_path(self):
        """Return the extraction folder, or '' for beside the bundle or none."""
        if not self.extract_media() or self.extract_beside():
            return ''
        return str(self._zip_path.text()).strip()

    def media_as_reference(self):
        """Return whether extracted media also comes in as a locked layer."""
        return bool(self._otioz_box is not None
                    and self._zip_ref.isChecked()
                    and self.extract_media())

    def _revalidate(self):
        """Recheck a refused start at the chosen rate."""
        if not self._error.isVisible():
            return
        try:
            parse_start_entry(self.start_tc(), self.rate(), self.drop(),
                              self._fill_from())
        except Exception:
            self._refuse()
            return
        self._error.hide()

    def _show_tc_for_frames(self):
        """Rewrite a frame entry as the timecode it means, at the chosen rate."""
        rate, drop = self.rate(), self.drop()
        try:
            frames = parse_start_entry(self._tc_edit.text(), rate, drop,
                                       self._fill_from())
        except Exception:
            return
        self._error.hide()
        self._tc_edit.setText(frames_to_timecode(frames, rate, drop))

    def accept(self):
        """Accept only a readable start; otherwise show the error."""
        try:
            self._frames = parse_start_entry(
                self.start_tc(), self.rate(), self.drop(), self._fill_from())
        except Exception:
            self._refuse()
            self._tc_edit.setFocus()
            self._tc_edit.selectAll()
            return
        super(ImportOptionsDialog, self).accept()

    def _refuse(self):
        """Show the error for an unreadable start."""
        rate  = self.rate()
        typed = self._tc_edit.text().strip()
        said  = 'invalid timecode %s at %gfps' % (_punctuated(typed), rate)
        if _re.match(r'^[+-]?\d+$', typed):
            said += '. Use %sf to set frame or change fps' % typed
        self._error.setText(said)
        self._error.show()


EXT_CHOICES = ['any', '.exr', '.dpx', '.mov', '.mxf', '.tif', '.jpg', '.png',
               '.ari', '.r3d', '.braw']


_CLASH_PAGE = 10

_THUMB_W, _THUMB_H = 96, 54

_CLASH_NAME_W   = 220
_CLASH_CELL_PAD = 12
_CLASH_COL_MAX  = 320

_UNSET = object()


class ConflictDialog(QtWidgets.QDialog):
    """Dialog choosing one file per source that matched several."""

    def __init__(self, clashes, parent=None, thumb=None):
        """Build the clash table from [(label, [(choice_label, payload), …]), …]."""
        super(ConflictDialog, self).__init__(parent)
        self.setWindowTitle('SMTL — more than one file matched')
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(_theme.dialog_style())

        self._thumb   = thumb
        self._clashes = list(clashes)
        self._chosen  = {}
        self._page    = 0
        self._pending = []

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(_DLG_MARGIN, _DLG_MARGIN,
                               _DLG_MARGIN, _DLG_MARGIN)
        lay.setSpacing(_DLG_SPACING)

        n = len(self._clashes)
        lay.addWidget(QtWidgets.QLabel(
            '%d conflict%s found' % (n, '' if n == 1 else 's')))

        widest = max([len(c[1]) for c in self._clashes] or [1])
        self._table = QtWidgets.QTableWidget(0, widest + 2)
        self._table.setHorizontalHeaderLabels(
            ['source'] + [''] * widest + ['skip'])
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self._table.setFocusPolicy(QtCore.Qt.NoFocus)
        self._table.setShowGrid(False)
        head = self._table.horizontalHeader()
        head.setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
        head.setStretchLastSection(False)
        lay.addWidget(self._table, 1)

        self._page_lbl = QtWidgets.QLabel('')
        self._prev = QtWidgets.QPushButton('Back')
        self._next = QtWidgets.QPushButton('More')
        self._prev.clicked.connect(lambda: self._turn(-1))
        self._next.clicked.connect(lambda: self._turn(1))
        page_row = QtWidgets.QHBoxLayout()
        page_row.addWidget(self._page_lbl)
        page_row.addStretch(1)
        page_row.addWidget(self._prev)
        page_row.addWidget(self._next)
        if n > _CLASH_PAGE:
            lay.addLayout(page_row)

        row = QtWidgets.QHBoxLayout()
        row.addStretch(1)
        use = QtWidgets.QPushButton('Apply')
        skip = QtWidgets.QPushButton('Cancel')
        use.setDefault(True)
        use.clicked.connect(self.accept)
        skip.clicked.connect(self.reject)
        row.addWidget(use)
        row.addWidget(skip)
        lay.addLayout(row)

        self._draw()
        room_w, room_h = self._room()
        want_w = self._width_for_columns()
        want_h = self._height_for_rows()
        if want_w > room_w:
            want_h += self._table.horizontalScrollBar().sizeHint().height()
        self.resize(min(want_w, room_w), min(want_h, room_h))

    def _width_for_columns(self):
        """Return the width needed to show every column."""
        cols = sum(self._table.columnWidth(c)
                   for c in range(self._table.columnCount()))
        bar = self._table.verticalScrollBar().sizeHint().width()
        return (cols + bar + 2 * self._table.frameWidth()
                + 2 * _DLG_MARGIN + 2)

    def _height_for_rows(self):
        """Return the height needed to show every row of the page."""
        rows = sum(self._table.rowHeight(r)
                   for r in range(self._table.rowCount()))
        table = (rows + self._table.horizontalHeader().sizeHint().height()
                 + 2 * self._table.frameWidth() + 2)
        rest = self.sizeHint().height() - self._table.sizeHint().height()
        return table + max(rest, 0)

    @staticmethod
    def _room():
        """Return 90% of the available screen size, with a fallback."""
        screen = QtWidgets.QApplication.primaryScreen()
        if screen is None:
            return 1600, 900
        avail = screen.availableGeometry()
        return int(avail.width() * 0.9), int(avail.height() * 0.9)


    def _draw(self):
        """Rebuild the visible page, rendering only the first row's thumbnails."""
        first = self._page * _CLASH_PAGE
        page  = self._clashes[first:first + _CLASH_PAGE]
        self._pending = []
        self._table.setRowCount(len(page))

        for r, (label, choices) in enumerate(page):
            idx = first + r
            name = QtWidgets.QLabel(' ' + _elide_middle(str(label), 30))
            name.setToolTip(str(label))
            name.setStyleSheet('border-bottom: 1px solid %s;' % _theme.LINE)
            self._table.setCellWidget(r, 0, name)

            group = QtWidgets.QButtonGroup(self._table)
            group.setExclusive(True)
            for c, (text, payload) in enumerate(choices):
                cell, pic, button = self._choice_cell(text, payload, idx)
                group.addButton(button)
                self._table.setCellWidget(r, 1 + c, cell)
                if self._thumb is not None:
                    if r == 0:
                        _set_thumb(pic, self._thumb(payload))
                    else:
                        self._pending.append((pic, payload))
            cell, _pic, button = self._choice_cell('skip', None, idx)
            group.addButton(button)
            self._table.setCellWidget(r, self._table.columnCount() - 1, cell)
            for c in range(1 + len(choices), self._table.columnCount() - 1):
                self._table.setCellWidget(r, c, self._blank_cell())
            self._table.setRowHeight(r, _THUMB_H + 26)

        self._size_columns()

        pages = max(1, (len(self._clashes) + _CLASH_PAGE - 1) // _CLASH_PAGE)
        self._page_lbl.setText('%d–%d of %d'
                               % (first + 1, first + len(page),
                                  len(self._clashes)))
        self._prev.setEnabled(self._page > 0)
        self._next.setEnabled(self._page < pages - 1)

    def _blank_cell(self):
        """Return an empty cell carrying the row's bottom line."""
        cell = QtWidgets.QWidget()
        cell.setObjectName('clash_cell')
        cell.setStyleSheet('QWidget#clash_cell { border-bottom: 1px solid %s; }'
                           % _theme.LINE)
        return cell

    def _size_columns(self):
        """Size each column to its contents, within floor and cap."""
        for c in range(self._table.columnCount()):
            need = 0
            for r in range(self._table.rowCount()):
                cell = self._table.cellWidget(r, c)
                if cell is not None:
                    need = max(need, cell.sizeHint().width())
            floor = _CLASH_NAME_W if c == 0 else _THUMB_W + 16
            self._table.setColumnWidth(
                c, min(max(floor, need + _CLASH_CELL_PAD), _CLASH_COL_MAX))

    def _choice_cell(self, text, payload, idx):
        """Return a choice cell with thumbnail placeholder and radio button."""
        cell = QtWidgets.QWidget()
        cell.setObjectName('clash_cell')
        col = QtWidgets.QVBoxLayout(cell)
        col.setContentsMargins(4, 2, 4, 0)
        col.setSpacing(2)
        pic = QtWidgets.QLabel()
        pic.setFixedSize(_THUMB_W, _THUMB_H)
        pic.setAlignment(QtCore.Qt.AlignCenter)
        pic.setStyleSheet('background-color: %s;' % _theme.WELL_BG)
        button = QtWidgets.QRadioButton(str(text))
        button.setToolTip(str(getattr(payload, 'path', '') or text))
        pic.setToolTip(button.toolTip())
        button.setChecked(self._chosen.get(idx, _UNSET) is payload)
        button.toggled.connect(
            lambda on, i=idx, p=payload: on and self._pick(i, p))
        if payload is not None:
            col.addWidget(pic)
        else:
            spacer = QtWidgets.QWidget()
            spacer.setFixedSize(_THUMB_W, _THUMB_H)
            col.addWidget(spacer)
        col.addWidget(button)
        cell.setStyleSheet('QWidget#clash_cell { border-bottom: 1px solid %s; }'
                           % _theme.LINE)
        return cell, pic, button

    def fill_thumbnails(self, tick=None):
        """Render the queued thumbnails, calling `tick` between each."""
        while self._pending:
            pic, payload = self._pending.pop(0)
            try:
                _set_thumb(pic, self._thumb(payload))
            except Exception:
                pass
            if tick is not None:
                tick()

    def _pick(self, index, payload):
        self._chosen[index] = payload

    def _turn(self, by):
        pages = max(1, (len(self._clashes) + _CLASH_PAGE - 1) // _CLASH_PAGE)
        self._page = max(0, min(pages - 1, self._page + by))
        self._draw()


    def choices(self):
        """Return {index: payload} for every answered, non-skipped clash."""
        return {i: p for i, p in self._chosen.items() if p is not None}


def _set_thumb(label, path):
    """Put a rendered frame in its placeholder, scaled to fit."""
    if not path:
        return
    pix = QtGui.QPixmap(str(path))
    if pix.isNull():
        return
    label.setPixmap(pix.scaled(_THUMB_W, _THUMB_H,
                               QtCore.Qt.KeepAspectRatio,
                               QtCore.Qt.SmoothTransformation))


class RateMismatchDialog(QtWidgets.QDialog):
    """Dialog asking whether to retime media whose rate differs from the edit."""

    def __init__(self, name, media_rate, seq_rate, parent=None, more=0):
        super(RateMismatchDialog, self).__init__(parent)
        self.setWindowTitle('SMTL')
        self.setStyleSheet(_theme.dialog_style())

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(_DLG_MARGIN, _DLG_MARGIN,
                               _DLG_MARGIN, _DLG_MARGIN)
        lay.setSpacing(_DLG_SPACING)

        head = QtWidgets.QLabel('Mismatched frame rate')
        head.setStyleSheet('font-weight: bold;')
        lay.addWidget(head)
        lay.addWidget(QtWidgets.QLabel(
            '"%s" is %s fps, the edit is %sfps'
            % (_elide_middle(str(name), 44),
               _rate_text(media_rate), _rate_text(seq_rate))))

        self._all = QtWidgets.QCheckBox('apply to all')
        if more > 0:
            lay.addSpacing(_DLG_GROUP_GAP)
            lay.addWidget(self._all)

        lay.addSpacing(_DLG_SPACING)
        row = QtWidgets.QHBoxLayout()
        row.addStretch(1)
        retime = QtWidgets.QPushButton('Retime')
        leave  = QtWidgets.QPushButton('leave')
        retime.setDefault(True)
        retime.clicked.connect(self.accept)
        leave.clicked.connect(self.reject)
        row.addWidget(retime)
        row.addWidget(leave)
        lay.addLayout(row)
        lay.setSizeConstraint(QtWidgets.QLayout.SetFixedSize)

    def apply_to_all(self):
        return self._all.isChecked()


def _rate_text(rate):
    """Return a rate as short text: 25, 23.976."""
    rate = float(rate or 0.0)
    return str(int(round(rate))) if abs(rate - round(rate)) < 1e-6 \
        else ('%.3f' % rate).rstrip('0').rstrip('.')


def _elide_middle(text, width):
    """Shorten text to `width` characters by eliding the middle."""
    if len(text) <= width:
        return text
    keep = width - 1
    return text[:keep // 2] + '…' + text[-(keep - keep // 2):]


class ConformOptionsDialog(QtWidgets.QDialog):
    """Dialog setting where to search for media and what must match."""

    def __init__(self, waiting, selected=0, parent=None, start_root='',
                 default_ext='any', have_paths=True, have_names=True,
                 have_reels=False):
        super(ConformOptionsDialog, self).__init__(parent)
        self.setWindowTitle('SMTL — conform')
        self.setStyleSheet(_theme.dialog_style())

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(_DLG_MARGIN, _DLG_MARGIN,
                               _DLG_MARGIN, _DLG_MARGIN)
        lay.setSpacing(_DLG_SPACING)

        lay.addWidget(QtWidgets.QLabel(
            '%d clip%s ha%s no media.'
            % (waiting, '' if waiting == 1 else 's',
               's' if waiting == 1 else 've')))

        self._all = QtWidgets.QRadioButton('All')
        self._sel = QtWidgets.QRadioButton('selected')
        self._all.setChecked(not selected)
        self._sel.setChecked(bool(selected))
        if selected:
            lay.addSpacing(_DLG_GROUP_GAP)
            lay.addWidget(QtWidgets.QLabel('Apply to'))
            which = QtWidgets.QButtonGroup(self)
            which.setExclusive(True)
            for b in (self._all, self._sel):
                which.addButton(b)
                lay.addWidget(b)

        lay.addSpacing(_DLG_GROUP_GAP)
        lay.addWidget(QtWidgets.QLabel('Search in'))

        self._orig   = QtWidgets.QRadioButton('Original path')
        self._custom = QtWidgets.QRadioButton('Custom path')
        self._orig.setChecked(True)
        where = QtWidgets.QButtonGroup(self)
        where.setExclusive(True)
        for b in (self._orig, self._custom):
            where.addButton(b)
            lay.addWidget(b)

        self._have_paths = bool(have_paths)
        self._have_names = bool(have_names)
        self._have_reels = bool(have_reels)
        if not have_paths:
            self._orig.setEnabled(False)
            self._orig.setToolTip(_tips.tip('orig'))
            self._custom.setChecked(True)

        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(_DLG_INDENT, 0, 0, 0)
        self._root = QtWidgets.QLineEdit(str(start_root or ''))
        self._root.setFixedHeight(_DLG_FIELD_H)
        self._root.setMinimumWidth(_DLG_FIELD_W * 2)
        self._root.textEdited.connect(lambda _t: self._custom.setChecked(True))
        browse = QtWidgets.QPushButton('Browse')
        browse.clicked.connect(self._browse)
        row.addWidget(self._root)
        row.addWidget(browse)
        lay.addLayout(row)

        lay.addSpacing(_DLG_GROUP_GAP)
        self._match_label = QtWidgets.QLabel('Match on')
        lay.addWidget(self._match_label)

        self._reel     = QtWidgets.QCheckBox('reel')
        self._name     = QtWidgets.QCheckBox('name')
        self._use_ext  = QtWidgets.QCheckBox('extension')
        for b in (self._name, self._use_ext):
            b.setChecked(True)
        self._reel.setChecked(False)

        row2 = QtWidgets.QHBoxLayout()
        row2.setSpacing(_DLG_SPACING)
        self._ext = QtWidgets.QComboBox()
        self._ext.setEditable(True)
        self._ext.addItems(EXT_CHOICES)
        self._ext.setFixedHeight(_DLG_FIELD_H)
        self._ext.setMinimumWidth(_DLG_FIELD_W)
        idx = self._ext.findText(str(default_ext or 'any'))
        self._ext.setCurrentIndex(idx if idx >= 0 else 0)
        row2.addWidget(self._reel)
        row2.addWidget(self._name)
        row2.addWidget(self._use_ext)
        row2.addWidget(self._ext)
        row2.addStretch(1)
        lay.addLayout(row2)

        lay.addSpacing(_DLG_GROUP_GAP)
        self._case = QtWidgets.QCheckBox('case sensitive')
        self._case.setChecked(True)
        lay.addWidget(self._case)

        self._buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        self._buttons.button(QtWidgets.QDialogButtonBox.Ok).setText('Conform')
        self._buttons.accepted.connect(self.accept)
        self._buttons.rejected.connect(self.reject)
        lay.addSpacing(_DLG_SPACING)
        lay.addWidget(self._buttons)

        for b in (self._orig, self._custom, self._reel, self._name,
                  self._use_ext, self._case):
            b.toggled.connect(self._enable)
        self._enable()

        lay.setSizeConstraint(QtWidgets.QLayout.SetFixedSize)


    def _enable(self):
        """Enable controls that apply and untick unavailable rules."""
        custom = self._custom.isChecked()
        self._root.setEnabled(custom)
        self._match_label.setEnabled(custom)
        self._case.setEnabled(custom)
        for w, have, why in (
                (self._reel, self._have_reels,
                 'These clips have no reel.'),
                (self._name, self._have_names,
                 'These clips have no name.')):
            w.setEnabled(custom and have)
            w.setToolTip('' if have else why)
            if not have and w.isChecked():
                w.setChecked(False)
        self._use_ext.setEnabled(custom)
        self._ext.setEnabled(custom and self._use_ext.isChecked())
        ok = self._buttons.button(QtWidgets.QDialogButtonBox.Ok)
        ok.setEnabled(self.spec().usable)

    def _browse(self):
        """Browse for a search root and select Custom path."""
        try:
            import nuke
            got = nuke.getFilename('SMTL — where to search')
        except Exception:
            got = ''
        if got:
            import os
            self._root.setText(got if os.path.isdir(got)
                               else os.path.dirname(got))
            self._custom.setChecked(True)


    def selected_only(self):
        return bool(self._sel.isChecked())

    def spec(self):
        """Return the dialog settings as a `smtl_conform.SearchSpec`."""
        import smtl_conform as _conform
        ext = self._ext.currentText().strip().lower()
        if ext and ext != 'any' and not ext.startswith('.'):
            ext = '.' + ext
        return _conform.SearchSpec(
            search_in=(_conform.CUSTOM_PATH if self._custom.isChecked()
                       else _conform.ORIGINAL_PATH),
            root=self._root.text().strip(),
            use_reel=self._reel.isChecked(),
            use_name=self._name.isChecked(),
            use_ext=self._use_ext.isChecked() and ext not in ('', 'any'),
            ext=('' if ext == 'any' else ext),
            case_sensitive=self._case.isChecked(),
        )

"""Pure-Python data classes for the SMTL timeline; no Qt or Nuke imports."""

import os, sys as _sys
_SMTL_DIR = os.path.dirname(os.path.abspath(__file__))
if _SMTL_DIR not in _sys.path:
    _sys.path.insert(0, _SMTL_DIR)

import math as _math
import re as _re
import uuid as _uuid

from smtl_constants import _LAYER_H, _NO_WALL, _STILL_HANDLE, _NO_MEDIA

_LAYER_NAME_RE = _re.compile(r'^Track (\d+)$')


def new_clip_id():
    """Generate a random eight-hex-character clip id."""
    return _uuid.uuid4().hex[:8]


RETIME_TIMEWARP = 'timewarp'
RETIME_OFLOW    = 'oflow'
RETIME_KRONOS   = 'kronos'
RETIME_NODES    = (RETIME_TIMEWARP, RETIME_OFLOW, RETIME_KRONOS)

RETIME_NEEDS_NUKEX = (RETIME_KRONOS,)

RETIME_CLASSES = {
    RETIME_TIMEWARP: 'TimeWarp',
    RETIME_OFLOW:    'OFlow2',
    RETIME_KRONOS:   'Kronos',
}

RETIME_CURVE_KNOB = {
    RETIME_TIMEWARP: 'lookup',
    RETIME_OFLOW:    'timingFrame2',
    RETIME_KRONOS:   'timingFrame2',
}
RETIME_MODE_KNOB = {
    RETIME_OFLOW:  ('timing2', 'Frame'),
    RETIME_KRONOS: ('timing2', 'Frame'),
}


ALPHA_USE     = 'use'
ALPHA_INVERT  = 'invert'
ALPHA_IGNORE  = 'ignore'
ALPHA_REMOVE  = 'remove'

ALPHA_MODES = (
    (ALPHA_USE,    'Use alpha'),
    (ALPHA_INVERT, 'Invert alpha'),
    (ALPHA_IGNORE, 'Ignore'),
    (ALPHA_REMOVE, 'Remove'),
)

ALPHA_WAS = {'add': ALPHA_IGNORE, 'none': ALPHA_REMOVE}


class SMTLClip:
    """A single clip bound to a Nuke Read node."""

    __slots__ = (
        'clip_id',
        'node_name', 'label',
        'first_frame', 'last_frame',
        'src_first', 'src_last',
        'orig_src_first', 'orig_src_last',
        'selected', 'offline', 'disabled', 'stale',
        'missing', 'was_missing', 'arrived',
        'user_label', 'colour',
        'merge_op', 'merge_mix', 'alpha_mode', 'alpha_premult',
        'speed', 'retime_node', 'retime_substituted',
        'src_reel', 'src_name', 'src_path',
        'src_tc', 'src_frame', 'src_rate',
    )

    def __init__(self, node_name, label, first_frame, last_frame,
                 src_first=None, src_last=None):
        self.clip_id     = new_clip_id()
        self.node_name   = node_name
        self.label       = label
        self.first_frame = int(first_frame)
        self.last_frame  = int(last_frame)
        self.src_first   = int(src_first) if src_first is not None else self.first_frame
        self.src_last    = int(src_last)  if src_last  is not None else self.last_frame
        self.orig_src_first = self.src_first
        self.orig_src_last  = self.src_last
        self.speed       = 1.0
        self.retime_node = None
        self.retime_substituted = False
        self.selected    = False
        self.offline     = False
        self.disabled    = False
        self.stale       = False
        self.missing     = ()
        self.was_missing = ()
        self.arrived     = ()
        self.merge_op    = 'over'
        self.merge_mix   = 1.0
        self.alpha_mode    = ALPHA_USE
        self.alpha_premult = False
        self.user_label  = ''
        self.colour      = ''
        self.src_reel    = ''
        self.src_name    = ''
        self.src_path    = ''
        self.src_tc      = ''
        self.src_frame   = None
        self.src_rate    = 0.0

    @property
    def is_placeholder(self):
        """True when this clip has no Read node yet."""
        return self.node_name == _NO_MEDIA

    @property
    def display_label(self):
        """Label drawn on the bar, with the speed appended when not 100%."""
        base = self.user_label or self.label
        return base if self.speed == 1.0 else f'{base}  {self.speed_label}'

    @property
    def speed_label(self):
        """The speed as a percentage string."""
        pct = self.speed * 100.0
        return f'{pct:.0f}%' if abs(pct - round(pct)) < 0.05 else f'{pct:.1f}%'

    @property
    def duration(self):
        return max(1, self.last_frame - self.first_frame + 1)

    def __repr__(self):
        return f'<SMTLClip {self.node_name} tl={self.first_frame}-{self.last_frame}>'


class SMTLLayer:
    """A horizontal track that contains zero or more clips."""

    def __init__(self, name=None):
        self.name      = name or 'Track'
        self.clips     = []
        self.transitions = []
        self.locked    = False
        self.solo      = False
        self.hidden    = False
        self.height    = _LAYER_H

    def __repr__(self):
        return f'<SMTLLayer "{self.name}" clips={len(self.clips)}>'


class SMTLTransition:
    """A dissolve, anchored to a frame rather than to a clip."""

    __slots__ = ('at_frame', 'before', 'after', 'curve')

    def __init__(self, at_frame, before, after=None, curve='linear'):
        """Take (at_frame, before, after), or (at_frame, length) for a centred one."""
        if after is None:
            length = int(before)
            before, after = length // 2, length - length // 2
        self.at_frame = int(at_frame)
        self.before   = max(0, int(before))
        self.after    = max(0, int(after))
        self.curve    = curve if curve in ('linear', 'smooth') else 'linear'

    @property
    def length(self):
        return self.before + self.after

    @property
    def first_frame(self):
        return self.at_frame - self.before

    @property
    def last_frame(self):
        return self.at_frame + self.after - 1

    def sides(self, clips):
        """Return (outgoing, incoming) clips at this anchor, either may be None."""
        out = next((c for c in clips if c.last_frame + 1 == self.at_frame), None)
        inc = next((c for c in clips if c.first_frame == self.at_frame), None)
        return out, inc

    def __repr__(self):
        return (f'<SMTLTransition at {self.at_frame} '
                f'-{self.before}/+{self.after} {self.curve}>')


def anchor_sides(clips, at_frame):
    """Return (outgoing, incoming) clips at an anchor; either may be None."""
    return (next((c for c in clips if c.last_frame + 1 == at_frame), None),
            next((c for c in clips if c.first_frame == at_frame), None))


def transition_room(clips, at_frame, transitions=()):
    """Return (max_before, max_after) a transition at this anchor can reach."""
    out, inc = anchor_sides(clips, at_frame)
    if out is None and inc is None:
        return 0, 0

    max_before = max_after = _NO_WALL
    if out is not None:
        room = clip_handles(out)[1]
        tail = _NO_WALL if room < 0 else handle_room(out, room)
        max_after  = min(max_after, tail)
        max_before = min(max_before, out.last_frame - out.first_frame + 1)
        other = next((t for t in transitions
                      if t.at_frame == out.first_frame), None)
        if other is not None:
            max_before = min(max_before, out.last_frame - other.last_frame)
    if inc is not None:
        room = clip_handles(inc)[0]
        head = _NO_WALL if room < 0 else handle_room(inc, room)
        max_before = min(max_before, head)
        max_after  = min(max_after,  inc.last_frame - inc.first_frame + 1)
        other = next((t for t in transitions
                      if t.at_frame == inc.last_frame + 1), None)
        if other is not None:
            max_after = min(max_after, other.first_frame - inc.first_frame)

    if out is None:
        ends = [c.last_frame for c in clips if c.last_frame < at_frame]
        if ends:
            max_before = min(max_before, at_frame - 1 - max(ends))
    if inc is None:
        starts = [c.first_frame for c in clips if c.first_frame >= at_frame]
        if starts:
            max_after = min(max_after, min(starts) - at_frame)
    return max(0, max_before), max(0, max_after)


def fit_dissolve(clips, at_frame, before, after, transitions=()):
    """Return (before, after, reason) for the dissolve that fits at this anchor."""
    room_before, room_after = transition_room(clips, at_frame, transitions)
    got_before = min(max(0, before), room_before)
    got_after  = min(max(0, after),  room_after)
    if got_before + got_after > 0:
        return got_before, got_after, None

    short = []
    if before and room_before <= 0:
        short.append('head')
    if after and room_after <= 0:
        short.append('tail')
    return 0, 0, ('Not enough frames on %s of clip(s).'
                  % ' or '.join(short or ['head', 'tail']))


def clamp_transition(clips, tr, transitions=()):
    """Clamp a transition to the available room; True if any length remains."""
    max_before, max_after = transition_room(clips, tr.at_frame, transitions)
    tr.before = min(tr.before, max_before)
    tr.after  = min(tr.after,  max_after)
    return tr.length > 0


def snapshot_transitions(layer):
    """Record each transition's position and adjoining clips."""
    return [(tr, tr.at_frame, tr.before, tr.after) + tr.sides(layer.clips)
            for tr in layer.transitions]


def restore_transitions(snap):
    """Restore each transition's anchor and reach from a snapshot."""
    for tr, at, before, after, _out, _inc in snap:
        tr.at_frame, tr.before, tr.after = at, before, after


def reanchor_transitions(layer, snap):
    """Move each transition back onto the join it belonged to."""
    for tr, _at, _b, _a, out, inc in snap:
        if out is not None and any(c is out for c in layer.clips):
            tr.at_frame = out.last_frame + 1
        elif inc is not None and any(c is inc for c in layer.clips):
            tr.at_frame = inc.first_frame
    return layer.transitions


def transition_anchors(clips):
    """Return every frame on this track where a transition could go."""
    if not clips:
        return []
    ordered = sorted(clips, key=lambda c: c.first_frame)
    anchors = {ordered[0].first_frame, ordered[-1].last_frame + 1}
    for a, b in zip(ordered, ordered[1:]):
        if a.last_frame + 1 == b.first_frame:
            anchors.add(b.first_frame)
        else:
            anchors.add(a.last_frame + 1)
            anchors.add(b.first_frame)
    return sorted(anchors)


def resolve_transition_drag(clips, tr, part, before0, after0, delta,
                            transitions=()):
    """Reshape a transition by dragging its head, tail or slide part."""
    max_b, max_a = transition_room(clips, tr.at_frame, transitions)

    if part == 'head':
        tr.before = max(0, min(max_b, before0 - delta))
        tr.after  = after0
    elif part == 'tail':
        tr.before = before0
        tr.after  = max(0, min(max_a, after0 + delta))
    else:
        length = min(before0 + after0, max_b + max_a)
        lo     = max(0, length - max_a)
        hi     = min(max_b, length)
        before = max(lo, min(hi, before0 - delta))
        tr.before, tr.after = before, length - before

    if tr.length < 1:
        if part == 'head':
            tr.before = max(1 - tr.after, tr.before)
        else:
            tr.after = max(1 - tr.before, tr.after)
    return tr


def _round_frames(value):
    """Round half away from zero to a whole frame."""
    return -int(_math.floor(-value + 0.5)) if value < 0 else \
        int(_math.floor(value + 0.5))


def source_anchor(clip):
    """Return the source frame a clip shows at its own first frame."""
    return clip.src_last if clip.speed < 0 else clip.src_first


def _sample_frame(value, speed):
    """Return the source frame a fractional lookup shows, truncated toward the anchor."""
    return int(_math.ceil(value)) if speed < 0 else int(_math.floor(value))


def tl_to_src(clip, frame):
    """Return the source frame `clip` shows at timeline frame `frame`."""
    return _sample_frame(source_anchor(clip)
                         + (frame - clip.first_frame) * clip.speed,
                         clip.speed)


def src_delta(clip, tl_delta):
    """Return the source frames `tl_delta` timeline frames spend for `clip`."""
    return _round_frames(tl_delta * abs(clip.speed))


def tl_delta(clip, src_delta_frames):
    """Return the timeline frames `src_delta_frames` source frames fill for `clip`."""
    if not clip.speed:
        return src_delta_frames
    return _round_frames(src_delta_frames / abs(clip.speed))


CLIP_MATERIAL_FIELDS = (
    'orig_src_first', 'orig_src_last',
    'offline', 'disabled', 'stale',
    'user_label', 'colour',
    'merge_op', 'merge_mix', 'alpha_mode', 'alpha_premult',
    'speed', 'retime_node', 'retime_substituted',
    'src_reel', 'src_name', 'src_path',
    'src_tc', 'src_frame', 'src_rate',
)


MATCH_EDIT_FIELDS = tuple(f for f in CLIP_MATERIAL_FIELDS
                          if f not in ('offline', 'stale', 'retime_substituted'))


def is_match_edit(left, right):
    """Return True if two clips are one clip cut in two (a through edit)."""
    if left is None or right is None or left is right:
        return False
    if left.retime_node or right.retime_node:
        return False
    if right.first_frame != left.last_frame + 1:
        return False
    if left.node_name != right.node_name:
        return False
    if right.src_first != left.src_last + 1:
        return False
    return all(getattr(left, f) == getattr(right, f) for f in MATCH_EDIT_FIELDS)


def match_seams(layer):
    """Return {frame: (left, right)} for every match edit on a layer."""
    out     = {}
    ordered = sorted(layer.clips, key=lambda c: c.first_frame)
    for left, right in zip(ordered, ordered[1:]):
        if is_match_edit(left, right):
            out[right.first_frame] = (left, right)
    return out


def join_match_edit(clips, left, right):
    """Join a match edit back into one clip; return True if joined."""
    if not is_match_edit(left, right):
        return False
    if left not in clips or right not in clips:
        return False
    left.last_frame = right.last_frame
    left.src_last   = right.src_last
    clips.remove(right)
    return True


def clip_like(source, first_frame, last_frame, src_first, src_last):
    """Return a new clip with `source`'s material at the given placement."""
    made = SMTLClip(source.node_name, source.label,
                    first_frame, last_frame,
                    src_first=src_first, src_last=src_last)
    for field in CLIP_MATERIAL_FIELDS:
        setattr(made, field, getattr(source, field))
    return made


def split_source(clip, head_len):
    """Return the (head, tail) source ranges for a cut after `head_len` frames."""
    if not clip.speed:
        return ((clip.src_first, clip.src_last),
                (clip.src_first, clip.src_last))
    total = clip.src_last - clip.src_first + 1
    if head_len <= 0:
        used = 0
    else:
        used = min(max(1, retime_source_span(clip, clip.speed, head_len)),
                   max(1, total - 1))
    if clip.speed < 0:
        return ((clip.src_last - used + 1, clip.src_last),
                (clip.src_first, clip.src_last - used))
    return ((clip.src_first, clip.src_first + used - 1),
            (clip.src_first + used, clip.src_last))


def split_tail(clip, at_frame):
    """Return the piece of `clip` from `at_frame` to its out point as a new clip."""
    _head, tail = split_source(clip, at_frame - clip.first_frame)
    return clip_like(clip, at_frame, clip.last_frame, tail[0], tail[1])


def split_clip(clip, at_frame):
    """Cut `clip` after `at_frame` and return the (left, right) pieces."""
    head, tail = split_source(clip, at_frame - clip.first_frame + 1)
    left = clip_like(clip, clip.first_frame, at_frame, head[0], head[1])
    return left, clip_like(clip, at_frame + 1, clip.last_frame,
                           tail[0], tail[1])


def handle_room(clip, source_frames):
    """Return `source_frames` of handle as timeline frames, floored at zero."""
    return max(0, tl_delta(clip, source_frames))


def clip_handles(clip):
    """Return (head, tail) source handle frames in play order."""
    below = clip.src_first - clip.orig_src_first
    above = clip.orig_src_last - clip.src_last
    return (above, below) if clip.speed < 0 else (below, above)


def resolve_shift_click(clips, anchor, hit):
    """Resolve a Shift+click into (clips to toggle, new anchor)."""
    if anchor is None or anchor not in clips:
        return [hit], hit
    lo, hi = sorted((anchor.first_frame, hit.first_frame))
    span = [c for c in clips
            if lo <= c.first_frame <= hi and c is not anchor]
    return span, None


def clip_span_and_ramp(layer, clip):
    """Return a clip's node reach and gate ramps across its transitions."""
    tl_first, tl_last   = clip.first_frame, clip.last_frame
    src_first, src_last = clip.src_first, clip.src_last
    ramp_up = ramp_down = None

    covered = any(o.first_frame == clip.last_frame + 1 for o in layer.clips)

    for tr in layer.transitions:
        if tr.at_frame == clip.first_frame:
            reach     = clip.first_frame - tr.first_frame
            tl_first -= reach
            if clip.speed < 0:
                src_last  += src_delta(clip, reach)
            else:
                src_first -= src_delta(clip, reach)
            ramp_up = (tr.first_frame, tr.last_frame, tr.curve)
        elif tr.at_frame == clip.last_frame + 1:
            reach    = tr.last_frame - clip.last_frame
            tl_last += reach
            if clip.speed < 0:
                src_first -= src_delta(clip, reach)
            else:
                src_last  += src_delta(clip, reach)
            if not covered:
                ramp_down = (tr.first_frame, tr.last_frame, tr.curve)

    return tl_first, tl_last, src_first, src_last, ramp_up, ramp_down


def prune_transitions(layer):
    """Drop transitions with no live anchor and clamp the rest."""
    live = set(transition_anchors(layer.clips))
    kept = []
    for tr in layer.transitions:
        if tr.at_frame not in live:
            continue
        if clamp_transition(layer.clips, tr, layer.transitions):
            kept.append(tr)
    layer.transitions = kept
    return layer.transitions


def starting_tracks():
    """Return the track list for an empty timeline."""
    return [SMTLLayer(next_layer_name([]))]


def next_layer_name(layers):
    """Return the lowest unused 'Track N' name."""
    taken = set()
    for layer in layers:
        m = _LAYER_NAME_RE.match(layer.name or '')
        if m:
            taken.add(int(m.group(1)))
    n = 1
    while n in taken:
        n += 1
    return f'Track {n}'


def resolve_overwrite(clips, incoming, protected=()):
    """Make `incoming` own its span on a track, trimming what it lands on."""
    removed, trimmed, split = [], [], []

    for other in list(clips):
        if other is incoming or other in protected:
            continue
        if other.last_frame < incoming.first_frame or other.first_frame > incoming.last_frame:
            continue

        covers_all = (incoming.first_frame <= other.first_frame
                      and incoming.last_frame >= other.last_frame)
        lands_inside = (other.first_frame < incoming.first_frame
                        and other.last_frame > incoming.last_frame)

        if covers_all:
            clips.remove(other)
            removed.append(other)

        elif lands_inside:
            right = split_tail(other, incoming.last_frame + 1)

            _trim_tail(other, incoming.first_frame - 1)
            clips.append(right)
            split.append((other, right))

        elif other.first_frame < incoming.first_frame:
            _trim_tail(other, incoming.first_frame - 1)
            trimmed.append(other)

        else:
            _trim_head(other, incoming.last_frame + 1)
            trimmed.append(other)

    return {'removed': removed, 'trimmed': trimmed, 'split': split}


def resolve_insert(clips, arrivals):
    """Make room for arriving clips by rippling later clips along."""
    arrivals = [c for c in arrivals if c in clips]
    if not arrivals:
        return {'split': [], 'shifted': []}

    protected = set(arrivals)
    insert_at = min(c.first_frame for c in arrivals)
    span      = max(c.last_frame for c in arrivals) - insert_at + 1

    split = []
    for other in list(clips):
        if other in protected:
            continue
        if other.first_frame < insert_at <= other.last_frame:
            right = split_tail(other, insert_at)
            _trim_tail(other, insert_at - 1)
            clips.append(right)
            split.append((other, right))

    shifted = []
    for other in clips:
        if other in protected:
            continue
        if other.first_frame >= insert_at:
            other.first_frame += span
            other.last_frame  += span
            shifted.append(other)

    return {'split': split, 'shifted': shifted}


def find_gap(clips, frame, track_first=None):
    """Return the empty span containing `frame`, or None."""
    if not clips:
        return None
    ordered = sorted(clips, key=lambda c: c.first_frame)

    if track_first is not None:
        head_last = ordered[0].first_frame - 1
        if track_first <= frame <= head_last:
            return track_first, head_last

    for left, right in zip(ordered, ordered[1:]):
        gap_first = left.last_frame + 1
        gap_last  = right.first_frame - 1
        if gap_first > gap_last:
            continue
        if gap_first <= frame <= gap_last:
            return gap_first, gap_last
    return None


def mark_clip_range(clips, frame, selection=(), track_first=None):
    """Return the (first, last, what) span Mark Clip should mark, or None."""
    if selection:
        return (min(c.first_frame for c in selection),
                max(c.last_frame for c in selection),
                'selection')
    hit = next((c for c in clips
                if c.first_frame <= frame <= c.last_frame), None)
    if hit is not None:
        return hit.first_frame, hit.last_frame, 'clip'
    gap = find_gap(clips, frame, track_first=track_first)
    if gap is not None:
        return gap[0], gap[1], 'gap'
    return None


def resolve_replace(clip, src_first, src_last, is_still=False):
    """Return the source range a replacement source should use for a clip."""
    need = clip.duration
    if is_still:
        return src_first, src_first + need - 1, 'still'

    head_over = max(0, clip.orig_src_first - clip.src_first)
    tail_over = max(0, clip.src_last - clip.orig_src_last)

    real_first = max(clip.src_first, clip.orig_src_first)
    real_last  = min(clip.src_last,  clip.orig_src_last)
    if src_first <= real_first and real_last <= src_last:
        return clip.src_first, clip.src_last, 'frames'

    shortfall = need - (src_last - src_first + 1)
    if shortfall <= 0:
        return src_first, src_first + need - 1, 'head'
    if shortfall > head_over + tail_over:
        return None
    start = src_first - min(head_over, shortfall)
    return start, start + need - 1, 'head'


def snap_targets(layers, exclude=(), bounds=None, cursor=None, marks=None):
    """Return the set of frames a dragged edge snaps to."""
    excl = set(exclude)
    frames = set()
    for layer in layers:
        if getattr(layer, 'hidden', False):
            continue
        for clip in layer.clips:
            if clip in excl:
                continue
            frames.add(clip.first_frame)
            frames.add(clip.last_frame + 1)

    if bounds is not None:
        tl_start, tl_end = bounds
        if tl_start is not None:
            frames.add(tl_start)
        if tl_end is not None:
            frames.add(tl_end + 1)
    if cursor is not None:
        frames.add(cursor)
    if marks is not None:
        mark_in, mark_out = marks
        if mark_in is not None:
            frames.add(mark_in)
        if mark_out is not None:
            frames.add(mark_out + 1)
    return frames


def nearest_snap(targets, first, last, zoom, threshold_px):
    """Return the offset that snaps the nearer end of a span to a target."""
    if not targets or zoom <= 0:
        return 0
    best_px, best_delta = threshold_px + 1.0, 0
    for edge in (first, last + 1):
        for target in sorted(targets):
            px = abs(target - edge) * zoom
            if px < best_px:
                best_px, best_delta = px, target - edge
    return best_delta


def layer_blocked(layer):
    """Return True when a layer refuses edits (locked or muted)."""
    return bool(getattr(layer, 'locked', False) or getattr(layer, 'hidden', False))


def fit_span(layers, tl_start, tl_end, margin=0.02):
    """Return the frame range Fit should show: the selection or the timeline."""
    picked = [c for lyr in layers
              for c in getattr(lyr, 'clips', ()) if getattr(c, 'selected', False)]
    if not picked:
        return tl_start, tl_end
    first = min(c.first_frame for c in picked)
    last  = max(c.last_frame for c in picked)
    pad   = 0 if margin <= 0 else max(1, int(round((last - first + 1) * margin)))
    return first - pad, last + pad


def removal_layers(layers, selected=(), sel_clip=None):
    """Return indices of layers a clip-driven Lift or Extract touches."""
    sel = set(selected)
    if not sel and sel_clip is not None:
        sel = {sel_clip}
    return [i for i, layer in enumerate(layers)
            if not layer_blocked(layer)
            and any(c in sel or getattr(c, 'selected', False)
                    for c in layer.clips)]


def range_layers(layers, selected=(), sel_clip=None, add_idx=0):
    """Return indices of layers a marked-range removal clears."""
    picked = removal_layers(layers, selected, sel_clip)
    if picked:
        return picked
    if 0 <= add_idx < len(layers) and not layer_blocked(layers[add_idx]):
        return [add_idx]
    return []


def removal_target(layers, selected=(), sel_clip=None, gap=None, marks=None,
                   prefer_range=False):
    """Return what Lift or Extract acts on: 'clips', 'gap', 'range' or None."""
    has_range = (marks is not None
                 and marks[0] is not None and marks[1] is not None)
    if prefer_range and has_range:
        return 'range'
    if removal_layers(layers, selected, sel_clip):
        return 'clips'
    if gap is not None:
        return 'gap'
    if has_range:
        return 'range'
    return None


def resolve_add_span(src_first, src_last, is_still, duration=None):
    """Return (src_last, length, orig_first, orig_last) for an added clip."""
    span = max(1, src_last - src_first + 1)
    orig_first, orig_last = src_first, src_last
    if duration is not None and int(duration) > 0:
        span     = int(duration)
        src_last = src_first + span - 1
    if is_still:
        orig_first = src_first - _STILL_HANDLE
        orig_last  = src_last  + _STILL_HANDLE
    return src_last, span, orig_first, orig_last


def resolve_roll(left, right, delta):
    """Roll the cut between two abutting clips; return the delta applied."""
    if delta > 0:
        room = min(delta,
                   handle_room(left, left.orig_src_last - left.src_last),
                   right.last_frame - right.first_frame)
        delta = max(0, room)
    elif delta < 0:
        room = min(-delta,
                   handle_room(right, right.src_first - right.orig_src_first),
                   left.last_frame - left.first_frame)
        delta = -max(0, room)

    if delta:
        left.last_frame   += delta
        left.src_last     += src_delta(left, delta)
        right.first_frame += delta
        right.src_first   += src_delta(right, delta)
    return delta


def resolve_ripple_trim(clips, clip, edge, delta):
    """Ripple-trim one edge of `clip`; return the track's change in length."""
    src_move = src_delta(clip, delta)
    was_last = clip.last_frame
    if edge == 'head':
        new_sf = min(max(min(clip.orig_src_first, clip.src_first),
                         clip.src_first + src_move),
                     clip.src_last)
        growth = clip.src_first - new_sf
        clip.src_first = new_sf
    else:
        new_sl = max(min(max(clip.orig_src_last, clip.src_last),
                         clip.src_last + src_move),
                     clip.src_first)
        growth = new_sl - clip.src_last
        clip.src_last = new_sl
    if not growth:
        return 0

    if clip.speed:
        clip.last_frame = clip.first_frame + retime_length(clip, clip.speed) - 1

    shift = clip.last_frame - was_last
    for other in clips:
        if other is not clip and other.first_frame > clip.first_frame:
            other.first_frame += shift
            other.last_frame  += shift
    return shift


def retime_render_class(kind, has_nukex):
    """Return (retime kind to build, substituted) for this machine."""
    if kind not in RETIME_NODES:
        return RETIME_TIMEWARP, False
    if kind in RETIME_NEEDS_NUKEX and not has_nukex:
        return RETIME_TIMEWARP, True
    return kind, False


def retime_lookup_keys(speed, tl_first, tl_last, src_first, src_last):
    """Return the retime curve's two (frame, lookup) keys."""
    y0 = tl_first + (src_last - src_first if speed < 0 else 0)
    y1 = y0 + (tl_last - tl_first) * speed
    return (tl_first, float(y0)), (tl_last, float(y1))


def retime_length(clip, speed):
    """Return `clip`'s timeline length at `speed`, keeping its source range."""
    if not speed:
        raise ValueError('a held clip has no length of its own')
    span = clip.src_last - clip.src_first + 1
    return max(1, _round_frames(span / abs(speed)))


def retime_source_span(clip, speed, length=None):
    """Return the source frames `clip` uses at `speed` over a given length."""
    if length is None:
        length = clip.last_frame - clip.first_frame + 1
    return max(1, _round_frames(length * abs(speed)))


def resolve_retime(clips, clip, speed, mode='resize', ripple=False):
    """Set a clip's speed, adjusting its length or source; return a summary."""
    out = {'resized': [], 'shifted': [], 'removed': [], 'trimmed': [],
           'split': [], 'wanted': None, 'clamped': False}
    if clip not in clips:
        return out

    was_len   = clip.last_frame - clip.first_frame + 1
    clip.speed = float(speed)
    if mode == 'resize' and not clip.speed:
        mode = 'keep'

    if mode == 'keep':
        need = retime_source_span(clip, clip.speed)
        if clip.speed < 0:
            wanted_first = clip.src_last - need + 1
            out['wanted'] = wanted_first
            clip.src_first = max(clip.orig_src_first, wanted_first)
            out['clamped'] = clip.src_first != wanted_first
        else:
            wanted_last = clip.src_first + need - 1
            out['wanted'] = wanted_last
            clip.src_last = min(clip.orig_src_last, wanted_last)
            out['clamped'] = clip.src_last != wanted_last
        if out['clamped'] and clip.speed:
            clip.last_frame = clip.first_frame + retime_length(clip, clip.speed) - 1
        out['resized'].append(clip)
        return out

    clip.last_frame = clip.first_frame + retime_length(clip, clip.speed) - 1
    out['resized'].append(clip)
    growth = (clip.last_frame - clip.first_frame + 1) - was_len
    if not growth:
        return out

    if ripple:
        for other in clips:
            if other is not clip and other.first_frame > clip.first_frame:
                other.first_frame += growth
                other.last_frame  += growth
                out['shifted'].append(other)
        return out

    if growth > 0:
        hit = resolve_overwrite(clips, clip)
        out['removed'] = hit['removed']
        out['trimmed'] = hit['trimmed']
        out['split']   = hit['split']
    return out


def resolve_slip(block, delta):
    """Slip a run of clips' source in place; return the delta applied."""
    if not block or not delta:
        return 0
    if delta > 0:
        delta = min(delta,
                    min(handle_room(c, c.orig_src_last - c.src_last)
                        for c in block))
    else:
        delta = -min(-delta,
                     min(handle_room(c, c.src_first - c.orig_src_first)
                         for c in block))
    for c in block:
        c.src_first += src_delta(c, delta)
        c.src_last  += src_delta(c, delta)
    return delta


def resolve_slide(clips, block, delta, track_first=None):
    """Slide a contiguous run along its track; return the delta applied."""
    if not block or not delta:
        return 0
    ordered = sorted(clips, key=lambda c: c.first_frame)
    first, last = block[0], block[-1]
    befores = [c for c in ordered if c.last_frame  < first.first_frame]
    afters  = [c for c in ordered if c.first_frame > last.last_frame]
    prev = befores[-1] if befores else None
    nxt  = afters[0]   if afters  else None
    gap_l = (first.first_frame - (prev.last_frame + 1)) if prev else None
    gap_r = (nxt.first_frame - (last.last_frame + 1))   if nxt  else None

    if delta > 0:
        if nxt is not None:
            delta = min(delta, gap_r + (nxt.last_frame - nxt.first_frame))
        if prev is not None and gap_l == 0:
            delta = min(delta,
                        handle_room(prev, prev.orig_src_last - prev.src_last))
        delta = max(0, delta)
    else:
        room = -delta
        if prev is not None:
            room = min(room, gap_l + (prev.last_frame - prev.first_frame))
        if nxt is not None and gap_r == 0:
            room = min(room,
                       handle_room(nxt, nxt.src_first - nxt.orig_src_first))
        if track_first is not None:
            room = min(room, first.first_frame - track_first)
        delta = -max(0, room)

    if not delta:
        return 0

    for c in block:
        c.first_frame += delta
        c.last_frame  += delta

    if delta > 0:
        if nxt is not None:
            take = max(0, delta - gap_r)
            if take:
                nxt.first_frame += take
                nxt.src_first   += src_delta(nxt, take)
        if prev is not None and gap_l == 0:
            prev.last_frame += delta
            prev.src_last   += src_delta(prev, delta)
    else:
        room = -delta
        if prev is not None:
            take = max(0, room - gap_l)
            if take:
                prev.last_frame -= take
                prev.src_last   -= src_delta(prev, take)
        if nxt is not None and gap_r == 0:
            nxt.first_frame -= room
            nxt.src_first   -= src_delta(nxt, room)
    return delta


def clear_range(clips, first_frame, last_frame):
    """Remove everything between two frames from a track, inclusive."""
    removed, trimmed, split = [], [], []
    if last_frame < first_frame:
        return {'removed': removed, 'trimmed': trimmed, 'split': split}

    for other in list(clips):
        if other.last_frame < first_frame or other.first_frame > last_frame:
            continue

        inside  = (other.first_frame >= first_frame and other.last_frame <= last_frame)
        spans   = (other.first_frame < first_frame and other.last_frame > last_frame)

        if inside:
            clips.remove(other)
            removed.append(other)

        elif spans:
            right = split_tail(other, last_frame + 1)
            _trim_tail(other, first_frame - 1)
            clips.append(right)
            split.append((other, right))

        elif other.first_frame < first_frame:
            _trim_tail(other, first_frame - 1)
            trimmed.append(other)

        else:
            _trim_head(other, last_frame + 1)
            trimmed.append(other)

    return {'removed': removed, 'trimmed': trimmed, 'split': split}


def close_span(clips, first_frame, last_frame):
    """Pull clips after an empty span back over it."""
    span = last_frame - first_frame + 1
    if span <= 0:
        return clips
    for clip in clips:
        if clip.first_frame > last_frame:
            clip.first_frame -= span
            clip.last_frame  -= span
    return clips


def close_gap(clips, removed):
    """Pull remaining clips back over the space removed clips left."""
    for clip in clips:
        shift = sum(r.duration for r in removed if r.last_frame < clip.first_frame)
        if shift:
            clip.first_frame -= shift
            clip.last_frame  -= shift
    return clips


_TC_DAY = 24 * 60 * 60


def nominal_rate(rate):
    """Return the whole-number frame rate a timecode counter counts in."""
    return max(1, int(round(float(rate))))


def is_drop_frame_rate(rate):
    """Return True at the NTSC rates that use drop-frame."""
    r = float(rate)
    return abs(r - 29.97) < 0.01 or abs(r - 59.94) < 0.01


def programme_start(rate):
    """Return the programme start timecode for a rate."""
    if is_drop_frame_rate(rate):
        return '01:00:00;00'
    return '01:00:00:00' if nominal_rate(rate) >= 30 else '10:00:00:00'


def frames_to_timecode(frames, rate, drop=False):
    """Return the timecode for a frame count, where 0 is 00:00:00:00."""
    fps = nominal_rate(rate)
    if not drop:
        frames %= fps * _TC_DAY
        return '%02d:%02d:%02d:%02d' % (
            frames // (fps * 3600), (frames // (fps * 60)) % 60,
            (frames // fps) % 60, frames % fps)

    dropped   = int(round(float(rate) * 0.0666666))
    per_10min = int(round(float(rate) * 600))
    per_min   = fps * 60 - dropped
    frames   %= per_10min * 6 * 24

    d, rem = divmod(frames, per_10min)
    frames += dropped * 9 * d + dropped * (max(0, rem - dropped) // per_min)

    return '%02d:%02d:%02d;%02d' % (
        frames // (fps * 3600), (frames // (fps * 60)) % 60,
        (frames // fps) % 60, frames % fps)


def timecode_to_frames(tc, rate, drop=None):
    """Return the frame count for a timecode string."""
    txt = str(tc).strip()
    if drop is None:
        drop = (';' in txt) or ('.' in txt)
    parts = txt.replace(';', ':').replace('.', ':').split(':')
    if len(parts) != 4:
        raise ValueError('not a timecode: %r' % (tc,))
    try:
        h, m, s, f = (int(p) for p in parts)
    except ValueError:
        raise ValueError('not a timecode: %r' % (tc,))

    fps = nominal_rate(rate)
    if f >= fps or s > 59 or m > 59 or h < 0 or m < 0 or s < 0 or f < 0:
        raise ValueError('timecode out of range at %s fps: %r' % (fps, tc))

    frames = ((h * 60 + m) * 60 + s) * fps + f
    if not drop:
        return frames
    dropped = int(round(float(rate) * 0.0666666))
    total_m = h * 60 + m
    return frames - dropped * (total_m - total_m // 10)


_TC_TERMS = _re.compile(r'[+-][^+-]*|^[^+-]+')


def parse_timecode_offset(text, rate):
    """Return a partial timecode offset as a frame count, read right to left."""
    fps   = nominal_rate(rate)
    parts = str(text).replace(';', ':').replace('.', ':').strip().split(':')
    if not 1 <= len(parts) <= 4 or not all(p.strip().isdigit() for p in parts):
        raise ValueError('not an offset: %r' % (text,))
    scale = (1, fps, fps * 60, fps * 3600)
    return sum(int(p) * scale[i] for i, p in enumerate(reversed(parts)))


def fill_timecode(text, rate, drop=None, current_tc=None):
    """Return a full timecode from a partial entry, filled from `current_tc`."""
    txt = ''.join(str(text or '').split())
    if not txt:
        raise ValueError('nothing entered')

    norm = txt.replace(';', ':').replace('.', ':')
    if ':' in norm:
        typed = norm.split(':')
    else:
        typed = [norm[max(0, i - 2):i]
                 for i in range(len(norm), 0, -2)][::-1]

    if not 1 <= len(typed) <= 4 or not all(p.isdigit() for p in typed):
        raise ValueError('not a timecode: %r' % (text,))

    if len(typed) == 4:
        fields = typed
    else:
        if current_tc is None:
            raise ValueError('nothing to fill %r from' % (text,))
        kept = str(current_tc).replace(';', ':').replace('.', ':').split(':')
        if len(kept) != 4:
            raise ValueError('not a timecode: %r' % (current_tc,))
        fields = kept[:4 - len(typed)] + typed

    try:
        h, m, sec, f = (int(p) for p in fields)
    except ValueError:
        raise ValueError('not a timecode: %r' % (text,))
    return '%02d:%02d:%02d%s%02d' % (h, m, sec, ';' if drop else ':', f)


def parse_timecode_entry(text, rate, drop=None, current=None):
    """Return the frame count for a typed timecode entry."""
    packed = ''.join(str(text or '').split())
    if not packed:
        raise ValueError('nothing entered')
    if drop is None:
        drop = is_drop_frame_rate(rate)

    tokens = _TC_TERMS.findall(packed)

    if tokens[0][0] in '+-':
        if current is None:
            raise ValueError('no timecode to offset from: %r' % (text,))
        total, terms = int(current), tokens
    else:
        head = fill_timecode(
            tokens[0], rate, drop,
            current_tc=(frames_to_timecode(int(current), rate, drop)
                        if current is not None else None))
        total, terms = timecode_to_frames(head, rate, drop), tokens[1:]

    for term in terms:
        step = parse_timecode_offset(term[1:], rate)
        total += step if term[0] == '+' else -step
    return total


_FRAMES_ENTRY_RE = _re.compile(r'^([+-]?\d+)\s*[fF]$')


def parse_start_entry(text, rate, drop=None, current=None):
    """Return the frame count for a start entry typed as timecode or frames."""
    packed = ''.join(str(text or '').split())
    m = _FRAMES_ENTRY_RE.match(packed)
    if m:
        return int(m.group(1))
    return parse_timecode_entry(text, rate, drop, current)


def source_timecode(src_frame, start_tc, start_src_frame, rate, drop=None):
    """Return the media's own timecode at a source frame, or None."""
    if not start_tc:
        return None
    if drop is None:
        drop = is_drop_frame_rate(rate)
    base = timecode_to_frames(start_tc, rate, drop)
    return frames_to_timecode(base + (int(src_frame) - int(start_src_frame)),
                              rate, drop)


def record_timecode(frame, programme_first, rate, start_tc=None, drop=None):
    """Return the record timecode for a timeline frame."""
    if drop is None:
        drop = is_drop_frame_rate(rate)
    base = timecode_to_frames(start_tc or programme_start(rate), rate, drop)
    return frames_to_timecode(base + (int(frame) - int(programme_first)),
                              rate, drop)


def _trim_tail(clip, new_last):
    """Trim a clip's out point back to `new_last`, moving its source."""
    delta = clip.last_frame - new_last
    if delta <= 0:
        return
    clip.last_frame = new_last
    cost = src_delta(clip, delta)
    if clip.speed < 0:
        clip.src_first = min(clip.orig_src_last, clip.src_first + cost)
    else:
        clip.src_last  = max(clip.orig_src_first, clip.src_last - cost)


def _trim_head(clip, new_first):
    """Trim a clip's in point forward to `new_first`, moving its source."""
    delta = new_first - clip.first_frame
    if delta <= 0:
        return
    clip.first_frame = new_first
    cost = src_delta(clip, delta)
    if clip.speed < 0:
        clip.src_last  = max(clip.orig_src_first, clip.src_last - cost)
    else:
        clip.src_first = min(clip.orig_src_last, clip.src_first + cost)

"""Nuke DAG interaction for SMTL; safe to import outside Nuke."""

import contextlib
import os
import re as _re
import sys as _sys
import json
import base64 as _base64
import zlib as _zlib
from pathlib import Path

_SMTL_DIR = os.path.dirname(os.path.abspath(__file__))
if _SMTL_DIR not in _sys.path:
    _sys.path.insert(0, _SMTL_DIR)

import smtl_theme as _theme
from smtl_constants import (
    _SMTL_GROUP_NAME, _SMTL_LAYER_SWITCH, _SMTL_SOLO_SWITCH,
    _SMTL_STATE_KNOB, _LAYER_H, _STILL_SECONDS, _NO_MEDIA,
)
from smtl_models import (
    SMTLClip, SMTLLayer, SMTLTransition, prune_transitions, new_clip_id,
    clip_span_and_ramp, starting_tracks,
    RETIME_TIMEWARP, RETIME_NODES,
    RETIME_CLASSES, RETIME_CURVE_KNOB, RETIME_MODE_KNOB,
    retime_render_class, retime_lookup_keys,
    ALPHA_USE, ALPHA_INVERT, ALPHA_IGNORE, ALPHA_REMOVE, ALPHA_WAS,
)


_VERBOSE = False


def _log(msg):
    """Print a progress message when _VERBOSE is on."""
    if _VERBOSE:
        print(msg)


@contextlib.contextmanager
def _undo_group(label):
    """Group Nuke changes inside the block into a single undo step."""
    if not _nuke_ok():
        yield
        return
    try:
        import nuke
        nuke.Undo.begin(label)
    except Exception:
        yield
        return
    try:
        yield
    except Exception:
        try:
            import nuke as _n
            _n.Undo.cancel()
        except Exception:
            pass
        raise
    else:
        try:
            import nuke as _n
            _n.Undo.end()
        except Exception:
            pass


@contextlib.contextmanager
def _no_undo():
    """Keep changes inside the block off the undo stack."""
    if not _nuke_ok():
        yield
        return
    try:
        import nuke
        nuke.Undo.disable()
    except Exception:
        yield
        return
    try:
        yield
    finally:
        try:
            import nuke as _n
            _n.Undo.enable()
        except Exception:
            pass


def _nuke_ok():
    """Return True if the `nuke` module is importable."""
    try:
        import nuke
        return True
    except ImportError:
        return False


def _root_first_frame():
    """Return the Nuke root first_frame, or 1 if unavailable."""
    try:
        import nuke
        return int(nuke.root()['first_frame'].value())
    except Exception:
        return 1


def _root_last_frame():
    """Return the Nuke root last_frame, or first+99 if unavailable."""
    try:
        import nuke
        return int(nuke.root()['last_frame'].value())
    except Exception:
        return _root_first_frame() + 99


def _get_or_create_smtl_group():
    """Return SMTL_Group, creating it with an Output1 node if needed."""
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            grp = nuke.nodes.Group(name=_SMTL_GROUP_NAME)
            grp['label'].setValue('SMTL\nEdit Group')
            _log(f'[SMTL] Created {_SMTL_GROUP_NAME} in DAG')
            grp.begin()
            try:
                nuke.nodes.Output(name='Output1', xpos=0, ypos=200)
                _log('[SMTL] Created Output1')
            finally:
                grp.end()

        _ensure_rebuild_knob(grp)
        return grp
    except Exception as e:
        print(f'[SMTL] Group node error: {e}')
        return None


_REBUILD_SCRIPT = """\
# SMTL — reload this group's timeline into the panel.
import os, sys, nuke


def _smtl_module():
    for mod in list(sys.modules.values()):
        path = getattr(mod, '__file__', '') or ''
        if (os.path.splitext(os.path.basename(path))[0] == 'smtl_panel'
                and hasattr(mod, 'reload_timeline')):
            return mod
    try:
        import smtl_panel
        return smtl_panel
    except ImportError:
        pass
    seen = set()
    for root in nuke.pluginPath():
        root = os.path.realpath(root or '')
        if not root or root in seen or not os.path.isdir(root):
            continue
        seen.add(root)
        depth0 = root.rstrip(os.sep).count(os.sep)
        for dirpath, dirnames, filenames in os.walk(root):
            if dirpath.count(os.sep) - depth0 >= 5:
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames
                           if not d.startswith('.') and d != '__pycache__']
            if 'smtl_panel.py' in filenames:
                sys.path.insert(0, dirpath)
                try:
                    import smtl_panel
                    return smtl_panel
                except ImportError:
                    sys.path.remove(dirpath)
    return None


_mod = _smtl_module()
if _mod is None:
    nuke.message(
        'SMTL could not be found in this session.\\n\\n'
        'The timeline is saved on this node and is not lost — it will open '
        'as soon as SMTL is on the Nuke plugin path here.')
else:
    _mod.reload_timeline()
"""


def _ensure_rebuild_knob(grp):
    """Add or refresh the Rebuild Timeline PyScript_Knob on grp."""
    try:
        import nuke
        knob = grp.knobs().get('smtl_rebuild')
        if knob is None:
            grp.addKnob(nuke.Text_Knob('smtl_div', ''))
            knob = nuke.PyScript_Knob(
                'smtl_rebuild', 'Rebuild Timeline', _REBUILD_SCRIPT)
            grp.addKnob(knob)
            print('[SMTL] Added Rebuild Timeline knob to SMTL_Group')
        elif knob.value() != _REBUILD_SCRIPT:
            knob.setValue(_REBUILD_SCRIPT)
            print('[SMTL] Updated the Rebuild Timeline knob to the portable script')
        knob.setTooltip(
            'Reload the SMTL panel from the saved state and rewire the group internals.\n'
            'Use this if the panel and the DAG have got out of sync, or after\n'
            'copying this group into another script.'
        )
    except Exception as e:
        print(f'[SMTL] Could not add rebuild knob: {e}')


def _knob(node, name, value):
    """Set a knob if it exists; log and return False if it does not."""
    k = node.knob(name)
    if k is None:
        print(f'[SMTL] {node.Class()} has no knob {name!r} — using its default')
        return False
    k.setValue(value)
    return True


_INTERP = {'step': 'CONSTANT', 'linear': 'LINEAR', 'smooth': 'HORIZONTAL'}


def _set_interpolation(knob, want):
    """Set each key's interpolation from `want`, a {frame: shape} map."""
    import nuke

    try:
        label = knob.node().name()
    except Exception:
        label = '?'

    try:
        curve = knob.animation(0)
        keys  = list(curve.keys())
    except Exception as e:
        print(f'[SMTL] {label}: no curve to interpolate ({e})')
        return

    grouped = {}
    for k in keys:
        shape = want.get(k.x)
        if shape is not None:
            grouped.setdefault(shape, []).append(k)

    for shape, group in grouped.items():
        flag = getattr(nuke, _INTERP[shape], None)
        if flag is None:
            print(f'[SMTL] {label}: this Nuke has no '
                 f'{_INTERP[shape]} — {shape} keys left as they are')
            continue
        try:
            curve.changeInterpolation(group, flag)
            continue
        except Exception as e:
            print(f'[SMTL] {label}: changeInterpolation {shape} failed ({e})'
                 f' — falling back to per-key')
        try:
            for k in group:
                k.interpolation = flag
        except Exception as e:
            print(f'[SMTL] {label}: could not set {shape} ({e})')


def _gate(knob, first, last, value=1.0, ramp_up=None, ramp_down=None):
    """Key a Merge's mix: `value` across first..last, 0 outside it."""
    def _shape(ramp):
        return 'smooth' if ramp[2] == 'smooth' else 'linear'

    keys = []
    if ramp_up:
        keys += [(ramp_up[0], 0.0, _shape(ramp_up)),
                 (ramp_up[1] + 1, value, _shape(ramp_up))]
    else:
        keys += [(first - 1, 0.0, 'step'), (first, value, 'step')]
    if ramp_down:
        keys += [(ramp_down[0], value, _shape(ramp_down)),
                 (ramp_down[1] + 1, 0.0, _shape(ramp_down))]
    else:
        keys += [(last, value, 'step'), (last + 1, 0.0, 'step')]

    knob.setAnimated()

    for f, v, _shp in keys:
        knob.setValueAt(v, f)

    want = {f for f, _v, _shp in keys}
    try:
        curve = knob.animation(0)
        stale = [k for k in curve.keys() if k.x not in want]
        if stale:
            curve.removeKey(stale)
    except Exception as e:
        _log(f'[SMTL] gate: could not clear the old keys ({e})')
    _set_interpolation(knob, {f: shp for f, _v, shp in keys})


def _have_nukex():
    """Return True when NukeX-only nodes can be rendered."""
    try:
        import nuke
        return bool(nuke.env.get('nukex'))
    except Exception:
        return False


def _kind_of(node):
    """Return the retime kind of an existing node, or TimeWarp if unknown."""
    cls = node.Class()
    for kind, name in RETIME_CLASSES.items():
        if name == cls:
            return kind
    return RETIME_TIMEWARP


def _make_retime(nuke, kind, name):
    """Build the retime node for `kind`, or return None if it cannot be made."""
    cls = RETIME_CLASSES.get(kind)
    if not cls:
        return None
    try:
        node = getattr(nuke.nodes, cls)(name=name)
    except Exception as e:
        _log(f'[SMTL] cannot create {cls} for {kind}: {e}')
        return None
    _default_filter(node)
    return node


RETIME_FILTERS = ('nearest', 'Nearest', 'None', 'none')


def _default_filter(node):
    """Set a freshly built retime node's filter to nearest, where it has one."""
    knob = node.knob('filter')
    if knob is None:
        return
    for want in RETIME_FILTERS:
        try:
            knob.setValue(want)
        except Exception:
            continue
        if str(knob.value()).strip().lower() == want.strip().lower():
            _log(f'[SMTL] {node.Class()} {node.name()}: filter {want!r}')
            return
    _log(f'[SMTL] {node.Class()} {node.name()}: no filter setting took — '
         f'it reads {str(node.knob("filter").value())!r}')


def _key_retime_curve(knob, x0, y0, x1, y1, reset=False):
    """Key the two ends of a retime curve, keeping user keys between them."""
    if reset:
        try:
            knob.clearAnimated()
        except Exception as e:
            print(f'[SMTL] retime curve: could not clear ({e})')

    knob.setAnimated()

    try:
        was = list(knob.animation(0).keys())
        old_edges = {float(min(was, key=lambda k: k.x).x),
                     float(max(was, key=lambda k: k.x).x)} if was else set()
    except Exception:
        old_edges = set()

    knob.setValueAt(y0, x0)
    knob.setValueAt(y1, x1)

    try:
        curve = knob.animation(0)
        keep  = {float(x0), float(x1)}
        drop  = [k for k in curve.keys()
                 if float(k.x) not in keep
                 and (float(k.x) in old_edges or k.x < x0 or k.x > x1)]
        if drop:
            curve.removeKey(drop)
            _log(f'[SMTL] retime curve: dropped {len(drop)} old key(s), '
                 f'kept the middle, re-keyed {x0}–{x1}')
    except Exception as e:
        print(f'[SMTL] retime curve: could not tidy ({e})')

    _set_interpolation(knob, {x0: 'linear', x1: 'linear'})
    _run_curve_on(knob)


RETIME_EXTRAPOLATION = (('BEFORE_LINEAR', min), ('AFTER_LINEAR', max))


def _run_curve_on(knob):
    """Set linear extrapolation on the end keys of a retime curve."""
    import nuke

    try:
        curve = knob.animation(0)
        keys  = list(curve.keys())
    except Exception as e:
        print(f'[SMTL] retime curve: no curve to extrapolate ({e})')
        return
    if not keys:
        return

    for flag_name, pick in RETIME_EXTRAPOLATION:
        flag = getattr(nuke, flag_name, None)
        if flag is None:
            print(f'[SMTL] this Nuke has no nuke.{flag_name} — '
                 f'that end of the retime curve stays flat')
            continue
        key = pick(keys, key=lambda k: k.x)
        try:
            curve.changeInterpolation([key], flag)
        except Exception as e:
            print(f'[SMTL] retime curve: {flag_name} at {key.x} '
                 f'refused ({e})')

    want = getattr(nuke, 'LINEAR', None)
    try:
        fresh = list(knob.animation(0).keys())
        for flag_name, pick in RETIME_EXTRAPOLATION:
            if getattr(nuke, flag_name, None) is None or want is None:
                continue
            key = pick(fresh, key=lambda k: k.x)
            if key.extrapolation != want:
                print(f'[SMTL] retime curve: asked for {flag_name} at '
                     f'{key.x}, extrapolation reads {key.extrapolation!r} '
                     f'rather than {want!r} — that end is still flat')
    except Exception as e:
        print(f'[SMTL] retime curve: cannot read extrapolation back ({e})')


def _retime_edges(clip):
    """Return a clip's TimeClip edge mode: hold if retimed, else black."""
    return 'hold' if clip.retime_node else 'black'


def _sync_retime_node(nuke, layer, clip, tc, reset=False):
    """Create, update or delete one clip's retime node; return it or None."""
    name = f'SMTL_RT_{clip.clip_id}'
    node = nuke.toNode(name)

    _knob(tc, 'before', _retime_edges(clip))
    _knob(tc, 'after',  _retime_edges(clip))

    if not clip.retime_node:
        clip.retime_substituted = False
        if node is not None:
            nuke.delete(node)
            _log(f'[SMTL] RT_{clip.clip_id}: removed')
        return None

    kind, substituted = retime_render_class(clip.retime_node, _have_nukex())
    wanted = RETIME_CLASSES.get(kind)

    if node is not None and node.Class() != wanted:
        fresh = _make_retime(nuke, kind, f'{name}_new')
        if fresh is None:
            print(f'[SMTL] RT_{clip.clip_id}: cannot build {wanted} — '
                 f'keeping the {node.Class()} that is there')
            kind, substituted = _kind_of(node), True
        else:
            _log(f'[SMTL] RT_{clip.clip_id}: {node.Class()} → {fresh.Class()}')
            nuke.delete(node)
            node = fresh
            node.setName(name)

    if node is None:
        node = _make_retime(nuke, kind, name)
        if node is None and kind != RETIME_TIMEWARP:
            kind, substituted = RETIME_TIMEWARP, True
            node = _make_retime(nuke, kind, name)
        if node is None:
            clip.retime_substituted = True
            return None
        if node.name() != name:
            print(f'[SMTL] RT: asked for {name}, got {node.name()} — '
                 f'something else is using that name')

    cls = node.Class()
    clip.retime_substituted = substituted
    if substituted:
        print(f'[SMTL] RT_{clip.clip_id}: {clip.retime_node} asked for, '
             f'{cls} built — the field still says {clip.retime_node}')

    node.setInput(0, tc)

    mode = RETIME_MODE_KNOB.get(kind)
    if mode:
        kname, want = mode
        if _knob(node, kname, want):
            got = node[kname].value()
            if str(got) != want:
                print(f'[SMTL] RT_{clip.clip_id}: {cls}.{kname} would not '
                     f'take {want!r} — it reads {got!r}, so the curve below '
                     f'may be on a knob nothing is looking at')

    (tl_first, tl_last, src_first, src_last,
     _up, _down) = clip_span_and_ramp(layer, clip)
    (x0, y0), (x1, y1) = retime_lookup_keys(clip.speed, tl_first, tl_last,
                                            src_first, src_last)
    kname = RETIME_CURVE_KNOB[kind]
    knob  = node.knob(kname)
    if knob is None:
        print(f'[SMTL] RT_{clip.clip_id}: {cls} has no knob {kname!r} — '
             f'the retime is not keyed')
    else:
        _key_retime_curve(knob, x0, y0, x1, y1, reset=reset)
        _log(f'[SMTL] RT_{clip.clip_id}: {cls} {kname} '
             f'({x0}, {y0}) → ({x1}, {y1})  speed={clip.speed}')

    if mode:
        kname_m, want_m = mode
        k_m = node.knob(kname_m)
        if k_m is not None and str(k_m.value()) != want_m:
            print(f'[SMTL] RT_{clip.clip_id}: {cls}.{kname_m} was set to '
                 f'{want_m!r} and now reads {k_m.value()!r} — something '
                 f'reset it, and the curve is on a knob nothing reads')

    return node


def _effective_which(active_idx, solo_idx, n_taps):
    """Return the LayerSwitch index: the soloed layer, else the active one."""
    idx = active_idx if solo_idx is None else solo_idx
    return min(max(0, idx), max(0, n_taps - 1))


ALPHA_MATHS = {
    ALPHA_USE:    ('a',     'a'),
    ALPHA_INVERT: ('(1-a)', '1-a'),
    ALPHA_IGNORE: (None,    '1'),
    ALPHA_REMOVE: (None,    '0'),
}


def _alpha_node(nuke, clip, xpos, ypos):
    """Return the alpha Expression node for a clip, or None if not needed."""
    mode = getattr(clip, 'alpha_mode', ALPHA_USE)
    mult, alpha = ALPHA_MATHS.get(mode, ALPHA_MATHS[ALPHA_USE])
    premult = bool(getattr(clip, 'alpha_premult', False)) and mult is not None
    if mode == ALPHA_USE and not premult:
        return None

    node = nuke.nodes.Expression(name='SMTL_A_%s' % clip.clip_id,
                                 xpos=int(xpos), ypos=int(ypos))
    for i, ch in enumerate(('red', 'green', 'blue')):
        _knob(node, 'channel%d' % i, ch)
        _knob(node, 'expr%d' % i,
              '%s*%s' % (ch[0], mult) if premult else ch[0])
    _knob(node, 'channel3', 'alpha')
    _knob(node, 'expr3', alpha)
    return node


def _input_name(node_name):
    """The name a source's Input takes inside the group."""
    return str(node_name).replace(' ', '_').replace('.', '_')


def _rebuild_group(layers, active_idx, solo_idx=None, offline=None):
    """Rebuild SMTL_Group internals from the timeline."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        grp = _get_or_create_smtl_group()
        if grp is None:
            return None

        grp.begin()
        try:
            out1 = nuke.toNode('Output1')
            if out1 is None:
                out1 = nuke.nodes.Output(name='Output1', xpos=0, ypos=300)
            out1.setInput(0, None)

            n_slots_before = grp.inputs()
            prev_ext = {}
            for _in_node in nuke.allNodes():
                if _in_node.Class() == 'Input':
                    _slot = int(_in_node['number'].value())
                    _ext  = grp.input(_slot)
                    if _ext is not None:
                        prev_ext[_in_node.name()] = _ext

            _live_retimes = {f'SMTL_RT_{c.clip_id}'
                             for l in layers for c in l.clips if c.retime_node}
            _legacy_prefixes = (
                'SMTL_TC_', 'SMTL_RM_', 'SMTL_M_', 'SMTL_Solo_',
                'SMTL_ClipMerge_', 'SMTL_ClipSwitch_',
                'SMTL_Merge_', 'SMTL_In_', 'SMTL_Append_', 'SMTL_FR_', 'SMTL_TO_',
                'SMTL_Const_', 'SMTL_TR_', 'SMTL_RT_', 'SMTL_A_',
            )
            _legacy_exact = {
                'SMTL_Switch', 'SMTL_Switch_B', 'SMTL_Black',
                _SMTL_LAYER_SWITCH, _SMTL_SOLO_SWITCH, 'Output2',
            }
            for node in list(nuke.allNodes()):
                n = node.name()
                if n == 'Output1' or n in _live_retimes:
                    continue
                if (node.Class() == 'Input'
                        or any(n.startswith(p) for p in _legacy_prefixes)
                        or n in _legacy_exact):
                    nuke.delete(node)

            NX         = 120
            NY         = 100
            SPINE_X    = 0
            LAYER_X    = 400
            LAYER_STEP = 380

            Y_INPUTS = -5 * NY

            all_clips    = []
            unique_names = []
            seen_names   = set()
            for layer in layers:
                for clip in sorted(layer.clips, key=lambda c: c.first_frame):
                    if clip.is_placeholder:
                        continue
                    if clip.node_name not in seen_names:
                        unique_names.append(clip.node_name)
                        seen_names.add(clip.node_name)
                    all_clips.append(clip)

            inp_x0   = LAYER_X
            node_inp = {}
            for slot, node_name in enumerate(unique_names):
                safe = _input_name(node_name)
                inp  = nuke.nodes.Input(
                    name=safe,
                    xpos=inp_x0 + slot * NX,
                    ypos=Y_INPUTS,
                )
                inp['number'].setValue(slot)
                node_inp[node_name] = inp
                _log(f'[SMTL] Input slot {slot}: {node_name}')

            read_offline = dict(offline or {})
            for layer in layers:
                for clip in layer.clips:
                    clip.offline = (True if clip.is_placeholder else
                                    read_offline.get(clip.node_name, False))

            offline_reads = {name for name, off in read_offline.items() if off}

            offline_const = {}
            for slot, node_name in enumerate(unique_names):
                if node_name in offline_reads:
                    safe = _input_name(node_name)
                    cx   = inp_x0 + slot * NX
                    const = nuke.nodes.Constant(
                        name=f'SMTL_Const_{safe}',
                        xpos=cx,
                        ypos=Y_INPUTS - NY,
                    )
                    const['color'].setValue(list(_theme.OFFLINE_CONST_RGBA))
                    offline_const[node_name] = const
                    _log(f'[SMTL] Constant placeholder for offline Read: {node_name}')

            spine = None
            taps  = []
            m_i   = 0

            for lyr_idx, layer in enumerate(layers):
                lx = LAYER_X + lyr_idx * LAYER_STEP

                sg = nuke.nodes.Multiply(name=f'SMTL_Solo_{lyr_idx}',
                                         xpos=SPINE_X - 150, ypos=m_i * NY)
                _knob(sg, 'channels', 'all')
                _knob(sg, 'value', 0.0)
                _knob(sg, 'disable', solo_idx != lyr_idx)
                sg.setInput(0, spine)
                spine = sg

                clips_sorted = sorted(layer.clips, key=lambda c: c.first_frame)
                for c_i, clip in enumerate(clips_sorted):
                    if clip.is_placeholder:
                        continue
                    (tl_first, tl_last, src_first, src_last,
                     ramp_up, ramp_down) = clip_span_and_ramp(layer, clip)

                    cx, my = lx + c_i * NX, m_i * NY

                    tc = nuke.nodes.TimeClip(name=f'SMTL_TC_{clip.clip_id}',
                                             xpos=cx, ypos=my - 3 * NY)
                    _knob(tc, 'first', src_first)
                    _knob(tc, 'last', src_last)
                    _knob(tc, 'before', _retime_edges(clip))
                    _knob(tc, 'after', _retime_edges(clip))
                    _knob(tc, 'frame_mode', 'start at')
                    _knob(tc, 'frame', str(tl_first))
                    tc.setInput(0, offline_const.get(clip.node_name)
                                or node_inp[clip.node_name])

                    rt = _sync_retime_node(nuke, layer, clip, tc)
                    if rt is not None:
                        rt.setInput(0, tc)
                        rt['xpos'].setValue(cx)
                        rt['ypos'].setValue(my - 2 * NY)

                    al = _alpha_node(nuke, clip,
                                     cx if rt is None else cx + 60,
                                     my - 2 * NY)
                    if al is not None:
                        al.setInput(0, rt if rt is not None else tc)

                    rm = nuke.nodes.Remove(name=f'SMTL_RM_{clip.clip_id}',
                                           xpos=cx, ypos=my - NY)
                    _knob(rm, 'operation', 'remove')
                    _knob(rm, 'channels', 'all')
                    _knob(rm, 'disable', not clip.disabled)
                    rm.setInput(0, al or rt or tc)

                    m = nuke.nodes.Merge2(name=f'SMTL_M_{clip.clip_id}',
                                          xpos=SPINE_X, ypos=my)
                    _knob(m, 'operation', clip.merge_op)
                    _knob(m, 'also_merge', 'all')
                    _knob(m, 'disable', layer.hidden)
                    m.setInput(0, spine)
                    m.setInput(1, rm)
                    _gate(m['mix'], tl_first, tl_last, clip.merge_mix,
                          ramp_up, ramp_down)

                    spine = m
                    m_i  += 1
                    _log(f'[SMTL] M_{clip.clip_id}: tl {tl_first}–{tl_last}  '
                         f'src {src_first}–{src_last}  op={clip.merge_op}'
                         + (f'  {clip.speed}x on {clip.retime_node}'
                            if clip.retime_node else '')
                         + (f'  up {ramp_up[0]}–{ramp_up[1]} {ramp_up[2]}'
                            if ramp_up else '')
                         + (f'  down {ramp_down[0]}–{ramp_down[1]} '
                            f'{ramp_down[2]}' if ramp_down else '')
                         + ('  [MUTED]' if clip.disabled else ''))

                taps.append(spine)

            lsw = nuke.nodes.Switch(name=_SMTL_LAYER_SWITCH,
                                    xpos=SPINE_X, ypos=(m_i + 1) * NY)
            for i, tap in enumerate(taps):
                lsw.setInput(i, tap)
            _knob(lsw, 'which', _effective_which(active_idx, solo_idx,
                                                 len(taps)))
            _log(f'[SMTL] LayerSwitch which='
                 f'{_effective_which(active_idx, solo_idx, len(taps))}')

            out1['xpos'].setValue(SPINE_X)
            out1['ypos'].setValue((m_i + 2) * NY)
            out1.setInput(0, lsw)

        finally:
            grp.end()

        for slot in range(max(n_slots_before, grp.inputs())):
            grp.setInput(slot, None)

        for slot, node_name in enumerate(unique_names):
            safe = _input_name(node_name)
            if safe in prev_ext:
                old_ext = prev_ext[safe]
                try:
                    old_ext.name()
                    grp.setInput(slot, old_ext)
                    _log(f'[SMTL] Restored slot {slot}: {node_name} → {old_ext.name()}')
                    continue
                except Exception:
                    pass
            read = nuke.toNode(node_name)
            if read is not None:
                grp.setInput(slot, read)
                _log(f'[SMTL] Wired slot {slot}: {node_name} → Group')
            else:
                _log(f'[SMTL] Read node not found: {node_name}')

    except Exception as e:
        import traceback
        print(f'[SMTL] Rebuild error: {e}')
        traceback.print_exc()
        return None


def default_transition_frames():
    """Return one second in frames at the script's nominal rate."""
    if not _nuke_ok():
        return 24
    try:
        import nuke
        return max(2, int(round(nuke.root()['fps'].value())))
    except Exception:
        return 24


def _sync_tc_start_positions(layers, moved_clips):
    """Sync TimeClip knobs for every clip on layers with a moved clip."""
    if not moved_clips:
        return
    affected_layer_idxs = {li for li, _ in moved_clips}
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            for lyr_idx in affected_layer_idxs:
                if lyr_idx >= len(layers):
                    continue
                clips_sorted = layers[lyr_idx].clips
                for clip in clips_sorted:
                    tc = nuke.toNode(f'SMTL_TC_{clip.clip_id}')
                    if tc is None:
                        continue
                    (tl_first, _tl_last, src_first, src_last,
                     _up, _down) = clip_span_and_ramp(layers[lyr_idx], clip)
                    _knob(tc, 'first', src_first)
                    _knob(tc, 'last', src_last)
                    _knob(tc, 'frame', str(tl_first))
                    _knob(tc, 'before', _retime_edges(clip))
                    _knob(tc, 'after', _retime_edges(clip))
                    _log(f'[SMTL] sync TC_{clip.clip_id}: '
                          f'src {src_first}–{src_last}  '
                          f'start_at={tl_first}')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _sync_tc_start_positions error: {e}')


def _set_clip_disabled_nuke(clip):
    """Set a clip's Remove node disable knob from its disabled state."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            rm = nuke.toNode(f'SMTL_RM_{clip.clip_id}')
            if rm is None:
                _log(f'[SMTL] _set_clip_disabled_nuke: '
                      f'SMTL_RM_{clip.clip_id} not found — rebuild needed first')
                return
            rm['disable'].setValue(not clip.disabled)
            state = 'disabled (all channels removed)' if clip.disabled else 'enabled (passthrough)'
            _log(f'[SMTL] RM_{clip.clip_id}: {state}')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _set_clip_disabled_nuke error: {e}')


def _layer_merges(nuke, layer):
    """Return every merge node belonging to a layer's clips."""
    out = []
    for clip in layer.clips:
        m = nuke.toNode(f'SMTL_M_{clip.clip_id}')
        if m is not None:
            out.append(m)
    return out


def _set_layer_merge_disabled(layers, layer_idx):
    """Disable or enable a layer's merges to hide or show it."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            layer   = layers[layer_idx]
            merges  = _layer_merges(nuke, layer)
            if not merges:
                _log(f'[SMTL] _set_layer_merge_disabled: no merges for layer '
                     f'{layer_idx} — rebuild needed first')
                return
            for m in merges:
                _knob(m, 'disable', layer.hidden)
            state = 'hidden' if layer.hidden else 'shown'
            _log(f'[SMTL] layer {layer_idx} {state} ({len(merges)} merges)')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _set_layer_merge_disabled error: {e}')


def _update_merge_settings(clips):
    """Push merge operation and mix onto the given clips' merges."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            touched = 0
            for layer, clip in clips:
                m = nuke.toNode(f'SMTL_M_{clip.clip_id}')
                if m is None:
                    continue
                (tl_first, tl_last, _sf, _sl,
                 ramp_up, ramp_down) = clip_span_and_ramp(layer, clip)
                _knob(m, 'operation', clip.merge_op)
                _knob(m, 'also_merge', 'all')
                _gate(m['mix'], tl_first, tl_last, clip.merge_mix,
                      ramp_up, ramp_down)
                touched += 1
                _log(f'[SMTL] M_{clip.clip_id}: op={clip.merge_op} '
                     f'mix={clip.merge_mix}')
            if not touched:
                _log('[SMTL] _update_merge_settings: nothing to update — '
                     'rebuild needed first')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _update_merge_settings error: {e}')


def _update_retime(clips, reset=False):
    """Sync each clip's retime node with the model without a rebuild."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            touched = 0
            for layer, clip in clips:
                tc = nuke.toNode(f'SMTL_TC_{clip.clip_id}')
                rm = nuke.toNode(f'SMTL_RM_{clip.clip_id}')
                if tc is None or rm is None:
                    _log(f'[SMTL] _update_retime: no chain for '
                         f'{clip.clip_id} — rebuild needed first')
                    continue
                rt = _sync_retime_node(nuke, layer, clip, tc, reset=reset)
                if rt is not None:
                    rt.setInput(0, tc)
                    rt['xpos'].setValue(int(tc['xpos'].value()))
                    rt['ypos'].setValue(int(tc['ypos'].value()) + 100)
                al = nuke.toNode(f'SMTL_A_{clip.clip_id}')
                if al is not None:
                    al.setInput(0, rt if rt is not None else tc)
                rm.setInput(0, al or rt or tc)
                touched += 1
            if not touched:
                _log('[SMTL] _update_retime: nothing to update — '
                     'rebuild needed first')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _update_retime error: {e}')


def _set_active_layer(layer_idx, layers):
    """Set the layer switch to the effective active layer."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            lsw = nuke.toNode(_SMTL_LAYER_SWITCH)
            if lsw is None:
                _log('[SMTL] _set_active_layer: LayerSwitch not found — '
                     'rebuild needed first')
                return
            solo_idx = next((i for i, l in enumerate(layers) if l.solo), None)
            which = _effective_which(layer_idx, solo_idx, len(layers))
            _knob(lsw, 'which', which)
            _log(f'[SMTL] LayerSwitch which → {which}')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _set_active_layer error: {e}')


def _set_solo_switch(solo_idx, active_idx, layers):
    """Set the solo gates and layer switch for a soloed layer or none."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return
        grp.begin()
        try:
            found = 0
            for i in range(len(layers)):
                sg = nuke.toNode(f'SMTL_Solo_{i}')
                if sg is None:
                    continue
                _knob(sg, 'disable', solo_idx != i)
                found += 1
            lsw = nuke.toNode(_SMTL_LAYER_SWITCH)
            if lsw is not None:
                _knob(lsw, 'which',
                      _effective_which(active_idx, solo_idx, len(layers)))
            if not found:
                _log('[SMTL] _set_solo_switch: no solo gates — '
                     'rebuild needed first')
                return
            _log(f'[SMTL] solo → {solo_idx} ({found} gates)')
        finally:
            grp.end()
    except Exception as e:
        print(f'[SMTL] _set_solo_switch error: {e}')


def link_viewer_if_needed():
    """Create the SMTL edit viewer if missing; return True if created."""
    if not _nuke_ok():
        return False
    try:
        import nuke
        if nuke.toNode('SMTL_EditViewer') is not None:
            return False
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return False
        viewer = nuke.nodes.Viewer(
            name='SMTL_EditViewer',
            xpos=grp.xpos(),
            ypos=grp.ypos() + 150,
        )
        viewer.setInput(0, grp)
        try:
            nuke.show(viewer)
        except Exception as e:
            _log(f'[SMTL] Could not raise the edit viewer ({e})')
        _log('[SMTL] Created SMTL_EditViewer wired to SMTL_Group')
        return True
    except Exception as e:
        _log(f'[SMTL] Could not make the edit viewer ({e})')
        return False


SOURCE_STEP_X = 100
SOURCE_STEP_Y = 100
SOURCE_GAP    = 30
NODE_W        = 80
NODE_H        = 78
VIEWER_DROP   = 150


def _layout_plan(roots, centre_x, group_y,
                 step_x=SOURCE_STEP_X, step_y=SOURCE_STEP_Y):
    """Return `{name: (centre_x, y)}` for source nodes and their chains."""
    widths = [max(1, len(chains)) for _n, chains in roots]
    slots  = sum(widths) or 1
    depth  = max([len(ch) for _n, chains in roots for ch in chains] or [0])
    row_y  = group_y - (depth + 1) * step_y
    x0     = centre_x - (slots - 1) * step_x / 2.0

    out  = {}
    slot = 0
    for (name, chains), width in zip(roots, widths):
        out[name] = (x0 + (slot + (width - 1) / 2.0) * step_x, row_y)
        for k, chain in enumerate(chains):
            for level, below in enumerate(chain, start=1):
                out[below] = (x0 + (slot + k) * step_x, row_y + level * step_y)
        slot += width
    return out


def _screen_w(node):
    """Return a node's drawn width, or a default before it is drawn."""
    try:
        return int(node.screenWidth()) or NODE_W
    except Exception:
        return NODE_W


def _screen_h(node):
    """Return a node's drawn height, or a default before it is drawn."""
    try:
        return int(node.screenHeight()) or NODE_H
    except Exception:
        return NODE_H


def _steps(nodes):
    """Return (x, y) layout steps that clear the largest given node."""
    wide = max([_screen_w(n) for n in nodes] or [NODE_W])
    tall = max([_screen_h(n) for n in nodes] or [NODE_H])
    return (max(SOURCE_STEP_X, wide + SOURCE_GAP),
            max(SOURCE_STEP_Y, tall + SOURCE_GAP))


def tidy_sources(only=None):
    """Lay the group's source nodes out in a row above it."""
    if not _nuke_ok():
        return False
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return False

        roots, chains_of = [], {}
        for i in range(grp.inputs()):
            node = grp.input(i)
            if node is None:
                continue
            chain, guard = [], set()
            walk = node
            while walk is not None and walk.name() not in guard:
                guard.add(walk.name())
                up = walk.input(0)
                if up is None:
                    break
                chain.append(walk.name())
                walk = up
            chain.reverse()
            key = walk.name()
            if key not in chains_of:
                chains_of[key] = []
                roots.append((key, chains_of[key]))
            if chain and chain not in chains_of[key]:
                chains_of[key].append(chain)
        if not roots:
            return False

        wanted = None if only is None else set(only)
        bottom = grp.ypos()
        if wanted is not None:
            mine = [(name, chains) for name, chains in roots if name in wanted]
            if not mine:
                return False
            theirs = [n for name, chains in roots if name not in wanted
                      for n in [name] + [x for ch in chains for x in ch]]
            tops = []
            for name in theirs:
                node = nuke.toNode(name)
                if node is not None:
                    tops.append(node.ypos())
            if tops:
                bottom = min(tops)
            roots = mine

        placing = [n for n in
                   [nuke.toNode(x) for name, chains in roots
                    for x in [name] + [y for ch in chains for y in ch]]
                   if n is not None] + [grp]
        step_x, step_y = _steps(placing)

        centre_x = grp.xpos() + _screen_w(grp) / 2.0
        for name, (cx, y) in _layout_plan(roots, centre_x, bottom,
                                          step_x, step_y).items():
            node = nuke.toNode(name)
            if node is None:
                continue
            node['xpos'].setValue(int(round(cx - _screen_w(node) / 2.0)))
            node['ypos'].setValue(int(round(y)))

        viewer = nuke.toNode('SMTL_EditViewer') if wanted is None else None
        if viewer is not None:
            viewer['xpos'].setValue(
                int(round(centre_x - _screen_w(viewer) / 2.0)))
            viewer['ypos'].setValue(int(grp.ypos() + VIEWER_DROP))
        return True
    except Exception as e:
        _log(f'[SMTL] Could not tidy the sources ({e})')
        return False


def _connect_viewer_to_group():
    """Create, wire and show SMTL's edit viewer; return a status string."""
    if not _nuke_ok():
        return 'Nuke not available.'
    try:
        import nuke
        grp = _get_or_create_smtl_group()
        if grp is None:
            return 'Could not create SMTL_Group.'

        viewer = nuke.toNode('SMTL_EditViewer')
        if viewer is None:
            link_viewer_if_needed()
            viewer = nuke.toNode('SMTL_EditViewer')
        if viewer is None:
            return (f'{_SMTL_GROUP_NAME} ready.  '
                    f'Connect a Viewer to it, then add clips.')

        if viewer.input(0) is not grp:
            viewer.setInput(0, grp)
        try:
            nuke.show(viewer)
        except Exception as e:
            _log(f'[SMTL] Could not raise the edit viewer ({e})')
        return (f'{viewer.name()} showing {_SMTL_GROUP_NAME}.  '
                f'Switch = active layer.  I/O keys set mark range.')
    except Exception as e:
        return f'Setup error: {e}'


def _delete_smtl_nodes():
    """Delete SMTL_Group and SMTL_EditViewer from the DAG."""
    if not _nuke_ok():
        return
    try:
        import nuke
        for name in ('SMTL_EditViewer', _SMTL_GROUP_NAME):
            node = nuke.toNode(name)
            if node is not None:
                nuke.delete(node)
                print(f'[SMTL] Deleted {name}')
    except Exception as e:
        print(f'[SMTL] Delete nodes error: {e}')


_CLIP_DEFAULTS = {
    'disabled': False, 'user_label': '', 'colour': '',
    'merge_op': 'over', 'merge_mix': 1.0,
    'alpha_mode': 'use', 'alpha_premult': False,
    'speed': 1.0, 'retime_node': None,
    'src_reel': '', 'src_name': '', 'src_path': '', 'src_tc': '',
    'src_frame': None, 'src_rate': 0.0,
}


def _strip_defaults(state):
    """The state with every value the loader would supply anyway left out."""
    out = {k: v for k, v in state.items() if v is not None}
    layers = []
    for ld in state.get('layers', []):
        ld = {k: v for k, v in ld.items()
              if not (k in ('locked', 'solo', 'hidden') and v is False)
              and not (k == 'height' and v == _LAYER_H)}
        clips = []
        for cd in ld.get('clips', []):
            cd = {k: v for k, v in cd.items()
                  if not (k in _CLIP_DEFAULTS and v == _CLIP_DEFAULTS[k]
                          and type(v) is type(_CLIP_DEFAULTS[k]))}
            if cd.get('label') == cd.get('node_name'):
                cd.pop('label', None)
            if cd.get('orig_src_first') == cd.get('src_first'):
                cd.pop('orig_src_first', None)
            if cd.get('orig_src_last') == cd.get('src_last'):
                cd.pop('orig_src_last', None)
            clips.append(cd)
        ld['clips'] = clips
        ld['transitions'] = [{k: v for k, v in td.items()
                              if not (k == 'curve' and v == 'linear')}
                             for td in ld.get('transitions', [])]
        layers.append(ld)
    out['layers'] = layers
    return out


def _encode_state(state):
    """Version 2: defaults left out, compact JSON, zlib, base64."""
    state = dict(_strip_defaults(state), version=2)
    packed = json.dumps(state, separators=(',', ':')).encode('utf-8')
    return _base64.b64encode(_zlib.compress(packed, 9)).decode('ascii')


def _save_timeline_to_node(layers, active_idx, add_idx, cursor_frame,
                            timeline_start=None, timeline_end=None,
                            mark_in=None, mark_out=None, dissolve=None,
                            ghost_in=None, ghost_out=None):
    """Serialise timeline state into a hidden knob on SMTL_Group."""
    if not _nuke_ok():
        return
    try:
        import nuke
        grp = _get_or_create_smtl_group()
        if grp is None:
            return

        if _SMTL_STATE_KNOB not in grp.knobs():
            k = nuke.String_Knob(_SMTL_STATE_KNOB, 'SMTL State')
            k.setFlag(nuke.INVISIBLE)
            grp.addKnob(k)

        state = {
            'version':        1,
            'active_idx':     active_idx,
            'add_idx':        add_idx,
            'cursor_frame':   cursor_frame,
            'timeline_start': timeline_start,
            'timeline_end':   timeline_end,
            'mark_in':        mark_in,
            'mark_out':       mark_out,
            'ghost_in':       ghost_in,
            'ghost_out':      ghost_out,
            'dissolve':       dissolve or {},
            'layers': [
                {
                    'name':      layer.name,
                    'locked':    layer.locked,
                    'solo':      layer.solo,
                    'hidden':    layer.hidden,
                    'height':    layer.height,
                    'clips': [
                        {
                            'clip_id':        clip.clip_id,
                            'node_name':      clip.node_name,
                            'label':          clip.label,
                            'first_frame':    clip.first_frame,
                            'last_frame':     clip.last_frame,
                            'src_first':      clip.src_first,
                            'src_last':       clip.src_last,
                            'orig_src_first': clip.orig_src_first,
                            'orig_src_last':  clip.orig_src_last,
                            'disabled':       clip.disabled,
                            'user_label':     clip.user_label,
                            'colour':         clip.colour,
                            'merge_op':       clip.merge_op,
                            'merge_mix':      clip.merge_mix,
                            'alpha_mode':     clip.alpha_mode,
                            'alpha_premult':  clip.alpha_premult,
                            'speed':          clip.speed,
                            'retime_node':    clip.retime_node,
                            'src_reel':       clip.src_reel,
                            'src_name':       clip.src_name,
                            'src_path':       clip.src_path,
                            'src_tc':         clip.src_tc,
                            'src_frame':      clip.src_frame,
                            'src_rate':       clip.src_rate,
                        }
                        for clip in layer.clips
                    ],
                    'transitions': [
                        {'at_frame': tr.at_frame,
                         'before':   tr.before,
                         'after':    tr.after,
                         'curve':    tr.curve}
                        for tr in layer.transitions
                    ],
                }
                for layer in layers
            ],
        }
        grp[_SMTL_STATE_KNOB].setValue(_encode_state(state))
        total_clips = sum(len(l.clips) for l in layers)
        _log(f'[SMTL] State saved: {len(layers)} layer(s), {total_clips} clip(s)')
    except Exception as e:
        print(f'[SMTL] Save error: {e}')


def _decode_state(raw):
    """The saved timeline as a dict: version 1 is JSON, version 2 is the same JSON compressed (zlib, then base64)."""
    raw = raw.strip()
    if not raw.startswith('{'):
        raw = _zlib.decompress(_base64.b64decode(raw)).decode('utf-8')
    return json.loads(raw)


def _load_timeline_from_node():
    """Load timeline state from SMTL_Group's state knob, or return None."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None or _SMTL_STATE_KNOB not in grp.knobs():
            return None

        raw = grp[_SMTL_STATE_KNOB].value()
        if not raw:
            return None

        state = _decode_state(raw)
        if state.get('version', 0) not in (1, 2):
            print(f'[SMTL] Unknown state version: {state.get("version")} — skipping load')
            return None

        layers = []
        _seen_clip_ids = set()
        for layer_data in state.get('layers', []):
            layer           = SMTLLayer()
            layer.name      = layer_data.get('name') or f'Track {len(layers) + 1}'
            layer.locked    = bool(layer_data.get('locked', False))
            layer.solo      = bool(layer_data.get('solo',   False))
            layer.hidden    = bool(layer_data.get('hidden', False))
            layer.height    = int(layer_data.get('height',  _LAYER_H))
            for cd in layer_data.get('clips', []):
                _nm = cd.get('node_name') or ''
                if _nm != _NO_MEDIA and nuke.toNode(_nm) is None:
                    print(f'[SMTL] Load: Read node "{_nm}" not found — skipped')
                    continue
                clip = SMTLClip(
                    node_name   = cd.get('node_name') or '',
                    label       = cd.get('label') or cd.get('node_name') or '',
                    first_frame = int(cd.get('first_frame', 0)),
                    last_frame  = int(cd.get('last_frame', 0)),
                    src_first   = cd.get('src_first'),
                    src_last    = cd.get('src_last'),
                )
                saved_id = str(cd.get('clip_id', '') or '')
                if not saved_id or saved_id in _seen_clip_ids:
                    saved_id = new_clip_id()
                _seen_clip_ids.add(saved_id)
                clip.clip_id = saved_id
                clip.orig_src_first = cd.get('orig_src_first', clip.src_first)
                clip.orig_src_last  = cd.get('orig_src_last',  clip.src_last)
                clip.offline  = _check_clip_offline(clip)
                clip.disabled = bool(cd.get('disabled', False))
                clip.user_label = str(cd.get('user_label', '') or '')
                clip.colour     = str(cd.get('colour', '') or '')
                clip.merge_op   = str(cd.get('merge_op', 'over') or 'over')
                clip.merge_mix  = float(cd.get('merge_mix', 1.0))
                _mode = str(cd.get('alpha_mode', ALPHA_USE) or ALPHA_USE)
                clip.alpha_mode    = ALPHA_WAS.get(_mode, _mode)
                clip.alpha_premult = bool(cd.get('alpha_premult', False))
                clip.speed      = float(cd.get('speed', 1.0))
                node = cd.get('retime_node') or None
                if node is not None:
                    node = str(node)
                    if node not in RETIME_NODES:
                        _log(f'[SMTL] {cd.get("node_name")}: unknown retime '
                             f'node {node!r} — loaded as {RETIME_TIMEWARP}')
                        node = RETIME_TIMEWARP
                clip.retime_node = node
                clip.src_reel     = str(cd.get('src_reel', '') or '')
                clip.src_name     = str(cd.get('src_name', '') or '')
                clip.src_path     = str(cd.get('src_path', '') or '')
                clip.src_tc       = str(cd.get('src_tc', '') or '')
                _sf = cd.get('src_frame')
                clip.src_frame    = None if _sf is None else int(_sf)
                clip.src_rate     = float(cd.get('src_rate', 0.0) or 0.0)
                layer.clips.append(clip)
            for td in layer_data.get('transitions', []):
                if 'before' in td:
                    layer.transitions.append(SMTLTransition(
                        td['at_frame'], td['before'], td['after'],
                        td.get('curve', 'linear')))
                else:
                    layer.transitions.append(
                        SMTLTransition(td['at_frame'], td.get('length', 0)))
            prune_transitions(layer)
            layers.append(layer)

        if not layers:
            layers = starting_tracks()

        n          = len(layers)
        active_idx = max(0, min(state.get('active_idx', 0), n - 1))
        add_idx    = max(0, min(state.get('add_idx',    0), n - 1))
        cursor_frame   = state.get('cursor_frame')
        timeline_start = state.get('timeline_start')
        timeline_end   = state.get('timeline_end')
        mark_in        = state.get('mark_in')
        mark_out       = state.get('mark_out')
        ghost_in       = state.get('ghost_in')
        ghost_out      = state.get('ghost_out')

        total_clips = sum(len(l.clips) for l in layers)
        print(f'[SMTL] State loaded: {n} layer(s), {total_clips} clip(s)')
        return (layers, active_idx, add_idx, cursor_frame,
                timeline_start, timeline_end, mark_in, mark_out,
                state.get('dissolve') or {}, ghost_in, ghost_out)
    except Exception as e:
        print(f'[SMTL] Load error: {e}')
        return None


def _read_node_info(node):
    """Return (label, first_frame, last_frame) for a node."""
    label = node.name()
    try:
        f = node.knob('file')
        if f is not None:
            label = Path(f.value()).stem or node.name()
    except Exception as e:
        _log(f'[SMTL] {node.name()}: no file knob to name from ({e})')
    try:
        return label, int(node.firstFrame()), int(node.lastFrame())
    except Exception:
        print(f'[SMTL] {node.name()}: no frame range — assuming 1-100')
        return label, 1, 100


_ALWAYS_STILL = {'FrameHold'}


def make_freeze_node(source_name, src_frame, label=None):
    """Create a named FrameHold on a source node at a frame in the main DAG."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        src = nuke.toNode(source_name)
        if src is None:
            return None
        hold = nuke.nodes.FrameHold(
            xpos=int(src['xpos'].value()) + 110,
            ypos=int(src['ypos'].value()) + 60,
        )
        hold.setInput(0, src)
        hold['first_frame'].setValue(int(src_frame))
        safe = ''.join(c if c.isalnum() else '_' for c in source_name)
        want = f'Freeze_{safe}_{int(src_frame)}'
        if nuke.toNode(want) is None:
            hold.setName(want)
        hold['label'].setValue(f'{label or source_name}\nfreeze {int(src_frame)}')
        for n in nuke.selectedNodes():
            n['selected'].setValue(False)
        hold['selected'].setValue(True)
        _log(f'[SMTL] Freeze: {hold.name()} holds {source_name} at {src_frame}')
        return hold
    except Exception as e:
        print(f'[SMTL] Freeze error: {e}')
        return None


def _has_media_upstream(node, depth=0, seen=None):
    """Return True if any file-based source feeds this node."""
    if depth > 50:
        return False
    if seen is None:
        seen = set()
    key = node.fullName()
    if key in seen:
        return False
    seen.add(key)
    try:
        f = node.knob('file')
        if f is not None and str(f.value()).strip():
            return True
        for dep in node.dependencies():
            if _has_media_upstream(dep, depth + 1, seen):
                return True
    except Exception as e:
        _log(f'[SMTL] {node.name()}: cannot walk upstream ({e})')
    return False


def _node_span(node):
    """Return (label, src_first, src_last, is_still) for a node's clip."""
    _hold_single_frame_read(node)
    label, first, last = _read_node_info(node)
    n = max(1, _STILL_SECONDS * default_transition_frames())
    try:
        if node.Class() in _ALWAYS_STILL:
            return label, first, first + n - 1, True
    except Exception as e:
        _log(f'[SMTL] {node.name()}: cannot read Class() ({e})')
    if last == first:
        return label, first, first + n - 1, True
    if not _has_media_upstream(node):
        return label, first, first + n - 1, True
    return label, first, last, False


def _hold_single_frame_read(node):
    """Set a one-frame Read's before/after to hold; return True if changed."""
    if not _nuke_ok():
        return False
    try:
        if node.Class() != 'Read':
            return False
        if int(node.firstFrame()) != int(node.lastFrame()):
            return False
        changed = False
        for knob_name in ('before', 'after'):
            k = node.knob(knob_name)
            if k is not None and k.value() == 'black':
                k.setValue('hold')
                changed = True
        if changed:
            _log(f'[SMTL] {node.name()}: single frame, set before/after to hold')
        return changed
    except Exception as e:
        print(f'[SMTL] hold single frame error: {e}')
        return False


def show_dissolve_node(layers, lyr_idx, t_idx):
    """Open the merge node whose mix curve is this dissolve."""
    if not _nuke_ok():
        return None
    if not (0 <= lyr_idx < len(layers)):
        return None
    layer = layers[lyr_idx]
    if not (0 <= t_idx < len(layer.transitions)):
        return None
    tr = layer.transitions[t_idx]

    clip = next((c for c in layer.clips if c.first_frame == tr.at_frame), None)
    if clip is None:
        clip = next((c for c in layer.clips
                     if c.last_frame + 1 == tr.at_frame), None)
    if clip is None:
        return None

    try:
        import nuke
        node = nuke.toNode(f'{_SMTL_GROUP_NAME}.SMTL_M_{clip.clip_id}')
        if node is None:
            return None
        node.showControlPanel()
        return node
    except Exception as e:
        print(f'[SMTL] show_dissolve_node error: {e}')
        return None

def show_retime_node(clip):
    """Open the clip's retime node control panel."""
    if not _nuke_ok() or clip is None:
        return None
    try:
        import nuke
        node = nuke.toNode(f'{_SMTL_GROUP_NAME}.SMTL_RT_{clip.clip_id}')
        if node is None:
            return None
        node.showControlPanel()
        return node
    except Exception as e:
        print(f'[SMTL] show_retime_node error: {e}')
        return None


def select_nodes_by_name(names):
    """Select exactly the named nodes; return the number selected."""
    if not _nuke_ok():
        return 0
    try:
        import nuke
        wanted = set(names)
        count  = 0
        for n in nuke.allNodes():
            want = n.name() in wanted
            if want:
                count += 1
            if n['selected'].value() != want:
                n['selected'].setValue(want)
        return count
    except Exception as e:
        print(f'[SMTL] Select nodes error: {e}')
        return 0


def read_state_blob():
    """Return the raw smtl_state string, or None."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None or _SMTL_STATE_KNOB not in grp.knobs():
            return None
        return grp[_SMTL_STATE_KNOB].value()
    except Exception:
        return None


def feeding_now(node_name):
    """Return the name of the node on a source's group input, or None."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        grp = nuke.toNode(_SMTL_GROUP_NAME)
        if grp is None:
            return None
        safe = _input_name(node_name)
        grp.begin()
        try:
            inp = nuke.toNode(safe)
            if inp is None or inp.Class() != 'Input':
                return None
            slot = int(inp['number'].value())
        finally:
            grp.end()
        ext = grp.input(slot)
        if ext is None:
            return None
        name = ext.name()
        return None if name == node_name else name
    except Exception as e:
        _log(f'[SMTL] feeding_now {node_name}: {e}')
        return None


def _missing_node_names(names):
    """Return the node names not found in the DAG."""
    if not _nuke_ok():
        return set()
    try:
        import nuke
        return {n for n in names if nuke.toNode(n) is None}
    except Exception:
        return set()


def _check_clip_offline_by_name(node_name):
    """Return True if the named node is a placeholder, missing or in error."""
    if node_name == _NO_MEDIA:
        return True
    if not _nuke_ok():
        return False
    try:
        import nuke
        node = nuke.toNode(node_name)
        if node is None:
            return True
        return bool(node.error())
    except Exception:
        return False


def read_offline_now(layers):
    """Return `{node_name: is_offline}` for every source on the layers."""
    names = {clip.node_name for layer in layers for clip in layer.clips}
    return {name: _check_clip_offline_by_name(name) for name in names}


def freeze_nodes_now(layers):
    """The names of the clips' nodes that are FrameHolds — SMTL's freezes."""
    names = {clip.node_name for layer in layers for clip in layer.clips}
    return {name for name in names if node_class(name) == 'FrameHold'}


def _check_clip_offline(clip):
    """Return True if the clip's source node is offline."""
    return _check_clip_offline_by_name(clip.node_name)


_NOT_A_SOURCE = {'Viewer', 'BackdropNode', 'StickyNote', 'Dot'}


def _is_smtl_output(node, depth=0, seen=None):
    """Return True if the node is SMTL_Group or downstream of it."""
    if depth > 20:
        return False
    if seen is None:
        seen = set()
    try:
        if node.name() in seen:
            return False
        seen.add(node.name())
        if node.name() == _SMTL_GROUP_NAME:
            return True
        for dep in node.dependencies():
            if _is_smtl_output(dep, depth + 1, seen):
                return True
    except Exception as e:
        _log(f'[SMTL] cannot walk upstream of a selected node ({e})')
    return False


def selected_source_names():
    """Return names of selected nodes that could go on a timeline."""
    if not _nuke_ok():
        return frozenset()
    try:
        import nuke
        return frozenset(n.name() for n in nuke.selectedNodes()
                         if n.Class() not in _NOT_A_SOURCE
                         and n.name() != _SMTL_GROUP_NAME)
    except Exception:
        return frozenset()


def node_ranges(names):
    """Return `{name: (first, last, is_still)}` without modifying nodes."""
    out = {}
    if not _nuke_ok():
        return out
    try:
        import nuke
    except Exception:
        return out
    for name in names:
        try:
            node = nuke.toNode(name)
            if node is None:
                continue
            first, last = int(node.firstFrame()), int(node.lastFrame())
            still = (node.Class() in _ALWAYS_STILL
                     or first == last
                     or not _has_media_upstream(node))
            out[name] = (first, last, still)
        except Exception:
            continue
    return out


def node_span_by_name(name):
    """Return _node_span for a named node, or None if missing."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        node = nuke.toNode(name)
    except Exception:
        return None
    if node is None:
        return None
    return _node_span(node)


def root_fps():
    """Return the script's exact frame rate."""
    if not _nuke_ok():
        return 24.0
    try:
        import nuke
        return float(nuke.root()['fps'].value())
    except Exception:
        return 24.0


def node_timecode_by_name(name):
    """Return (start_tc, start_frame, rate) for a named node, or None."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        node = nuke.toNode(name)
    except Exception:
        return None
    if node is None:
        return None

    try:
        first = int(node.firstFrame())
    except Exception:
        first = 1

    tc, at, rate = read_anchor(node, first)
    return (str(tc).strip() or None), at, rate


def node_media_facts(names):
    """Return path, timecode, rate and available range per node, read-only."""
    out = {}
    if not _nuke_ok():
        return out
    try:
        import nuke
    except Exception:
        return out
    for name in names:
        try:
            node = nuke.toNode(name)
        except Exception:
            continue
        if node is None:
            continue
        hold = None
        if node.Class() == 'FrameHold' and node.input(0) is not None:
            k = node.knob('firstFrame') or node.knob('first_frame')
            hold = int(k.value()) if k is not None else None
            node = node.input(0)
        path = ''
        try:
            f = node.knob('file')
            if f is not None:
                path = str(f.value() or '').strip()
        except Exception as e:
            _log(f'[SMTL] {name}: no file knob to export ({e})')
        try:
            first, last = int(node.firstFrame()), int(node.lastFrame())
        except Exception:
            first, last = 0, -1
        tc = node_timecode_by_name(node.name()) or (None, first, 0.0)
        out[name] = {
            'path':        path,
            'start_tc':    tc[0] or '',
            'start_frame': tc[1],
            'rate':        tc[2] or 0.0,
            'available':   (first, last) if last >= first else None,
            'hold':        hold,
        }
    return out


_TC_RE = _re.compile(r'^\s*\d{1,2}[:;]\d{2}[:;]\d{2}[:;]\d{2}\s*$')


def _make_readable(node):
    """Try colourspaces until a Read is out of error; return True if readable."""
    try:
        if not node.error():
            return True
    except Exception:
        return True
    knob = node.knob('colorspace')
    if knob is None:
        return False
    try:
        options = [str(v) for v in knob.values()
                   if v and not str(v).startswith('-')]
    except Exception:
        options = []
    for want in ('data', 'raw', 'scene_linear', 'linear', 'Raw', 'Linear'):
        if want in options:
            options.insert(0, options.pop(options.index(want)))
    for name in options[:8]:
        try:
            knob.setValue(name)
            if not node.error():
                return True
        except Exception:
            continue
    return False


def _at_frame(node, key, frame):
    """Return one metadata value at a frame, moving the root frame if needed."""
    try:
        got = node.metadata(key, frame)
    except Exception:
        got = None
    if got:
        return got
    try:
        import nuke
        was = nuke.frame()
    except Exception:
        return None
    try:
        nuke.frame(int(frame))
        return node.metadata(key)
    except Exception:
        return None
    finally:
        try:
            nuke.frame(was)
        except Exception:
            pass


def _read_tc(node, frame):
    """Return the media's timecode at a frame, or ''."""
    got = _at_frame(node, 'input/timecode', frame)
    if got and _TC_RE.match(str(got)):
        return str(got).strip()
    for key in sorted(_metadata_keys(node, frame)):
        if 'timecode' not in str(key).lower():
            continue
        value = str(_at_frame(node, key, frame) or '').strip()
        if _TC_RE.match(value):
            return value
    return ''


def read_anchor(node, first, rate=0.0):
    """Return `(timecode, frame, rate)` anchoring a node's timecode."""
    first = int(first)
    rate = float(rate or 0.0)
    if rate <= 0:
        rate = float(_at_frame(node, 'input/frame_rate', first) or 0.0)
    if rate <= 0:
        rate = root_fps()

    return _read_tc(node, first), first, rate


def _metadata_keys(node, frame):
    """Return every metadata key a node offers."""
    for asked in (frame, None):
        try:
            data = (node.metadata(None, asked) if asked is not None
                    else node.metadata()) or {}
        except Exception:
            data = {}
        if data:
            return sorted(str(k) for k in data)
    return []


def _no_undo_items(paths):
    """Yield `paths.items()` with the whole iteration outside undo."""
    with _no_undo():
        for item in dict(paths).items():
            yield item


_THUMB_DIR = None


def thumbnail(path, frame, width=96, height=54):
    """Render one frame of a file as a small PNG; return its path or ''."""
    global _THUMB_DIR
    if not _nuke_ok() or not path:
        return ''
    try:
        import nuke
        import tempfile
        if _THUMB_DIR is None:
            _THUMB_DIR = tempfile.mkdtemp(prefix='smtl_thumb_')
        out = os.path.join(_THUMB_DIR,
                           '%s.png' % abs(hash((path, int(frame)))))
        if os.path.exists(out):
            return out
    except Exception:
        return ''

    made = []
    try:
        with _no_undo():
            read = nuke.createNode('Read', inpanel=False)
            made.append(read)
            read['file'].setValue(path)
            _make_readable(read)
            at = max(int(read.firstFrame()),
                     min(int(read.lastFrame()), int(frame)))
            fit = nuke.createNode('Reformat', inpanel=False)
            made.append(fit)
            fit.setInput(0, read)
            fit['type'].setValue('to box')
            fit['box_width'].setValue(int(width))
            fit['box_height'].setValue(int(height))
            fit['box_fixed'].setValue(True)
            fit['black_outside'].setValue(True)
            write = nuke.createNode('Write', inpanel=False)
            made.append(write)
            write.setInput(0, fit)
            write['file'].setValue(out.replace('\\', '/'))
            write['file_type'].setValue('png')
            write['create_directories'].setValue(True)
            nuke.execute(write, at, at)
        return out if os.path.exists(out) else ''
    except Exception as e:
        _log(f'[SMTL] thumbnail {os.path.basename(str(path))}: {e}')
        return ''
    finally:
        with _no_undo():
            for node in reversed(made):
                try:
                    nuke.delete(node)
                except Exception:
                    pass


def probe_media(paths, trace=None):
    """Return timecode, rate, size and range for each candidate media file."""
    def say(text):
        if trace is not None:
            trace.append('    ' + text)
    out = {}
    if not _nuke_ok():
        return out
    try:
        import nuke
    except Exception:
        return out
    for path, (first, last) in _no_undo_items(paths):
        direct = None
        try:
            import smtl_media as _media
            direct = _media.read(path)
        except Exception as e:
            _log(f'[SMTL] Conform: cannot read {path} directly ({e})')
        if direct and direct.get('timecode'):
            out[path] = (direct['timecode'], int(direct['first']),
                         float(direct['rate'] or 0.0), 0, 0,
                         int(direct['first']), int(direct['last']))
            say('%s: read from the file — tc %r at %d, %g fps, frames %d-%d'
                % (os.path.basename(path), direct['timecode'],
                   direct['first'], direct['rate'],
                   direct['first'], direct['last']))
            continue

        node = None
        try:
            node = nuke.createNode('Read', inpanel=False)
            node['file'].setValue(path)
            if last > first:
                node['first'].setValue(int(first))
                node['last'].setValue(int(last))
            if not _make_readable(node):
                say('%s: the Read is in error, so it can be asked nothing '
                    '— %s' % (os.path.basename(path),
                              (node.error() if callable(node.error)
                               else 'unknown')))
            real_first = int(node.firstFrame())
            real_last  = int(node.lastFrame())
            if last > first:
                real_first, real_last = int(first), int(last)

            tc, at, rate = read_anchor(node, real_first)
            if not tc:
                keys = _metadata_keys(node, real_first)
                say('%s: offers %s'
                    % (os.path.basename(path),
                       ', '.join(keys[:14]) or 'no metadata at all'))
            say('%s: frames %d-%d @ %g → %s'
                % (os.path.basename(path), real_first, real_last, rate,
                   ('anchor %r at %d' % (tc, at)) if tc else
                   'no timecode we can trust, so it needs placing by '
                   'hand'))

            out[path] = (str(tc).strip(), at, rate,
                         int(node.width()), int(node.height()),
                         real_first, real_last)
        except Exception as e:
            _log(f'[SMTL] Conform: cannot read {path} ({e})')
        finally:
            if node is not None:
                try:
                    nuke.delete(node)
                except Exception:
                    pass
    return out


def node_class(name):
    """Return the Nuke class of a named node, or ''."""
    if not name or not _nuke_ok():
        return ''
    try:
        import nuke
        node = nuke.toNode(str(name))
        return '' if node is None else str(node.Class())
    except Exception:
        return ''


def prune_unused(names, in_use):
    """Delete unused Reads and FrameHolds; return the names deleted."""
    if not _nuke_ok():
        return []
    gone = []
    try:
        import nuke
        wanted = list(names)
        for name in list(names):
            node = nuke.toNode(str(name))
            if node is None or node.Class() != 'FrameHold':
                continue
            src = node.input(0)
            if src is not None:
                wanted.append(src.name())
        wanted.sort(key=lambda n: 0 if node_class(n) == 'FrameHold' else 1)
        for name in wanted:
            if name in in_use:
                continue
            node = nuke.toNode(str(name))
            if node is None or node.Class() not in ('Read', 'FrameHold'):
                continue
            if node.dependent():
                continue
            nuke.delete(node)
            gone.append(name)
    except Exception as e:
        _log(f'[SMTL] prune_unused: {e}')
    return gone


def reads_in_script():
    """Return `{file path: node name}` for every Read in the script."""
    out = {}
    if not _nuke_ok():
        return out
    try:
        import nuke
        for node in sorted(nuke.allNodes('Read'), key=lambda n: n.name()):
            try:
                path = str(node['file'].value() or '').strip()
            except Exception:
                continue
            if path and path not in out:
                out[path] = node.name()
    except Exception as e:
        _log(f'[SMTL] Conform: cannot list Reads ({e})')
    return out


def read_for_media(path, first, last, label='', proxy=''):
    """Return the Read for a media file, creating one if needed."""
    if not _nuke_ok():
        return ''
    try:
        import nuke
    except Exception:
        return ''
    try:
        for node in nuke.allNodes('Read'):
            if str(node['file'].value() or '').strip() == path:
                return node.name()
        node = nuke.createNode('Read', inpanel=False)
        node['file'].setValue(path)
        if 'auto_alpha' in node.knobs():
            node['auto_alpha'].setValue(True)
        node['first'].setValue(int(first))
        node['last'].setValue(int(last))
        for knob in ('origfirst', 'origlast'):
            if knob in node.knobs():
                node[knob].setValue(int(first if knob.endswith('first')
                                        else last))
        if proxy and 'proxy' in node.knobs():
            node['proxy'].setValue(proxy)
        if label:
            node['label'].setValue(str(label))
        return node.name()
    except Exception as e:
        _log(f'[SMTL] Conform: cannot make a Read for {path} ({e})')
        return ''


_ERROR_MODE_WAS = {}

_READ_ERROR_MODE = 'checkerboard'


def _read_error_default():
    """Return the facility default for a Read's on_error knob."""
    try:
        import nuke
        return str(nuke.knobDefault('Read.on_error') or 'error')
    except Exception:
        return 'error'


def set_read_error_mode(name, black):
    """Set a Read's on_error to checkerboard; return True if changed."""
    if not _nuke_ok():
        return False
    try:
        import nuke
        node = nuke.toNode(name)
        if node is None or 'on_error' not in node.knobs():
            return False
        now = str(node['on_error'].value())
        want = _READ_ERROR_MODE
        if now == want:
            return False
        node['on_error'].setValue(want)
        return True
    except Exception as e:
        _log(f'[SMTL] set_read_error_mode {name}: {e}')
        return False


def reload_read(name):
    """Reload one Read from disk; return True if it did."""
    if not _nuke_ok():
        return False
    try:
        import nuke
        node = nuke.toNode(name)
        if node is None or 'reload' not in node.knobs():
            return False
        node['reload'].execute()
        return True
    except Exception as e:
        _log(f'[SMTL] reload_read {name}: {e}')
        return False


def _get_selected_reads():
    """Return (sources, refused) from the selection, in selection order."""
    if not _nuke_ok():
        return [], []
    try:
        import nuke
        ok, refused = [], []
        for n in nuke.selectedNodes()[::-1]:
            if n.Class() in _NOT_A_SOURCE:
                continue
            (refused if _is_smtl_output(n) else ok).append(n)
        return ok, refused
    except Exception as e:
        print(f'[SMTL] _get_selected_reads error: {e}')
        return [], []


def _read_viewer_range():
    """Return the active viewer's (first, last, locked) range, or None."""
    if not _nuke_ok():
        return None
    try:
        import nuke
        av = nuke.activeViewer()
        if av is None:
            return None
        vn = av.node()
        locked = bool(vn['frame_range_lock'].value())
        parts  = str(vn['frame_range'].value()).split('-')
        if len(parts) != 2:
            return None
        return int(parts[0]), int(parts[1]), locked
    except Exception:
        return None


def _set_viewer_frame(frame):
    """Move the Nuke viewer to a frame."""
    if not _nuke_ok():
        return
    try:
        import nuke
        nuke.frame(frame)
        _log(f'[SMTL] Viewer frame → {frame}')
    except Exception as e:
        print(f'[SMTL] Set frame error: {e}')


def _do_play(direction=1, first_frame=None, last_frame=None):
    """Start playback on the active viewer (forward=1, reverse=-1)."""
    if not _nuke_ok():
        return
    try:
        import nuke
        if first_frame is not None and last_frame is not None:
            nuke.frame(first_frame if direction > 0 else last_frame)
        av = nuke.activeViewer()
        if av:
            av.play(direction)
            _log(f'[SMTL] Play dir={direction}'
                  + (f'  mark range {first_frame}–{last_frame}'
                     if first_frame is not None else ''))
    except Exception as e:
        print(f'[SMTL] Play error: {e}')


def _do_stop():
    """Stop playback on the active viewer."""
    if not _nuke_ok():
        return
    try:
        import nuke
        av = nuke.activeViewer()
        if av:
            av.stop()
    except Exception as e:
        print(f'[SMTL] Stop error: {e}')


def _export_tc_to_dag(clip):
    """Copy a clip's TimeClip into the main DAG; return the node or None."""
    if not _nuke_ok():
        return None
    try:
        import nuke

        grp = nuke.toNode(_SMTL_GROUP_NAME)
        anchor_x = int(grp['xpos'].value()) if grp else 0
        anchor_y = int(grp['ypos'].value()) if grp else 0

        read_node = nuke.toNode(clip.node_name) if clip.node_name else None

        src_label = clip.label or clip.node_name or 'clip'
        safe_name = src_label.replace('/', '_').replace('\\', '_').replace(' ', '_')
        base_name = f'{safe_name}_TC'
        final_name = base_name
        counter    = 1
        while nuke.toNode(final_name):
            final_name = f'{base_name}_{counter}'
            counter   += 1

        with _undo_group('SMTL: Export TimeOffset'):
            nuke.selectAll()
            nuke.invertSelection()

            tc = nuke.nodes.TimeClip(
                name       = final_name,
                first      = clip.src_first,
                last       = clip.src_last,
                frame_mode = 'start at',
                frame      = str(clip.first_frame),
                xpos       = anchor_x + 200,
                ypos       = anchor_y + 200,
            )

            if read_node:
                tc.setInput(0, read_node)

            tc['selected'].setValue(True)

        print(f'[SMTL] Exported TC node → {final_name}')
        return tc

    except Exception as e:
        print(f'[SMTL] Export TC error: {e}')
        return None

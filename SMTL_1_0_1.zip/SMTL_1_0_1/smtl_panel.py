"""Dockable Nuke panel for assembling and reviewing clips on layered tracks."""

import html
import os
import sys
import time
import weakref as _weakref

_SMTL_DIR = os.path.dirname(os.path.abspath(__file__))
if _SMTL_DIR not in sys.path:
    sys.path.insert(0, _SMTL_DIR)

try:
    from PySide6 import QtWidgets, QtCore, QtGui
    from PySide6.QtCore import Qt
except ImportError:
    from PySide2 import QtWidgets, QtCore, QtGui
    from PySide2.QtCore import Qt

from smtl_constants import (
    __version__,
    _LABEL_W, _MERGE_OPS,
    _POLL_FAST_MS, _POLL_IDLE_MS, _POLL_IDLE_AFTER, _STILL_SECONDS,
    _STILL_HANDLE,
    _TC_FIELD_MIN_W, _TC_FIELD_CHROME, _TC_FIELD_H,
    _PLAY_STILL_TICKS,
    _SMTL_GROUP_NAME,
    _SMTL_AUTHOR, _SMTL_URL,
    _NO_MEDIA,
)
import smtl_theme as _theme
import smtl_log as _log
from smtl_models import (
    SMTLClip, SMTLLayer, next_layer_name, starting_tracks,
    mark_clip_range, resolve_replace,
    source_timecode, is_drop_frame_rate,
    frames_to_timecode,
    parse_timecode_entry,
    split_clip, CLIP_MATERIAL_FIELDS, layer_blocked, transition_anchors,
    resolve_add_span,
    match_seams, join_match_edit,
    resolve_retime, tl_to_src,
    RETIME_TIMEWARP, RETIME_OFLOW, RETIME_KRONOS, RETIME_NODES,
    RETIME_NEEDS_NUKEX,
    ALPHA_MODES, ALPHA_USE, ALPHA_INVERT,
)
from smtl_nuke import (
    _nuke_ok,
    _undo_group,
    _root_first_frame, _root_last_frame,
    _rebuild_group,
    _sync_tc_start_positions,
    default_transition_frames,
    _set_clip_disabled_nuke,
    _set_layer_merge_disabled,
    _update_merge_settings,
    _update_retime,
    show_retime_node,
    _have_nukex,
    _set_active_layer,
    _set_solo_switch,
    _connect_viewer_to_group, link_viewer_if_needed,
    _delete_smtl_nodes,
    _save_timeline_to_node,
    _load_timeline_from_node,
    _get_selected_reads,
    _check_clip_offline,
    _missing_node_names,
    read_state_blob,
    select_nodes_by_name,
    show_dissolve_node,
    _node_span,
    selected_source_names,
    node_span_by_name,
    node_ranges,
    make_freeze_node,
    _check_clip_offline_by_name,
    _set_viewer_frame,
    _read_viewer_range,
    _do_play,
    _do_stop,
    _export_tc_to_dag,
    node_timecode_by_name, feeding_now,
    node_media_facts,
    probe_media, reads_in_script, read_for_media, node_class, prune_unused,
    tidy_sources, read_offline_now, freeze_nodes_now,
    set_read_error_mode, reload_read, _READ_ERROR_MODE,
    thumbnail,
    root_fps,
)
from smtl_import import BundleChoice, BUNDLE_NONE, point_at_extracted
from smtl_timeline import TimelineWidget
from smtl_widgets import (
    ExprSpinBox, DragDoubleWidget, _vline, apply_button_face, set_face_mark,
    StickyMenu,
    set_button_style,
    is_ctrl, is_shift, held, text_width, TimecodeEdit, PlainDoubleSpinBox,
    ImportOptionsDialog, ConformOptionsDialog, RateMismatchDialog,
    ConflictDialog,
)
import smtl_parse as _parse
import smtl_import as _importer
import smtl_tips as _tips
import smtl_export as _exporter
import smtl_conform as _conform

def _ctrl_held():
    """Return True while Ctrl (Cmd on macOS) is held."""
    return is_ctrl(held())


_USE_FS_WATCHER = True


_active_widget = None


def _size_text(n):
    """Return a byte count as a human-readable size string."""
    n = float(n or 0)
    for unit in ('bytes', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024 or unit == 'TB':
            return ('%d %s' % (n, unit) if unit == 'bytes'
                    else '%.1f %s' % (n, unit))
        n /= 1024.0


_RETIME_LABEL = {RETIME_TIMEWARP: 'TimeWarp',
                 RETIME_OFLOW:    'OFlow',
                 RETIME_KRONOS:   'Kronos'}


class SMTLWidget(QtWidgets.QWidget):

    @property
    def _sel_clip(self):
        """The clicked clip — the timeline's, read through, so there is one."""
        tl = getattr(self, '_timeline', None)
        return tl._sel_clip if tl is not None else None

    @_sel_clip.setter
    def _sel_clip(self, clip):
        tl = getattr(self, '_timeline', None)
        if tl is not None:
            tl._sel_clip = clip
    """The full SMTL panel: toolbar + scrollable timeline + status bar."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Snow Monkey Time Line')
        self.setMinimumSize(500, 200)
        self.setStyleSheet(_theme.panel_style())

        self._layers         = starting_tracks()
        self._active_idx     = 0
        self._add_idx        = 0
        self._clipboard      = None
        self._import_options = None
        self._import_offset  = 0
        self._had_clips      = False
        self._last_seen_frame = None
        self._pushing_frame   = False
        self._freeze_frames   = 0
        self._retime_speed = 0.5
        self._retime_kind  = RETIME_TIMEWARP
        self._retime_mode  = 'keep'
        self._retime_ripple = False
        self._dissolve_align  = 'centre'
        self._dissolve_len    = 0
        self._dissolve_before = 12
        self._dissolve_after  = 12

        self._poll_idle_ticks = 0
        self._pushed_range    = None

        self._build_ui()

        self._fs_watcher = None
        if _USE_FS_WATCHER:
            try:
                self._fs_watcher = QtCore.QFileSystemWatcher(self)
                self._fs_watcher.directoryChanged.connect(self._refresh_offline_states)
                self._fs_watcher.fileChanged.connect(self._refresh_offline_states)
            except Exception as e:
                print(f'[SMTL] QFileSystemWatcher unavailable: {e}')
                self._fs_watcher = None

        self._frame_poll = QtCore.QTimer(self)
        self._frame_poll.setInterval(_POLL_FAST_MS)
        self._frame_poll.timeout.connect(self._poll_viewer_frame)

        global _active_widget
        _active_widget = _weakref.ref(self)

        saved = _load_timeline_from_node()
        if saved is not None:
            self._apply_saved(saved)
            self._sync_spins()

        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._timeline._freeze_nodes = freeze_nodes_now(self._layers)

        self._state_seen = read_state_blob()
        self._sync_spins()
        self._refresh_merge_bar()
        self._refresh_status()
        self._check_sources_changed()
        self._recheck_missing_frames()
        self._nothing_is_waiting()


    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 4)
        root.setSpacing(4)

        toolbar = QtWidgets.QHBoxLayout()
        toolbar.setSpacing(4)

        _ICONS_DIR = os.path.join(_SMTL_DIR, 'icons')
        self._icons_dir = _ICONS_DIR

        def _face(btn, label, tip=None):
            apply_button_face(btn, label, _ICONS_DIR, tip)
            return btn

        self._btn_clip_overwrite = _face(QtWidgets.QPushButton(), 'Overwrite')
        self._btn_clip_overwrite.clicked.connect(
            lambda _=False: self._add_selected_reads('overwrite', ctrl=_ctrl_held()))

        self._btn_clip_splice = _face(QtWidgets.QPushButton(), 'Splice In')
        self._btn_clip_splice.clicked.connect(
            lambda _=False: self._add_selected_reads('splice', ctrl=_ctrl_held()))

        self._btn_clip_replace = _face(QtWidgets.QPushButton(), 'Replace')
        self._btn_clip_replace.clicked.connect(lambda _=False: self._replace_clip())
        self._btn_clip_replace.setEnabled(False)

        self._btn_clip_lift = _face(QtWidgets.QPushButton(), 'Lift')
        self._btn_clip_lift.clicked.connect(
            lambda _=False: self._remove_clip(False, ctrl=_ctrl_held()))
        self._btn_clip_lift.setEnabled(False)

        self._btn_clip_extract = _face(QtWidgets.QPushButton(), 'Extract')
        self._btn_clip_extract.clicked.connect(
            lambda _=False: self._remove_clip(True, ctrl=_ctrl_held()))
        self._btn_clip_extract.setEnabled(False)

        self._btn_layer_add = _face(QtWidgets.QPushButton(), 'Add Track')
        self._btn_layer_add.clicked.connect(self._add_layer)

        self._btn_layer_remove = _face(QtWidgets.QPushButton(), 'Remove Track')
        self._btn_layer_remove.clicked.connect(self._remove_layer)

        self._btn_clip_freeze = _face(QtWidgets.QPushButton(), '+ Freeze')
        self._btn_clip_freeze.clicked.connect(self._freeze_frame)
        self._btn_clip_freeze.setEnabled(False)

        self._btn_clip_retime = _face(QtWidgets.QPushButton(), 'Retime')
        self._btn_clip_retime.clicked.connect(self._retime_clips)
        self._btn_clip_retime.setEnabled(False)

        self._btn_clip_dissolve = _face(QtWidgets.QPushButton(), '+ Dissolve')
        def _on_dissolve_clicked():
            mods = QtWidgets.QApplication.keyboardModifiers()
            if is_ctrl(mods):
                self._dissolve_menu()
            else:
                self._add_dissolve(
                    curve='smooth' if is_shift(mods) else 'linear')

        self._btn_clip_dissolve.clicked.connect(_on_dissolve_clicked)

        _mode_style = _theme.mode_button_style()

        self._btn_tool_edit = _face(QtWidgets.QToolButton(), 'Edit')
        self._btn_tool_edit.setCheckable(True)
        self._btn_tool_edit.setChecked(True)
        set_button_style(self._btn_tool_edit, _mode_style)
        self._btn_tool_trim = _face(QtWidgets.QToolButton(), 'Trim')
        self._btn_tool_trim.setCheckable(True)
        set_button_style(self._btn_tool_trim, _mode_style)
        self._btn_tool_slide = _face(QtWidgets.QToolButton(), 'Slide')
        self._btn_tool_slide.setCheckable(True)
        set_button_style(self._btn_tool_slide, _mode_style)
        self._btn_tool_splice = _face(QtWidgets.QToolButton(), 'Splice')
        self._btn_tool_splice.setCheckable(True)
        set_button_style(self._btn_tool_splice, _mode_style)
        self._btn_tool_sel_left = _face(QtWidgets.QToolButton(), 'Sel L')
        self._btn_tool_sel_left.setCheckable(True)
        set_button_style(self._btn_tool_sel_left, _mode_style)
        self._btn_tool_sel_right = _face(QtWidgets.QToolButton(), 'Sel R')
        self._btn_tool_sel_right.setCheckable(True)
        set_button_style(self._btn_tool_sel_right, _mode_style)
        self._tool_mode_group = QtWidgets.QButtonGroup(self)
        self._tool_mode_group.setExclusive(True)
        for _btn in (self._btn_tool_edit, self._btn_tool_trim, self._btn_tool_slide,
                     self._btn_tool_splice,
                     self._btn_tool_sel_left, self._btn_tool_sel_right):
            self._tool_mode_group.addButton(_btn)

        def _on_tool_mode(btn=None):
            modes = {
                self._btn_tool_edit:  'edit',
                self._btn_tool_trim:  'trim',
                self._btn_tool_slide: 'slide',
                self._btn_tool_splice: 'splice',
                self._btn_tool_sel_left:  'sel_left',
                self._btn_tool_sel_right:  'sel_right',
            }
            checked = btn or self._tool_mode_group.checkedButton()
            if checked and hasattr(self, '_timeline'):
                new_mode = modes.get(checked, 'edit')
                if new_mode == getattr(self._timeline, '_tool_mode', 'edit') \
                        and new_mode != 'edit':
                    new_mode = 'edit'
                    self._btn_tool_edit.setChecked(True)
                self._timeline._tool_mode = new_mode
                if new_mode != 'splice':
                    self._timeline._splice_x = -1
                    self._timeline.setCursor(Qt.ArrowCursor)
                    self._timeline.update()
                self._refresh_mode_labels()

        self._tool_mode_group.buttonClicked.connect(_on_tool_mode)

        self._shift_names = {
            'trim': (
                self._btn_tool_trim,
                ('Trim',   _tips.tip('trim')),
                ('Ripple', _tips.tip('ripple')),
            ),
            'slide': (
                self._btn_tool_slide,
                ('Slide', _tips.tip('slide')),
                ('Slip',  _tips.tip('slip')),
            ),
        }
        self._refresh_dissolve_tip()

        self._shift_state = None
        self._shift_poll  = QtCore.QTimer(self)
        self._shift_poll.setInterval(80)
        self._shift_poll.timeout.connect(self._refresh_mode_labels)
        self._sel_poll_tick = 0
        self._has_reads     = None
        self._dag_sel_names = None
        self._log_btn_variant = None
        self._shift_poll.timeout.connect(self._poll_read_selection)
        self._gone_poll_tick = 0
        self._shift_poll.timeout.connect(self._poll_missing_nodes)
        self._state_poll_tick = 0
        self._state_seen      = None
        self._shift_poll.timeout.connect(self._poll_state_knob)
        self._watch_tick = 0
        self._watched    = {}
        self._shift_poll.timeout.connect(self._poll_for_frames)
        self._btn_clip_overwrite.setEnabled(False)
        self._btn_clip_splice.setEnabled(False)

        self._btn_snap = _face(QtWidgets.QToolButton(), 'Snap')
        self._btn_snap.setCheckable(True)
        set_button_style(self._btn_snap, _mode_style)

        def _on_snap_toggled(checked):
            if hasattr(self, '_timeline'):
                self._timeline.snap_active = checked

        self._btn_snap.toggled.connect(_on_snap_toggled)

        self._ui_freeze = False
        self._btn_ui_freeze = _face(QtWidgets.QToolButton(), 'UI Freeze')
        self._btn_ui_freeze.setCheckable(True)
        self._btn_ui_freeze.setChecked(self._ui_freeze)
        set_button_style(self._btn_ui_freeze, _mode_style)

        def _on_ui_freeze_toggled(checked):
            self._ui_freeze = bool(checked)
            if not checked:
                self._catch_up_to_viewer()

        self._btn_ui_freeze.toggled.connect(_on_ui_freeze_toggled)

        self._playing = 0

        self._btn_play_rev = _face(QtWidgets.QToolButton(), '\u25c0')
        self._btn_play_rev.setCheckable(True)
        set_button_style(self._btn_play_rev, _mode_style)
        self._btn_play_rev.clicked.connect(
            lambda _=False: self._on_play_pressed(-1))

        self._btn_play_fwd = _face(QtWidgets.QToolButton(), '\u25b6')
        self._btn_play_fwd.setCheckable(True)
        set_button_style(self._btn_play_fwd, _mode_style)
        self._btn_play_fwd.clicked.connect(
            lambda _=False: self._on_play_pressed(1))

        self._spin_cursor = ExprSpinBox(self)
        self._spin_cursor.setRange(-999999, 999999)
        self._spin_cursor.setStyleSheet(_theme.spin_style('cursor'))
        self._spin_cursor.setKeyboardTracking(False)

        self._btn_import = _face(QtWidgets.QPushButton(), 'Import')
        self._btn_import.clicked.connect(self._on_import_clicked)

        self._btn_export = _face(QtWidgets.QPushButton(), 'Export')
        self._btn_export.clicked.connect(self._on_export_clicked)

        self._btn_conform = _face(QtWidgets.QPushButton(), 'Conform')
        self._btn_conform.clicked.connect(self._on_conform_clicked)

        self._btn_link_viewer = _face(QtWidgets.QPushButton(), 'Relink Viewer')
        self._btn_link_viewer.clicked.connect(self._ensure_viewer)
        set_button_style(self._btn_link_viewer, _theme.push_button_style('link'))
        self._btn_reload = _face(QtWidgets.QPushButton(), 'Rebuild')
        self._btn_reload.clicked.connect(self._reload_from_node)

        self._spin_clip_frame = QtWidgets.QSpinBox(self)
        self._spin_clip_frame.setRange(-999999, 999999)
        self._spin_clip_frame.setReadOnly(True)
        self._spin_clip_frame.setSpecialValueText('—')
        self._spin_clip_frame.setStyleSheet(_theme.spin_style('clip'))
        self._spin_clip_frame.setEnabled(False)

        self._edit_src_tc = QtWidgets.QLineEdit(self)
        self._edit_src_tc.setReadOnly(True)
        self._edit_src_tc.setFocusPolicy(QtCore.Qt.NoFocus)
        self._edit_src_tc.setStyleSheet(_theme.line_edit_style('clip'))

        self._edit_rec_tc = TimecodeEdit(self)
        self._edit_rec_tc.setFocusPolicy(QtCore.Qt.StrongFocus)
        self._edit_rec_tc.setStyleSheet(_theme.line_edit_style('cursor'))
        self._edit_rec_tc.committed.connect(self._on_rec_tc_committed)

        _field_w = max(_TC_FIELD_MIN_W,
                       text_width(self._edit_rec_tc, '00:00:00:00',
                                  _TC_FIELD_CHROME))
        for _fld in (self._spin_cursor, self._spin_clip_frame,
                     self._edit_src_tc, self._edit_rec_tc):
            _fld.setFixedSize(_field_w, _TC_FIELD_H)
            _fld.setAlignment(QtCore.Qt.AlignCenter)

        self._btn_tc = _face(QtWidgets.QToolButton(), 'TC')
        self._btn_tc.setCheckable(True)
        set_button_style(self._btn_tc, _mode_style)
        self._btn_tc.toggled.connect(self._on_tc_toggled)

        self._src_tc_cache = {}

        self._btn_reset = _face(QtWidgets.QPushButton(), 'Reset')
        set_button_style(self._btn_reset, _theme.push_button_style('danger'))
        self._btn_reset.clicked.connect(self._reset_timeline)

        self._btn_fit = _face(QtWidgets.QToolButton(), 'Fit')
        set_button_style(self._btn_fit, _mode_style)

        self._btn_offline_check = _face(QtWidgets.QPushButton(), 'Refresh')
        set_button_style(self._btn_offline_check, _theme.push_button_style('default'))
        self._btn_offline_check.clicked.connect(self._on_refresh_clicked)

        self._btn_log = _face(QtWidgets.QPushButton(), 'Log')
        set_button_style(self._btn_log, _theme.push_button_style('default'))
        self._btn_log.clicked.connect(self._show_log)

        _lbl_s = QtWidgets.QLabel('S:')
        _lbl_s.setStyleSheet(_theme.toolbar_label_style())
        _lbl_e = QtWidgets.QLabel(':E')
        _lbl_e.setStyleSheet(_theme.toolbar_label_style())

        self._spin_start = QtWidgets.QSpinBox(self)
        self._spin_start.setRange(-999999, 999999)
        self._spin_start.setStyleSheet(_theme.spin_style())
        self._spin_start.setFixedSize(72, _TC_FIELD_H)

        self._spin_mark_in = QtWidgets.QSpinBox(self)
        self._spin_mark_in.setRange(-999999, 999999)
        self._spin_mark_in.setStyleSheet(_theme.spin_style('mark_in'))
        self._spin_mark_in.setFixedSize(62, _TC_FIELD_H)
        self._spin_mark_in.setKeyboardTracking(False)

        self._spin_mark_out = QtWidgets.QSpinBox(self)
        self._spin_mark_out.setRange(-999999, 999999)
        self._spin_mark_out.setStyleSheet(_theme.spin_style('mark_out'))
        self._spin_mark_out.setFixedSize(62, _TC_FIELD_H)
        self._spin_mark_out.setKeyboardTracking(False)

        self._spin_view_start = QtWidgets.QSpinBox(self)
        self._spin_view_start.setRange(-999999, 999999)
        self._spin_view_start.setStyleSheet(_theme.spin_style('view'))
        self._spin_view_start.setFixedSize(62, _TC_FIELD_H)

        self._spin_view_end = QtWidgets.QSpinBox(self)
        self._spin_view_end.setRange(-999999, 999999)
        self._spin_view_end.setStyleSheet(_theme.spin_style('view'))
        self._spin_view_end.setFixedSize(62, _TC_FIELD_H)

        self._spin_end = QtWidgets.QSpinBox(self)
        self._spin_end.setRange(-999999, 999999)
        self._spin_end.setStyleSheet(_theme.spin_style())
        self._spin_end.setFixedSize(72, _TC_FIELD_H)


        _left_w = QtWidgets.QWidget()
        _left_w.setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                              QtWidgets.QSizePolicy.Preferred)
        _left_lay = QtWidgets.QHBoxLayout(_left_w)
        _left_lay.setContentsMargins(0, 0, 0, 0)
        _left_lay.setSpacing(4)
        _left_lay.addWidget(self._btn_import)
        _left_lay.addWidget(self._btn_export)
        _left_lay.addWidget(self._btn_conform)
        _left_lay.addWidget(_vline())
        _left_lay.addWidget(self._btn_link_viewer)
        _left_lay.addStretch()

        _ctr_w = QtWidgets.QWidget()
        _ctr_w.setSizePolicy(QtWidgets.QSizePolicy.Fixed,
                             QtWidgets.QSizePolicy.Preferred)
        _ctr_lay = QtWidgets.QHBoxLayout(_ctr_w)
        _ctr_lay.setContentsMargins(0, 0, 0, 0)
        _ctr_lay.setSpacing(4)
        _ctr_lay.addWidget(self._spin_mark_in)
        _ctr_lay.addSpacing(8)
        _ctr_lay.addWidget(self._btn_play_rev)
        _ctr_lay.addWidget(self._spin_cursor)
        _ctr_lay.addWidget(self._edit_rec_tc)
        _ctr_lay.addWidget(self._btn_play_fwd)
        _ctr_lay.addSpacing(8)
        _ctr_lay.addWidget(self._spin_mark_out)
        _ctr_lay.addSpacing(12)
        _ctr_lay.addWidget(self._btn_ui_freeze)

        _right_w = QtWidgets.QWidget()
        _right_w.setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                               QtWidgets.QSizePolicy.Preferred)
        _right_lay = QtWidgets.QHBoxLayout(_right_w)
        _right_lay.setContentsMargins(0, 0, 0, 0)
        _right_lay.setSpacing(4)
        _right_lay.addStretch()
        for w in (self._spin_clip_frame, self._edit_src_tc,
                  self._btn_tc, _vline(),
                  self._btn_fit, self._spin_view_start, self._spin_view_end,
                  _vline(),
                  _lbl_s, self._spin_start, self._spin_end, _lbl_e, _vline(),
                  self._btn_offline_check, _vline(),
                  self._btn_reload, _vline(), self._btn_reset):
            _right_lay.addWidget(w)

        self._edit_src_tc.setVisible(False)
        self._edit_rec_tc.setVisible(False)

        toolbar.addWidget(_left_w,  1)
        toolbar.addWidget(_ctr_w,   0)
        toolbar.addWidget(_right_w, 1)

        root.addLayout(toolbar)

        self._row2 = QtWidgets.QWidget()
        row2 = QtWidgets.QHBoxLayout(self._row2)
        row2.setContentsMargins(4, 2, 4, 2)
        row2.setSpacing(4)
        row2.addSpacing(_LABEL_W)
        row2.addStretch()
        for w in (self._btn_clip_overwrite, self._btn_clip_splice,
                  self._btn_clip_replace, _vline(),
                  self._btn_clip_lift, self._btn_clip_extract, _vline(),
                  self._btn_clip_dissolve, self._btn_clip_freeze,
                  self._btn_clip_retime, _vline(),
                  self._btn_tool_edit, self._btn_tool_trim, self._btn_tool_slide,
                  self._btn_tool_splice, _vline(),
                  self._btn_tool_sel_left, self._btn_tool_sel_right,
                  _vline(), self._btn_snap, _vline()):
            row2.addWidget(w)

        self._merge_bar   = QtWidgets.QWidget()
        merge_bar_row     = QtWidgets.QHBoxLayout(self._merge_bar)
        merge_bar_row.setContentsMargins(0, 0, 0, 0)
        merge_bar_row.setSpacing(6)

        merge_bar_row.addWidget(QtWidgets.QLabel('Operation:'))
        self._combo_merge_op = QtWidgets.QComboBox()
        self._combo_merge_op.addItems(_MERGE_OPS)
        self._combo_merge_op.setSizeAdjustPolicy(
            QtWidgets.QComboBox.AdjustToContents)
        self._combo_merge_op.insertItem(0, '')
        merge_bar_row.addWidget(self._combo_merge_op)

        merge_bar_row.addSpacing(10)
        merge_bar_row.addWidget(QtWidgets.QLabel('Mix:'))
        self._spin_merge_mix = DragDoubleWidget(value=1.0, min_val=0.0, max_val=1.0)
        merge_bar_row.addWidget(self._spin_merge_mix)

        self._combo_merge_op.currentTextChanged.connect(self._on_merge_op_changed)
        self._spin_merge_mix.value_changed.connect(self._on_merge_mix_changed)

        row2.addWidget(self._merge_bar)
        row2.addStretch()

        self._row2.setStyleSheet(_theme.merge_bar_style())
        root.addWidget(self._row2)

        self._scroll = QtWidgets.QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self._scroll.setStyleSheet(_theme.scroll_area_style())

        self._timeline = TimelineWidget()
        self._btn_snap.setChecked(self._timeline.snap_active)

        self._spin_start.editingFinished.connect(self._on_spin_start_edited)
        self._spin_end.editingFinished.connect(self._on_spin_end_edited)
        self._spin_mark_in.editingFinished.connect(
            lambda: self._set_mark_in(self._spin_mark_in.value()))
        self._spin_mark_out.editingFinished.connect(
            lambda: self._set_mark_out(self._spin_mark_out.value()))
        self._spin_view_start.editingFinished.connect(self._on_spin_view_start_edited)
        self._spin_view_end.editingFinished.connect(self._on_spin_view_end_edited)
        self._timeline.viewport_changed.connect(self._sync_view_spins)
        self._sync_spins()
        self._sync_view_spins()

        self._timeline.clip_selected.connect(self._on_clip_selected)
        self._timeline.layer_activated.connect(self._on_layer_activated)
        self._timeline.add_target_changed.connect(self._on_add_target_changed)
        self._timeline.cursor_moved.connect(self._on_cursor_moved)
        self._timeline.clip_dropped.connect(self._on_clip_dropped)
        self._timeline.clip_repositioned.connect(self._on_clip_repositioned)
        self._timeline.clip_dragging.connect(self._update_clip_frame_spin)
        self._timeline.clip_right_clicked.connect(self._on_clip_right_clicked)
        self._timeline.cursor_released.connect(self._save_state)
        self._timeline.layer_lock_toggled.connect(self._on_layer_lock_toggled)
        self._timeline.layer_move_requested.connect(self._move_layer)
        self._install_shortcuts()
        self._timeline.transition_changed.connect(self._on_transition_changed)
        self._timeline.transition_selected.connect(self._select_dissolve_curve)
        self._timeline.status_message.connect(self._set_status)
        self._timeline.extend_requested.connect(self._ask_extend_past_media)
        self._timeline.layer_solo_toggled.connect(self._on_layer_solo_toggled)
        self._timeline.split_requested.connect(self._on_split_clip)
        self._timeline.exit_sel_mode.connect(self._on_exit_sel_mode)
        self._timeline.layer_hide_toggled.connect(self._on_layer_hide_toggled)
        self._timeline.tl_bounds_changed.connect(self._on_tl_bounds_changed)
        self._btn_fit.clicked.connect(self._timeline.fit_to_bounds)

        self._timeline.cursor_moved.connect(self._on_cursor_spin_update)
        self._spin_cursor.valueChanged.connect(self._on_cursor_spin_jump)

        self._timeline.set_layer_buttons(self._btn_layer_add, self._btn_layer_remove)

        self._scroll.setWidget(self._timeline)
        root.addWidget(self._scroll, 1)

        self._lbl_status = QtWidgets.QLabel()
        self._lbl_status.setStyleSheet(_theme.status_style())

        self._lbl_credit = QtWidgets.QLabel(self)
        self._lbl_credit.setTextFormat(QtCore.Qt.RichText)
        self._lbl_credit.setText(_theme.credit_markup(
            f'SMTL {__version__} \u2014 {_SMTL_AUTHOR}', _SMTL_URL))
        self._lbl_credit.setOpenExternalLinks(True)
        self._lbl_credit.setTextInteractionFlags(
            QtCore.Qt.TextBrowserInteraction)
        self._lbl_credit.setToolTip(f'Snow Monkey VFX \u2014 {_SMTL_URL}')
        self._lbl_credit.setStyleSheet(_theme.credit_style())

        status_row = QtWidgets.QHBoxLayout()
        status_row.setContentsMargins(0, 0, 0, 0)
        status_row.setSpacing(6)
        status_row.addWidget(self._lbl_credit)
        status_row.addWidget(self._lbl_status, 1)
        self._status_balance = QtWidgets.QWidget()
        status_row.addWidget(self._status_balance)
        status_row.addWidget(self._btn_log)
        root.addLayout(status_row)

        _tips.apply(self)

        self._lock_shift_widths()

    def _lock_shift_widths(self):
        """Hold every button that renames itself at the width of its longer name."""
        for btn, plain, shifted in list(self._shift_names.values()) + [
                (self._btn_clip_dissolve,
                 ('+ Dissolve', ''), ('+ S Dissolve', ''))]:
            btn.ensurePolished()
            keep, widest = btn.text(), 0
            for label in (plain[0], shifted[0]):
                btn.setText(label)
                widest = max(widest, btn.sizeHint().width())
            btn.setText(keep)
            btn.setFixedWidth(widest)

        if getattr(self, '_status_balance', None) is not None:
            self._btn_log.ensurePolished()
            self._lbl_credit.ensurePolished()
            self._status_balance.setFixedWidth(
                max(0, self._lbl_credit.sizeHint().width()
                       - self._btn_log.sizeHint().width()))


    def _on_add_target_changed(self, idx):
        self._add_idx = idx
        self._update_clip_frame_spin()
        self._refresh_merge_bar()
        self._save_state()
        self._refresh_status()

    def _on_split_clip(self, clip, split_frame):
        """Split a clip at split_frame into two clips."""
        if split_frame < clip.first_frame or split_frame >= clip.last_frame:
            return

        owner_layer = None
        for layer in self._layers:
            if clip in layer.clips:
                owner_layer = layer
                break
        if owner_layer is None:
            return

        clip_a, clip_b = split_clip(clip, split_frame)
        clip_a.clip_id = clip.clip_id

        idx = owner_layer.clips.index(clip)
        owner_layer.clips[idx:idx + 1] = [clip_a, clip_b]

        self._timeline._clear_selection(keep=clip_b)

        self._sync_viewer_group('SMTL: Split clip')
        self._refresh_status()

    def _on_exit_sel_mode(self):
        """Reset the tool buttons to Edit after leaving a selection mode."""
        self._tool_mode_group.setExclusive(False)
        self._btn_tool_sel_left.setChecked(False)
        self._btn_tool_sel_right.setChecked(False)
        self._tool_mode_group.setExclusive(True)
        self._btn_tool_edit.setChecked(True)

    def _on_clip_dropped(self):
        """Rebuild after a clip is dragged to another layer."""
        self._sync_viewer_group('SMTL: Move clip')

    def _on_clip_repositioned(self, moved_clips):
        """Update nodes in place for clips moved within their layers."""
        touched = {li for li, _ in moved_clips}
        had     = any(getattr(self._layers[li], 'transitions', None)
                      for li in touched if li < len(self._layers))
        changed = self._timeline.prune_all_transitions()
        if had or changed:
            self._sync_viewer_group('SMTL: Move clip')
            self._update_clip_frame_spin()
            self._refresh_status()
            return
        pairs = [(self._layers[li], c)
                 for li in sorted(touched) if li < len(self._layers)
                 for c in self._layers[li].clips]
        with _undo_group('SMTL: Move clip'):
            _sync_tc_start_positions(self._layers, moved_clips)
            _update_merge_settings(pairs)
            _update_retime(pairs)
            self._save_state()
        self._update_clip_frame_spin()
        self._refresh_status()

    def _on_cursor_moved(self, frame):
        """Drive the viewer from the playhead."""
        self._refresh_status(cursor_only=True)
        self._pushing_frame = True
        try:
            _set_viewer_frame(frame)
            self._last_seen_frame = frame
        finally:
            self._pushing_frame = False

    def _update_clip_frame_spin(self):
        """Show the source frame under the playhead on the edit-target layer."""
        cursor = self._timeline._cursor_frame
        idx    = self._add_idx
        clip   = None
        if 0 <= idx < len(self._layers):
            for c in self._layers[idx].clips:
                if c.first_frame <= cursor <= c.last_frame:
                    clip = c
                    break

        self._spin_clip_frame.blockSignals(True)
        if clip is None:
            self._spin_clip_frame.setValue(self._spin_clip_frame.minimum())
            self._spin_clip_frame.setEnabled(False)
        else:
            src = tl_to_src(clip, cursor)
            self._spin_clip_frame.setValue(
                max(clip.src_first, min(clip.src_last, src)))
            self._spin_clip_frame.setEnabled(True)
        self._spin_clip_frame.blockSignals(False)
        self._update_tc_fields(clip, cursor)

    def _on_tc_toggled(self, checked):
        """Switch both frame fields between timecode and frame display."""
        self._spin_cursor.setVisible(not checked)
        self._edit_rec_tc.setVisible(checked)
        self._spin_clip_frame.setVisible(not checked)
        self._edit_src_tc.setVisible(checked)
        self._update_clip_frame_spin()

    def _on_rec_tc_committed(self, text):
        """Jump the playhead to a typed record timecode."""
        tl   = self._timeline
        rate = root_fps()
        try:
            count = parse_timecode_entry(text, rate,
                                         current=tl._cursor_frame)
        except ValueError as e:
            self._set_status(f'{str(text).strip()!r}: {e}', _log.WARN)
            self._update_clip_frame_spin()
            return

        frame = count
        frame = max(self._spin_cursor.minimum(),
                    min(self._spin_cursor.maximum(), frame))
        self._on_cursor_spin_jump(frame)

    def _source_tc_info(self, node_name):
        """Return cached (start_tc, start_frame, rate) for a source node."""
        if node_name not in self._src_tc_cache:
            info = None
            try:
                info = node_timecode_by_name(node_name)
            except Exception as e:
                _log.note(f'timecode metadata: {node_name}: {e}', _log.WARN)
            self._src_tc_cache[node_name] = info
        return self._src_tc_cache[node_name]

    def _update_tc_fields(self, clip, cursor):
        """Update the source and record timecode fields for the playhead."""
        rate = root_fps()

        if clip is None:
            self._edit_src_tc.setText('\u2014')
            self._edit_src_tc.setEnabled(False)
        else:
            src  = max(clip.src_first,
                       min(clip.src_last, tl_to_src(clip, cursor)))
            info = self._source_tc_info(clip.node_name)
            src_rate = info[2] if info else rate
            if info and info[0]:
                start_tc, start_frame, src_rate = info
                try:
                    txt = source_timecode(src, start_tc, start_frame, src_rate)
                except ValueError as e:
                    _log.note(f'{clip.display_label}: unreadable timecode '
                              f'{start_tc!r} ({e})', _log.WARN)
                    txt = None
            else:
                txt = None
            if txt is None:
                txt = frames_to_timecode(src, src_rate,
                                         is_drop_frame_rate(src_rate))
            self._edit_src_tc.setText(txt)
            self._edit_src_tc.setEnabled(True)

        if not self._edit_rec_tc.hasFocus():
            try:
                self._edit_rec_tc.setText(
                    frames_to_timecode(cursor, rate,
                                       is_drop_frame_rate(rate)))
                self._edit_rec_tc.setEnabled(True)
            except Exception as e:
                _log.note(f'record timecode: {e}', _log.WARN)
                self._edit_rec_tc.setText('\u2014')
                self._edit_rec_tc.setEnabled(False)

    def _on_cursor_spin_update(self, frame):
        """Sync the playhead spinbox with the timeline cursor."""
        if not self._spin_cursor.hasFocus():
            self._spin_cursor.blockSignals(True)
            self._spin_cursor.setValue(frame)
            self._spin_cursor.blockSignals(False)
        self._update_clip_frame_spin()

    def _on_cursor_spin_jump(self, frame):
        """Move the timeline cursor to a frame."""
        tl = self._timeline
        tl._cursor_frame = frame
        tl.cursor_moved.emit(frame)
        tl.update()

    def _has_selected_transition(self):
        """Return True when a dissolve is selected."""
        return self._timeline._sel_trans is not None

    def _refresh_freeze_button(self):
        """Freeze needs a clip under the playhead, on an unlocked track."""
        self._btn_clip_freeze.setEnabled(
            self._timeline.clip_under_cursor() is not None
            and not self._locked_now())

    def _refresh_removal_buttons(self):
        """Enable the edit buttons from what they would act on."""
        self._refresh_freeze_button()
        self._btn_clip_retime.setEnabled(
            bool(self._selected_clip_pairs()) and not self._locked_now())
        self._refresh_replace_button()

        if self._has_selected_transition():
            self._btn_clip_lift.setEnabled(True)
            self._btn_clip_extract.setEnabled(False)
            return

        target    = self._timeline.removal_target()
        has_range = self._timeline.has_marked_range()

        if target == 'clips':
            lift    = True
            extract = len(self._timeline.removal_layers()) <= 1 or has_range
        elif target == 'gap':
            lift, extract = False, True
        elif target == 'range':
            lift, extract = True, True
        else:
            lift, extract = has_range, has_range

        self._btn_clip_lift.setEnabled(lift)
        self._btn_clip_extract.setEnabled(extract)

    def _can_remove(self):
        """Return True when Lift or Extract has a target."""
        return self._timeline.removal_target() is not None

    def _sync_dag_selection(self):
        """Select the selected clips' nodes in the DAG."""
        names = frozenset(c.node_name for c in self._timeline.selection())
        if names:
            select_nodes_by_name(names)

    def _on_clip_selected(self, clip):
        self._sync_dag_selection()
        self._sel_clip = clip
        if clip is not None and clip.retime_node:
            show_retime_node(clip)
        self._refresh_merge_bar()
        self._refresh_removal_buttons()
        self._update_clip_frame_spin()
        self._refresh_status()

    def _on_layer_activated(self, idx):
        if idx == self._active_idx or idx >= len(self._layers):
            return
        self._active_idx = idx
        self._timeline.active_idx = idx
        self._timeline.update()
        _set_active_layer(idx, self._layers)
        self._save_state()
        self._refresh_status()


    def _selected_clip_pairs(self):
        """Return (layer, clip) for every selected clip, in layer order."""
        sel = set(self._timeline.selection())
        return [(layer, clip) for layer in self._layers
                for clip in layer.clips if clip in sel]

    def _refresh_merge_bar(self):
        """Update the merge bar from the selected clips."""
        pairs   = self._selected_clip_pairs()
        locked  = any(getattr(lyr, 'locked', False) for lyr, _c in pairs)
        enabled = bool(pairs) and not locked
        self._merge_bar.setEnabled(enabled)
        if not enabled:
            return

        ops   = {c.merge_op  for _l, c in pairs}
        mixes = {c.merge_mix for _l, c in pairs}

        self._combo_merge_op.blockSignals(True)
        self._spin_merge_mix.blockSignals(True)
        if len(ops) == 1:
            op = next(iter(ops))
            self._combo_merge_op.setCurrentIndex(
                _MERGE_OPS.index(op) + 1 if op in _MERGE_OPS else 0)
        else:
            self._combo_merge_op.setCurrentIndex(0)
        self._combo_merge_op.setStyleSheet(
            _theme.combo_mixed_style(len(ops) != 1))
        if len(mixes) == 1:
            self._spin_merge_mix.setValue(next(iter(mixes)))
        else:
            self._spin_merge_mix.setMixed()
        self._combo_merge_op.blockSignals(False)
        self._spin_merge_mix.blockSignals(False)

    def _on_merge_op_changed(self, op):
        """Apply a merge operation to every selected clip."""
        if not op:
            return
        pairs = self._selected_clip_pairs()
        if not pairs:
            return
        for _lyr, clip in pairs:
            clip.merge_op = op
        with _undo_group('SMTL: Merge op'):
            _update_merge_settings(pairs)
            self._save_state()
        self._set_status(f'{op} on {len(pairs)} clip'
                         f'{"" if len(pairs) == 1 else "s"}')
        self._refresh_merge_bar()

    def _on_merge_mix_changed(self, value):
        """Apply a merge mix to every selected clip."""
        pairs = self._selected_clip_pairs()
        if not pairs:
            return
        for _lyr, clip in pairs:
            clip.merge_mix = value
        with _undo_group('SMTL: Merge mix'):
            _update_merge_settings(pairs)
            self._save_state()
        self._refresh_merge_bar()


    def _add_selected_reads(self, mode='overwrite', ctrl=False):
        """Add the selected Read nodes to the edit-target layer."""
        reads, refused = _get_selected_reads()
        if refused:
            names = ', '.join(n.name() for n in refused[:3])
            more  = '' if len(refused) <= 3 else f' and {len(refused) - 3} more'
            self._set_status(
                f'{names}{more} cannot go on the timeline — '
                f'it comes from {_SMTL_GROUP_NAME} and would feed itself.',
                _log.WARN)
        if not reads:
            if not refused:
                self._set_status(
                    'Select one or more Read nodes in the Nuke graph first.',
                    _log.WARN)
            return

        tl        = self._timeline
        mark_in   = None if ctrl else tl._mark_in
        mark_out  = None if ctrl else tl._mark_out
        limit     = None
        if mark_in is not None and mark_out is not None:
            start, limit = min(mark_in, mark_out), max(mark_in, mark_out)
        elif mark_in is not None:
            start = mark_in
        elif mark_out is not None:
            total = 0
            for node in reads:
                _lbl, sf, sl, _still = _node_span(node)
                total += max(1, sl - sf + 1)
            start, limit = mark_out - total + 1, mark_out
        else:
            start = tl._cursor_frame

        added = skipped = 0
        cut_short = False
        at = start
        for node in reads:
            _lbl, sf, sl, _still = _node_span(node)
            wanted = max(1, sl - sf + 1)
            clip = tl.add_read(node, self._add_idx, mode=mode,
                               at_frame=at, max_last=limit)
            if clip is None:
                skipped += 1
                continue
            if clip.last_frame - clip.first_frame + 1 < wanted:
                cut_short = True
            added += 1
            at = clip.last_frame + 1

        if added:
            self._timeline.set_layers(self._layers, self._active_idx,
                                      add_idx=self._add_idx)
            label = 'Splice in clip' if mode == 'splice' else 'Add clip'
            self._sync_viewer_group(f'SMTL: {label}')

        self._refresh_status()
        if skipped:
            self._set_status(
                f'Added {added} of {added + skipped} — the rest would not fit '
                f'before the out point at {limit}.', _log.WARN)
        elif cut_short:
            self._set_status(
                f'Added {added} — cut off at the out point at {limit}.', _log.WARN)
        elif limit is not None or mark_in is not None or mark_out is not None:
            self._set_status(f'Added {added} from {start}.')

    def _remove_clip(self, extract=False, ctrl=False):
        """Lift (extract=False) or Extract (extract=True) the selection."""
        if not extract and self._remove_dissolve():
            return
        if ctrl and not self._timeline.has_marked_range():
            self._set_status('Ctrl needs a marked In/Out range to work with.',
                             _log.WARN)
            return
        if (extract and self._timeline.removal_target(prefer_range=ctrl) == 'clips'
                and len(self._timeline.removal_layers()) > 1):
            self._set_status(
                'Extract works on one layer at a time — use Lift, '
                'select clips on a single layer, or mark a range and Ctrl-click.',
                _log.WARN)
            return
        if not self._timeline.remove_selected_clip(extract=extract,
                                                   prefer_range=ctrl):
            return
        self._refresh_removal_buttons()
        self._sync_viewer_group('SMTL: Extract' if extract else 'SMTL: Lift')
        self._refresh_status()

    def _toggle_clip_disabled(self):
        """Toggle the disabled state of the selected clip."""
        if not self._sel_clip:
            return
        self._sel_clip.disabled = not self._sel_clip.disabled
        self._timeline.update()
        with _undo_group('SMTL: Mute clip'):
            _set_clip_disabled_nuke(self._sel_clip)
            self._save_state()
        state = 'disabled' if self._sel_clip.disabled else 'enabled'
        self._refresh_status()
        print(f'[SMTL] Clip "{self._sel_clip.display_label}" {state}')


    def _on_clip_right_clicked(self, clip, layer_idx, global_pos):
        """Show the context menu for a clip."""
        menu = QtWidgets.QMenu(self)
        menu.setStyleSheet(_theme.menu_style())

        head = clip.display_label or clip.node_name or '(unnamed)'
        if clip.user_label and clip.label and clip.label != clip.user_label:
            head = f'{head}   ({clip.label})'
        lbl_action = menu.addAction(head)
        lbl_action.setEnabled(False)

        menu.addSeparator()

        act_rename = menu.addAction('Rename…')
        act_colour = menu.addAction('Colour…')
        act_reset  = menu.addAction('Reset name and colour')
        act_reset.setEnabled(bool(clip.user_label or clip.colour))

        menu.addSeparator()

        layer = self._layers[layer_idx] if 0 <= layer_idx < len(self._layers) else None
        act_join = None
        join_pair = None
        if layer is not None:
            mine = [(f, pair) for f, pair in match_seams(layer).items()
                    if clip is pair[0] or clip is pair[1]]
            if mine:
                cursor = self._timeline._cursor_frame
                _f, join_pair = min(mine, key=lambda fp: abs(fp[0] - cursor))
                act_join = menu.addAction('Remove match edit')
                act_join.setEnabled(not layer_blocked(layer))
                menu.addSeparator()

        kind_acts = {}
        act_remove = None
        if clip.retime_node and layer is not None:
            menu.addSeparator()
            node_menu = menu.addMenu('Retime node')
            nukex = _have_nukex()
            for kind in RETIME_NODES:
                text = _RETIME_LABEL.get(kind, kind)
                if kind in RETIME_NEEDS_NUKEX and not nukex:
                    text += '   (NukeX required)'
                act = node_menu.addAction(text)
                act.setCheckable(True)
                act.setChecked(kind == clip.retime_node)
                act.setEnabled(not (kind in RETIME_NEEDS_NUKEX and not nukex))
                kind_acts[act] = kind
            act_remove = menu.addAction('Remove retime')

        menu.addSeparator()
        act_reconform = menu.addAction('Reconform')
        act_reconform.setEnabled(
            bool(clip.src_tc) and clip.src_rate > 0
            and layer is not None and not layer_blocked(layer))
        act_reconform.setToolTip(_tips.tip('reconform'))

        menu.addSeparator()
        act_alpha = menu.addAction('Alpha…')

        menu.addSeparator()
        export_menu = menu.addMenu('Export')
        tc_action   = export_menu.addAction('TimeOffset')
        tc_action.triggered.connect(lambda: self._export_clip_tc(clip))

        chosen = menu.exec_(global_pos)
        if chosen is act_rename:
            self._rename_clip(clip)
        elif chosen is act_colour:
            self._colour_clip(clip, layer_idx)
        elif chosen is act_reset:
            self._reset_clip_look(clip)
        elif chosen is act_reconform:
            self._on_reconform(clip)
        elif chosen is act_alpha:
            self._alpha_menu(clip, global_pos)
        elif chosen in kind_acts:
            self._set_retime_kind(layer, clip, kind_acts[chosen])
        elif chosen is act_remove and act_remove is not None:
            self._remove_retime(layer, clip)
        elif chosen is act_join and act_join is not None:
            self._join_match_edit(layer, *join_pair)


    def _rename_clip(self, clip):
        """Set or clear a clip's own name."""
        name, ok = QtWidgets.QInputDialog.getText(
            self, 'Rename clip', 'Name:',
            QtWidgets.QLineEdit.Normal, clip.display_label)
        if not ok:
            return
        name = name.strip()
        clip.user_label = '' if name in ('', clip.label) else name
        self._save_state()
        self._timeline.update()
        self._set_status(f'Renamed to "{clip.display_label}".' if clip.user_label
                         else f'Name cleared — back to "{clip.label}".')

    def _colour_clip(self, clip, layer_idx):
        """Set a clip's own colour."""
        start = clip.colour or _theme.layer_colour(layer_idx)
        for i, tint in enumerate(_theme.CLIP_TINTS):
            QtWidgets.QColorDialog.setCustomColor(i, QtGui.QColor(tint))
        picked = QtWidgets.QColorDialog.getColor(
            QtGui.QColor(start), self, 'Clip colour')
        if not picked.isValid():
            return
        clip.colour = picked.name()
        self._save_state()
        self._timeline.update()
        self._set_status(f'{clip.display_label}: colour set to {clip.colour}.')

    def _reset_clip_look(self, clip):
        """Clear a clip's own name and colour."""
        clip.user_label = ''
        clip.colour     = ''
        self._save_state()
        self._timeline.update()
        self._set_status(f'{clip.label}: back to its node name and layer colour.')

    def _show_conform_report(self, label, summary):
        """Show a conform summary in a message box."""
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle('SMTL — %s' % label.lower())
        box.setIcon(QtWidgets.QMessageBox.NoIcon)
        box.setText(summary)
        box.setStandardButtons(QtWidgets.QMessageBox.Close)
        box.exec_()

    def _say(self, text, title='SMTL'):
        """Show a message box with a Close button."""
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle(title)
        box.setIcon(QtWidgets.QMessageBox.NoIcon)
        box.setText(text)
        box.setStandardButtons(QtWidgets.QMessageBox.Close)
        box.exec_()

    def _ask(self, text, ok='Add'):
        """Show a confirm box; return True if accepted."""
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle('SMTL')
        box.setIcon(QtWidgets.QMessageBox.NoIcon)
        box.setText(text)
        go = box.addButton(ok, QtWidgets.QMessageBox.AcceptRole)
        box.addButton('Cancel', QtWidgets.QMessageBox.RejectRole)
        box.setDefaultButton(go)
        box.exec_()
        return box.clickedButton() is go

    def _show_log(self):
        """Open the log window."""
        self._log_seen = True
        if getattr(self, '_log_dlg', None) is not None:
            self._log_dlg.show()
            self._log_dlg.raise_()
            self._log_refresh()
            self._refresh_log_button()
            return

        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle('SMTL — session log')
        dlg.setStyleSheet(_theme.log_window_style())
        dlg.resize(720, 380)
        lay = QtWidgets.QVBoxLayout(dlg)

        row = QtWidgets.QHBoxLayout()
        self._log_filter = {}
        group = QtWidgets.QButtonGroup(dlg)
        group.setExclusive(True)
        for label, kind in (('All', None),
                            ('Warnings', _log.WARN),
                            ('Errors', _log.ERROR)):
            rb = QtWidgets.QRadioButton(label, dlg)
            group.addButton(rb)
            self._log_filter[rb] = kind
            row.addWidget(rb)
            if kind is None:
                rb.setChecked(True)
        group.buttonClicked.connect(lambda *_: self._log_refresh())
        row.addStretch()

        btn_clear = QtWidgets.QPushButton('Clear', dlg)
        btn_clear.setStyleSheet(_theme.push_button_style('default'))
        btn_clear.clicked.connect(
            lambda: (_log.clear(), setattr(self, '_log_seen', True),
                     self._log_refresh(), self._refresh_log_button()))
        btn_close = QtWidgets.QPushButton('Close', dlg)
        btn_close.setStyleSheet(_theme.push_button_style('default'))
        btn_close.clicked.connect(dlg.hide)
        row.addWidget(btn_clear)
        row.addWidget(btn_close)
        lay.addLayout(row)

        self._log_view = QtWidgets.QPlainTextEdit(dlg)
        self._log_view.setReadOnly(True)
        lay.addWidget(self._log_view)

        self._log_dlg = dlg
        self._log_refresh()
        self._refresh_log_button()
        dlg.show()

    def _log_refresh(self):
        """Redraw the log window for the selected filter."""
        if getattr(self, '_log_view', None) is None:
            return
        kind = None
        for rb, k in self._log_filter.items():
            if rb.isChecked():
                kind = k
                break
        entries = _log.entries(kind)
        self._log_view.clear()
        if not entries:
            self._log_view.appendHtml(
                f'<span style="color:{_theme.LOG_TIME_FG}">(nothing yet)</span>')
            return
        for e in entries:
            tail = f'  (x{e["count"]})' if e['count'] > 1 else ''
            when = time.strftime('%H:%M:%S', time.localtime(e['at']))
            body = html.escape(f'{e["kind"]:<5}  {e["message"]}{tail}')
            self._log_view.appendHtml(
                f'<span style="white-space:pre; color:{_theme.LOG_TIME_FG}">'
                f'{when}  </span>'
                f'<span style="white-space:pre; color:{_theme.log_kind_fg(e["kind"])}">'
                f'{body}</span>')
        self._log_view.verticalScrollBar().setValue(
            self._log_view.verticalScrollBar().maximum())

    def _refresh_log_button(self):
        """Colour the Log button for unseen warnings or errors."""
        if getattr(self, '_btn_log', None) is None:
            return
        dlg = getattr(self, '_log_dlg', None)
        if dlg is not None and dlg.isVisible():
            self._log_seen = True
        worst = _log.worst()
        unseen = (worst in (_log.WARN, _log.ERROR)
                  and not getattr(self, '_log_seen', True))
        if not unseen:
            variant = 'default'
        elif worst == _log.ERROR:
            variant = 'danger'
        else:
            variant = 'attention'
        if variant != self._log_btn_variant:
            self._log_btn_variant = variant
            set_button_style(self._btn_log, _theme.push_button_style(variant))
    def _set_status(self, text, kind=None):
        """Show a line in the status bar and record it in the log."""
        lbl = getattr(self, '_lbl_status', None)
        if lbl is not None:
            lbl.setText(text)
        kind = kind or _log.INFO
        _log.note(text, kind)
        if kind != _log.INFO:
            self._log_seen = False
        dlg = getattr(self, '_log_dlg', None)
        if dlg is not None and dlg.isVisible():
            self._log_refresh()
        self._refresh_log_button()

    def _ask_extend_past_media(self, clip, edge, wanted):
        """Offer to extend a refused trim past the media and apply it."""
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle('SMTL')
        box.setText('Allow trim past end of footage?')
        box.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        box.setDefaultButton(QtWidgets.QMessageBox.No)
        if box.exec_() != QtWidgets.QMessageBox.Yes:
            return

        if not self._timeline.apply_extend(clip, edge, wanted):
            return
        self._timeline.prune_all_transitions()
        self._sync_viewer_group('SMTL: Trim past media')
        self._refresh_status()
        self._set_status(f'{clip.display_label}: {edge} extended past its media.')

    def _export_clip_tc(self, clip):
        """Export the SMTL_TC node for a clip to the main DAG."""
        node = _export_tc_to_dag(clip)
        if node:
            self._refresh_status()

    def _add_layer(self):
        new = SMTLLayer(next_layer_name(self._layers))
        self._layers.append(new)
        self._add_idx = len(self._layers) - 1
        self._active_idx = self._add_idx
        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_viewer_group('SMTL: Add layer')
        self._refresh_merge_bar()
        self._refresh_status()

    def _remove_layer(self):
        if len(self._layers) <= 1:
            self._set_status('Cannot remove the only layer.', _log.WARN)
            return
        if self._layers[self._add_idx].locked:
            self._set_status(
                f'Track "{self._layers[self._add_idx].name}" is locked — '
                f'unlock it first.', _log.WARN)
            return
        removed = self._add_idx
        self._layers.pop(removed)
        n = len(self._layers)

        if self._active_idx > removed:
            self._active_idx -= 1
        elif self._active_idx == removed:
            self._active_idx = max(0, removed - 1)

        self._add_idx = max(0, min(removed, n - 1))

        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_viewer_group('SMTL: Remove layer')
        self._refresh_merge_bar()
        self._refresh_status()

    def _dissolve_prefs(self):
        """Return the dissolve, freeze and retime defaults as a dict."""
        return {'align':  self._dissolve_align,
                'length': self._dissolve_len,
                'before': self._dissolve_before,
                'after':  self._dissolve_after,
                'freeze': self._freeze_frames,
                'retime_speed':  self._retime_speed,
                'retime_kind':   self._retime_kind,
                'retime_mode':   self._retime_mode,
                'retime_ripple': self._retime_ripple}

    def _load_dissolve_prefs(self, d):
        """Load the dissolve, freeze and retime defaults from a dict."""
        if not d:
            return
        self._dissolve_align  = d.get('align',  self._dissolve_align)
        self._dissolve_len    = int(d.get('length', self._dissolve_len))
        self._dissolve_before = int(d.get('before', self._dissolve_before))
        self._dissolve_after  = int(d.get('after',  self._dissolve_after))
        self._freeze_frames   = int(d.get('freeze',  self._freeze_frames))
        try:
            self._retime_speed = float(d.get('retime_speed',
                                             self._retime_speed))
        except (TypeError, ValueError):
            pass
        kind = d.get('retime_kind', self._retime_kind)
        self._retime_kind   = kind if kind in RETIME_NODES else RETIME_TIMEWARP
        mode = d.get('retime_mode', self._retime_mode)
        self._retime_mode   = mode if mode in ('resize', 'keep') else 'keep'
        self._retime_ripple = bool(d.get('retime_ripple', self._retime_ripple))
        if getattr(self, '_btn_clip_dissolve', None) is not None:
            self._refresh_dissolve_tip()

    def _dissolve_here(self):
        """Return the dissolve in question as (layer_idx, transition) or None."""
        sel = self._timeline._sel_trans
        if (sel is not None and 0 <= sel[0] < len(self._layers)
                and sel[1] in self._layers[sel[0]].transitions):
            return sel

        idx = self._add_idx
        if not (0 <= idx < len(self._layers)):
            return None
        layer   = self._layers[idx]
        anchors = transition_anchors(layer.clips)
        if not anchors:
            return None
        at = min(anchors, key=lambda a: abs(a - self._timeline._cursor_frame))
        tr = next((t for t in layer.transitions if t.at_frame == at), None)
        return None if tr is None else (idx, tr)

    def _read_dissolve(self, tr):
        """Load an existing dissolve's shape into the settings."""
        self._dissolve_before = int(tr.before)
        self._dissolve_after  = int(tr.after)
        n = self._dissolve_before + self._dissolve_after
        if not self._dissolve_before:
            self._dissolve_align, self._dissolve_len = 'start', n
        elif not self._dissolve_after:
            self._dissolve_align, self._dissolve_len = 'end', n
        elif abs(self._dissolve_before - self._dissolve_after) <= 1:
            self._dissolve_align, self._dissolve_len = 'centre', n
        else:
            self._dissolve_align = 'custom'

    def _dissolve_shape(self):
        """Return (before, after) frames for the next dissolve."""
        if self._dissolve_align == 'custom':
            return self._dissolve_before, self._dissolve_after
        n = self._dissolve_len or default_transition_frames()
        if self._dissolve_align == 'start':
            return 0, n
        if self._dissolve_align == 'end':
            return n, 0
        return n // 2, n - n // 2

    def _dissolve_summary(self):
        before, after = self._dissolve_shape()
        names = {'centre': 'Centred', 'start': 'Start at cut',
                 'end': 'End at cut', 'custom': 'Custom'}
        return (f'{names.get(self._dissolve_align, "Centred")}, '
                f'{before + after} frames (-{before}/+{after})')

    def _refresh_dissolve_tip(self, shift=False):
        """Update the dissolve button's label, mark and tooltip."""
        label = '+ S Dissolve' if shift else '+ Dissolve'
        shape = self._dissolve_summary() + '.'
        before, after = self._dissolve_shape()
        set_face_mark(self._btn_clip_dissolve, before, after,
                      self._dissolve_align == 'custom')
        apply_button_face(
            self._btn_clip_dissolve, label, self._icons_dir,
            _tips.tip('+_s_dissolve' if shift else '+_dissolve', shape=shape))

    def _dissolve_menu(self):
        """Show the dissolve settings menu and add a dissolve."""
        was = (self._dissolve_align, self._dissolve_len,
               self._dissolve_before, self._dissolve_after)

        here = self._dissolve_here()
        if here is not None:
            self._read_dissolve(here[1])

        menu = StickyMenu(self)
        menu.setStyleSheet(_theme.menu_style())

        if here is not None:
            what = menu.addAction(
                f'Dissolve at {here[1].at_frame}  '
                f'(-{here[1].before}/+{here[1].after})')
            what.setEnabled(False)
            menu.addSeparator()

        head = menu.addAction('Alignment')
        head.setEnabled(False)
        aligns = []
        for key, label in (('centre', 'Centred on the cut'),
                           ('start',  'Start at the cut'),
                           ('end',    'End at the cut')):
            act = menu.addAction('   ' + label)
            act.setCheckable(True)
            aligns.append((act, key))
        act_custom = menu.addAction('   Custom…')

        menu.addSeparator()
        head = menu.addAction('Length')
        head.setEnabled(False)
        fps     = default_transition_frames()
        lengths = []
        for label, frames in ((f'{max(1, fps // 2)} frames', max(1, fps // 2)),
                              ('1 second',  fps),
                              ('2 seconds', fps * 2)):
            act = menu.addAction(f'   {label}'
                                 + (f'  ({frames})' if 'frame' not in label else ''))
            act.setCheckable(True)
            lengths.append((act, frames))

        menu.addSeparator()
        chose = ['cancel']
        row   = QtWidgets.QWidget()
        row_l = QtWidgets.QHBoxLayout(row)
        row_l.setContentsMargins(8, 2, 8, 2)
        row_l.setSpacing(6)
        row_l.addStretch(1)
        for name, key in (('Add', 'add'), ('Add S', 'add_s'), ('Cancel', 'cancel')):
            btn = QtWidgets.QPushButton(name)
            set_button_style(btn, _theme.push_button_style('default'))
            btn.clicked.connect(
                lambda _=False, k=key: (chose.__setitem__(0, k), menu.close()))
            row_l.addWidget(btn)
        holder = QtWidgets.QWidgetAction(menu)
        holder.setDefaultWidget(row)
        menu.addAction(holder)

        def _sync():
            n = self._dissolve_len or default_transition_frames()
            for act, key in aligns:
                act.setChecked(self._dissolve_align == key)
            for act, frames in lengths:
                act.setChecked(self._dissolve_align != 'custom' and n == frames)
            act_custom.setText('   Custom…' if self._dissolve_align != 'custom'
                               else f'   Custom…  (-{self._dissolve_before}'
                                    f'/+{self._dissolve_after})')

        def _set_align(key):
            self._dissolve_align = key
            _sync()

        def _set_length(frames):
            self._dissolve_len = frames
            if self._dissolve_align == 'custom':
                self._dissolve_align = 'centre'
            _sync()

        for act, key in aligns:
            act.triggered.connect(lambda _=False, k=key: _set_align(k))
        for act, frames in lengths:
            act.triggered.connect(lambda _=False, f=frames: _set_length(f))
        _sync()

        chosen = menu.exec_(QtGui.QCursor.pos())

        if chosen is act_custom:
            if not self._ask_custom_dissolve():
                (self._dissolve_align, self._dissolve_len,
                 self._dissolve_before, self._dissolve_after) = was
                return
        elif chose[0] == 'cancel':
            (self._dissolve_align, self._dissolve_len,
             self._dissolve_before, self._dissolve_after) = was
            self._refresh_dissolve_tip()
            return

        self._refresh_dissolve_tip()
        self._save_state()
        self._add_dissolve(curve='smooth' if chose[0] == 'add_s' else 'linear',
                           at=here)

    def _ask_custom_dissolve(self):
        """Ask for a custom before/after split; return True if accepted."""
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle('Custom Dissolve')
        form = QtWidgets.QFormLayout(dlg)
        form.setContentsMargins(16, 14, 16, 14)
        form.setSpacing(12)
        form.setHorizontalSpacing(14)
        sp_b = QtWidgets.QSpinBox(dlg)
        sp_b.setRange(0, 9999)
        sp_b.setMinimumWidth(80)
        sp_b.setValue(self._dissolve_before)
        sp_a = QtWidgets.QSpinBox(dlg)
        sp_a.setRange(0, 9999)
        sp_a.setMinimumWidth(80)
        sp_a.setValue(self._dissolve_after)
        form.addRow('Before', sp_b)
        form.addRow('After',  sp_a)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel,
            parent=dlg)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        form.addRow(buttons)
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return False
        if sp_b.value() + sp_a.value() < 1:
            self._set_status('A dissolve needs at least one frame.', _log.WARN)
            return False
        self._dissolve_before = sp_b.value()
        self._dissolve_after  = sp_a.value()
        self._dissolve_align  = 'custom'
        return True

    def _freeze_frame(self):
        """Freeze the frame under the playhead onto the edit-target layer."""
        found = self._timeline.clip_under_cursor()
        if found is None:
            self._set_status('Park the playhead on a selected clip first.', _log.WARN)
            return
        _layer_idx, clip = found
        cursor = self._timeline._cursor_frame
        src    = tl_to_src(clip, cursor)

        answer = self._ask_freeze(clip, src)
        if answer is None:
            return
        frames, mode = answer

        if frames != self._freeze_frames:
            self._freeze_frames = frames
            self._save_state()

        node = make_freeze_node(clip.node_name, src, label=clip.label)
        if node is None:
            self._set_status(f'Could not freeze {clip.display_label}.', _log.ERROR)
            return

        new_clip = self._timeline.add_read(node, self._add_idx, mode=mode,
                                           duration=frames)
        if new_clip is None:
            self._set_status('Freeze made, but it would not fit here.', _log.WARN)
            return
        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_viewer_group('SMTL: Freeze frame')
        self._refresh_status()
        self._set_status(
            f'Froze {clip.display_label} at {src} — {frames} frames, '
            f'{"spliced in" if mode == "splice" else "overwritten"}.')

    def _ask_freeze(self, clip, src):
        """Ask for freeze length and mode; return (frames, mode) or None."""
        default = self._freeze_frames or (
            _STILL_SECONDS * default_transition_frames())
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle('Freeze Frame')
        form = QtWidgets.QVBoxLayout(dlg)
        form.addWidget(QtWidgets.QLabel(
            f'{clip.label} — hold frame {src}'))
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel('Duration (frames):'))
        spin = QtWidgets.QSpinBox(dlg)
        spin.setRange(1, 999999)
        spin.setValue(int(default))
        row.addWidget(spin)
        form.addLayout(row)

        buttons = QtWidgets.QDialogButtonBox(parent=dlg)
        b_over  = buttons.addButton('Overwrite',
                                    QtWidgets.QDialogButtonBox.AcceptRole)
        b_splice = buttons.addButton('Splice In',
                                     QtWidgets.QDialogButtonBox.AcceptRole)
        buttons.addButton(QtWidgets.QDialogButtonBox.Cancel)
        form.addWidget(buttons)

        chosen = {}
        b_over.clicked.connect(lambda: chosen.update(mode='overwrite'))
        b_splice.clicked.connect(lambda: chosen.update(mode='splice'))
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)

        if dlg.exec_() != QtWidgets.QDialog.Accepted or 'mode' not in chosen:
            return None
        return int(spin.value()), chosen['mode']

    def _join_match_edit(self, layer, left, right):
        """Join two clips across a match edit."""
        if layer_blocked(layer):
            why = 'muted' if getattr(layer, 'hidden', False) else 'locked'
            self._set_status(f'Track "{layer.name}" is {why}.', _log.WARN)
            return
        at = right.first_frame
        if not join_match_edit(layer.clips, left, right):
            self._set_status('Those two no longer join.', _log.WARN)
            return
        self._sync_viewer_group('SMTL: Remove match edit')
        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._timeline._clear_selection(keep=left)
        self._refresh_status()
        self._set_status(f'Match edit at {at} removed — '
                         f'{left.display_label} is one clip again.')


    def _retime_clips(self):
        """Set the speed of every selected clip."""
        pairs = self._selected_clip_pairs()
        if not pairs:
            self._set_status('Select a clip to retime.', _log.WARN)
            return
        if self._locked_now():
            self._set_status('That layer is locked.', _log.WARN)
            return

        answer = self._ask_retime(pairs)
        if answer is None:
            return
        speed, kind, mode, ripple = answer

        self._retime_kind, self._retime_mode = kind, mode
        self._retime_ripple = ripple
        self._retime_speed  = speed
        self._save_state()

        layers, clamped = [], []
        for layer, clip in pairs:
            out = resolve_retime(layer.clips, clip, speed,
                                 mode=mode, ripple=ripple)
            clip.retime_node = kind
            if out.get('clamped'):
                clamped.append(clip)
            if layer not in layers:
                layers.append(layer)

        self._timeline.prune_all_transitions()

        moved  = [(self._layers.index(l), c) for l in layers for c in l.clips]
        spans  = [(l, c) for l in layers for c in l.clips]
        pushed = [(l, c) for l, c in spans if not any(c is pc for _pl, pc in pairs)]

        with _undo_group('SMTL: Retime'):
            _sync_tc_start_positions(self._layers, moved)
            _update_retime(pairs, reset=True)
            _update_retime(pushed)
            _update_merge_settings(spans)
            self._save_state()

        self._timeline.update()
        self._refresh_status()
        n   = len(pairs)
        pct = ('%g' % (speed * 100.0)).rstrip('.')
        msg = (f'{pct}% on {n} clip{"" if n == 1 else "s"} — {kind}.')
        if clamped:
            msg += (f'  {len(clamped)} ran out of material and stopped '
                    f'where it did.')
        self._set_status(msg, _log.WARN if clamped else _log.INFO)

    def _ask_retime(self, pairs):
        """Ask for retime settings; return (speed, kind, mode, ripple) or None."""
        rate  = root_fps() or 25.0
        first = pairs[0][1]

        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle('Retime')
        form = QtWidgets.QVBoxLayout(dlg)
        form.setContentsMargins(16, 14, 16, 14)
        form.setSpacing(12)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(10)
        row.addWidget(QtWidgets.QLabel('Speed'))
        pct = PlainDoubleSpinBox(dlg)
        pct.setDecimals(2)
        pct.setRange(-100000.0, 100000.0)
        pct.setSuffix(' %')
        pct.setMinimumWidth(90)
        start_speed = first.speed if first.retime_node else self._retime_speed
        pct.setValue(start_speed * 100.0)
        row.addWidget(pct)
        fps = PlainDoubleSpinBox(dlg)
        fps.setDecimals(3)
        fps.setRange(-100000.0, 100000.0)
        fps.setSuffix(' fps')
        fps.setMinimumWidth(100)
        fps.setValue(start_speed * rate)
        row.addWidget(fps)
        row.addStretch()
        form.addLayout(row)

        busy = {'in': False}

        def _from_pct(v):
            if busy['in']:
                return
            busy['in'] = True
            fps.setValue(v / 100.0 * rate)
            busy['in'] = False

        def _from_fps(v):
            if busy['in']:
                return
            busy['in'] = True
            pct.setValue(v / rate * 100.0)
            busy['in'] = False

        pct.valueChanged.connect(_from_pct)
        fps.valueChanged.connect(_from_fps)

        node_row = QtWidgets.QHBoxLayout()
        node_row.setSpacing(10)
        node_row.addWidget(QtWidgets.QLabel('Node'))
        combo = QtWidgets.QComboBox(dlg)
        combo.setMinimumWidth(180)
        nukex = _have_nukex()
        for kind in RETIME_NODES:
            text = _RETIME_LABEL.get(kind, kind)
            if kind in RETIME_NEEDS_NUKEX and not nukex:
                text += '   (NukeX required)'
            combo.addItem(text, kind)
            if kind in RETIME_NEEDS_NUKEX and not nukex:
                item = combo.model().item(combo.count() - 1)
                if item is not None:
                    item.setEnabled(False)
        want = first.retime_node or self._retime_kind
        idx  = combo.findData(want)
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        node_row.addWidget(combo)
        node_row.addStretch()
        form.addLayout(node_row)

        choices = QtWidgets.QVBoxLayout()
        choices.setSpacing(8)
        choices.setContentsMargins(0, 4, 0, 4)
        r_keep   = QtWidgets.QRadioButton('Keep duration', dlg)
        r_over   = QtWidgets.QRadioButton('Overwrite', dlg)
        r_ripple = QtWidgets.QRadioButton('Ripple', dlg)
        for r in (r_keep, r_over, r_ripple):
            choices.addWidget(r)
        (r_ripple if self._retime_mode == 'resize' and self._retime_ripple
         else r_over if self._retime_mode == 'resize'
         else r_keep).setChecked(True)
        form.addLayout(choices)

        buttons = QtWidgets.QDialogButtonBox(parent=dlg)
        buttons.addButton('Retime', QtWidgets.QDialogButtonBox.AcceptRole)
        buttons.addButton(QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        form.addWidget(buttons)

        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return None
        kind = combo.itemData(combo.currentIndex()) or RETIME_TIMEWARP
        mode = 'keep' if r_keep.isChecked() else 'resize'
        return pct.value() / 100.0, kind, mode, bool(r_ripple.isChecked())

    def _set_retime_kind(self, layer, clip, kind):
        """Change which node renders an existing retime."""
        if clip.retime_node == kind:
            return
        old, clip.retime_node = clip.retime_node, kind
        with _undo_group('SMTL: Retime node'):
            _update_retime([(layer, clip)])
            self._save_state()
        self._timeline.update()
        self._set_status(
            f'{clip.display_label}: {old} → {kind}.  The curve came across; '
            f'the old node\'s settings did not.')

    def _remove_retime(self, layer, clip):
        """Remove a clip's retime and its node."""
        if not clip.retime_node:
            return
        resolve_retime(layer.clips, clip, 1.0, mode='keep')
        clip.retime_node = None
        self._timeline.prune_all_transitions()
        lyr_idx = self._layers.index(layer)
        with _undo_group('SMTL: Remove retime'):
            _sync_tc_start_positions(self._layers, [(lyr_idx, clip)])
            _update_retime([(layer, clip)])
            _update_merge_settings([(layer, c) for c in layer.clips])
            self._save_state()
        self._timeline.update()
        self._refresh_status()
        self._set_status(f'Retime removed from {clip.display_label}.')

    def _add_dissolve(self, curve='linear', at=None):
        """Add a dissolve at the chosen join."""
        before, after = self._dissolve_shape()
        lyr_idx = frame = None
        if at is not None:
            lyr_idx, frame = at[0], at[1].at_frame
        asked = before + after

        _at, would_before, would_after, why = self._timeline.plan_transition(
            layer_idx=lyr_idx, frame=frame, before=before, after=after)
        if why:
            self._set_status(why, _log.WARN)
            self._say(why)
            return
        if would_before + would_after < asked:
            if not self._ask('Not enough frames for a %d frame transition.\n\n'
                             'Trim to available (-%d/+%d)?'
                             % (asked, would_before, would_after)):
                self._set_status('Dissolve cancelled.')
                return

        tr, msg = self._timeline.add_transition(
            layer_idx=lyr_idx, frame=frame, before=before, after=after,
            curve=curve)
        if tr is None:
            why = msg or 'Cannot add a dissolve here.'
            self._set_status(why, _log.WARN)
            self._say(why)
            return
        self._sync_viewer_group('SMTL: Add dissolve')
        self._refresh_status()
        self._set_status(msg or f'Dissolve at {tr.at_frame}, {tr.length} frames.',
                         _log.WARN if msg else _log.INFO)

    def _select_dissolve_curve(self):
        """Open the selected dissolve's Dissolve node."""
        sel = self._timeline._sel_trans
        if sel is None:
            return
        lyr_idx, tr = sel
        if not (0 <= lyr_idx < len(self._layers)):
            return
        try:
            t_idx = self._layers[lyr_idx].transitions.index(tr)
        except ValueError:
            return
        node = show_dissolve_node(self._layers, lyr_idx, t_idx)
        if node is None:
            self._set_status(
                f'No node for dissolve {lyr_idx}/{t_idx} — rebuild first.', _log.WARN)
        else:
            self._set_status(f'{node.name()} open — its curve is in the '
                             f'Curve Editor and Dope Sheet.')

    def _on_transition_changed(self):
        """Rebuild and save after a dissolve is trimmed or slid."""
        self._sync_viewer_group('SMTL: Trim dissolve')
        self._refresh_status()

    def _remove_dissolve(self):
        """Remove the selected dissolve; return True if one is removed."""
        if not self._timeline.remove_selected_transition():
            return False
        self._sync_viewer_group('SMTL: Remove dissolve')
        self._refresh_status()
        return True

    def _move_layer(self, idx, delta):
        """Swap a layer with its neighbour: delta +1 up, -1 down."""
        j = idx + delta
        if not (0 <= idx < len(self._layers) and 0 <= j < len(self._layers)):
            return
        if getattr(self._layers[idx], 'locked', False):
            self._set_status('Track is locked.', _log.WARN)
            return

        self._layers[idx], self._layers[j] = self._layers[j], self._layers[idx]
        if self._add_idx == idx:
            self._add_idx = j
        elif self._add_idx == j:
            self._add_idx = idx

        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_viewer_group('SMTL: Move layer')
        self._refresh_merge_bar()
        self._refresh_status()


    def _save_state(self):
        """Save the timeline state into the SMTL_Group node knob."""
        _save_timeline_to_node(
            self._layers,
            self._active_idx,
            self._add_idx,
            self._timeline._cursor_frame,
            timeline_start = self._timeline._tl_start,
            timeline_end   = self._timeline._tl_end,
            mark_in        = self._timeline._mark_in,
            mark_out       = self._timeline._mark_out,
            ghost_in       = self._timeline._ghost_in,
            ghost_out      = self._timeline._ghost_out,
            dissolve       = self._dissolve_prefs(),
        )
        self._state_seen = read_state_blob()

    def _sync_viewer_group(self, undo_label=None):
        """Rebuild SMTL_Group internals from the timeline state."""
        self._timeline.prune_all_transitions()
        solo_idx = next((i for i, l in enumerate(self._layers) if l.solo), None)
        offline = read_offline_now(self._layers)
        self._timeline._freeze_nodes = freeze_nodes_now(self._layers)
        if undo_label:
            with _undo_group(undo_label):
                _rebuild_group(self._layers, self._active_idx,
                               solo_idx=solo_idx, offline=offline)
                self._save_state()
        else:
            _rebuild_group(self._layers, self._active_idx,
                           solo_idx=solo_idx, offline=offline)
            self._save_state()
        has_clips = any(layer.clips for layer in self._layers)
        if has_clips and not self._had_clips:
            link_viewer_if_needed()
        self._had_clips = has_clips
        self._update_fs_watcher()


    def _ask_import_options(self, edl_first_frame, probe_rate, drop,
                            stated_rate=None, what='EDL', bundle=None):
        """Ask the import rate, start and bundle options; None if cancelled."""
        if self._import_options is not None and bundle is None:
            return self._import_options + (False, BUNDLE_NONE)

        rate = root_fps() or 24.0
        edl_tc    = frames_to_timecode(edl_first_frame, probe_rate, bool(drop))
        script_tc = frames_to_timecode(self._timeline._tl_start, rate,
                                       is_drop_frame_rate(rate))

        dlg = ImportOptionsDialog(rate, edl_tc, script_tc, self,
                                  stated_rate=stated_rate, what=what,
                                  drop=drop, bundle=bundle)
        if not dlg.exec_():
            return None

        rate  = dlg.rate()
        start = dlg.start_frames()
        if start is None:
            return None
        media = BundleChoice(dlg.extract_media(), dlg.extract_beside(),
                             dlg.extract_path(), dlg.media_as_reference()) \
            if bundle is not None else BUNDLE_NONE

        first = self._import_options is None
        self._import_options = (float(rate), int(start))
        return self._import_options + (first, media)

    def _place_tracks(self, built, suffix=''):
        """Put each built track on an empty layer; return (layers, notes)."""
        notes = []
        idx   = self._add_idx
        first = self._layers[idx]
        reuse = (not first.clips) and (not layer_blocked(first))
        if not reuse:
            notes.append('%s is %s, so the import went above it'
                         % (first.name,
                            'locked' if layer_blocked(first) else 'not empty'))

        landed = []
        for n, (track, res) in enumerate(built):
            if n == 0 and reuse and not suffix:
                layer = first
                if track and track.get('name'):
                    layer.name = track['name']
            else:
                idx += 1
                layer = SMTLLayer(
                    ((track or {}).get('name')
                     or next_layer_name(self._layers)) + suffix)
                self._layers.insert(idx, layer)
            if track is not None:
                layer.hidden = bool(track.get('hidden', False))
            layer.clips.extend(res.clips)
            layer.clips.sort(key=lambda c: c.first_frame)
            layer.transitions.extend(res.transitions)
            layer.transitions.sort(key=lambda t: t.at_frame)
            landed.append(layer)

        self._add_idx = self._active_idx = idx
        return landed, notes

    def _apply_import_range(self, rate, first, last, establish):
        """Set the script fps, start, end and range lock for an import."""
        if abs(float(rate) - (root_fps() or 0.0)) > 1e-6:
            try:
                import nuke
                nuke.root()['fps'].setValue(float(rate))
                _log.note('[SMTL] Import: script fps set to %g' % rate)
            except Exception as e:
                _log.note('[SMTL] Import: root fps not set to %g: %s'
                          % (rate, e), _log.WARN)
        if establish:
            self._spin_start.setValue(int(first))
            self._on_spin_start_edited()

        try:
            import nuke
            root_last = int(nuke.root()['last_frame'].value())
        except Exception:
            root_last = int(self._spin_end.value())
        want = max(int(last), root_last, int(self._timeline._tl_end))
        if want != root_last or want != int(self._spin_end.value()):
            self._spin_end.setValue(want)
            self._on_spin_end_edited()
            _log.note('[SMTL] Import: last frame %d' % want)

        try:
            import nuke
            nuke.root()['lock_range'].setValue(True)
        except Exception as e:
            _log.note('[SMTL] Import: root lock_range not set: %s' % e,
                      _log.WARN)

    def _on_import_clicked(self):
        """Import an edit list onto the selected layer."""
        try:
            import nuke
        except Exception:
            self._set_status('Import needs Nuke.', _log.WARN)
            return
        pattern = ' '.join('*%s' % e for e in sorted(_parse.PARSERS))
        path = nuke.getFilename('SMTL — import an edit list', pattern)
        if not path:
            return

        ext = os.path.splitext(path)[1].lower()
        parser = _parse.PARSERS.get(ext)
        if parser is None:
            self._set_status('No parser for %s files yet.' % (ext or '?'),
                             _log.WARN)
            return
        if ext in _parse.WANTS_PATH:
            text = path
        else:
            try:
                with open(path, encoding='utf-8', errors='replace') as fh:
                    text = fh.read()
            except Exception as e:
                self._set_status('Could not read %s: %s'
                                 % (os.path.basename(path), e), _log.WARN)
                return

        try:
            probe_rate = root_fps() or 24.0
            probe = parser(text, probe_rate)
        except Exception as e:
            self._set_status('Could not parse %s: %s'
                             % (os.path.basename(path), e), _log.WARN)
            return
        if probe.start() is None:
            self._set_status('Nothing to import from %s.'
                             % os.path.basename(path), _log.WARN)
            return

        bundle = None
        if ext == '.otioz':
            try:
                held = _parse.otioz_media(path)
            except Exception as e:
                self._set_status('Could not read the bundle: %s' % e,
                                 _log.WARN)
                return
            total = sum(n for _f, n in held)
            bundle = ('OTIOZ carries %d media file%s, %s.'
                      % (len(held), '' if len(held) == 1 else 's',
                         _size_text(total))) if held else \
                'OTIOZ carries no media.'

        chosen = self._ask_import_options(
            probe.start(), probe_rate, probe.drop,
            stated_rate=probe.stated_rate, what=ext.lstrip('.').upper(),
            bundle=bundle)
        if chosen is None:
            return
        rate, anchor, establish, media = chosen

        extracted = {}
        if media.extract:
            dest = media.folder(path)
            try:
                extracted = _parse.extract_otioz(path, dest)
            except Exception as e:
                self._set_status('Could not extract the media: %s' % e,
                                 _log.WARN)
                return
            _log.note('[SMTL] Import: %d media file(s) extracted to %s'
                      % (len(extracted), dest))

        try:
            cut = parser(text, rate)
        except Exception as e:
            self._set_status('Could not parse %s: %s'
                             % (os.path.basename(path), e), _log.WARN)
            return
        anchor_in = cut.start()
        if anchor_in is None:
            self._set_status('Nothing to import from %s.'
                             % os.path.basename(path), _log.WARN)
            return

        if establish:
            offset = anchor - anchor_in
            self._import_offset = offset
        else:
            offset = self._import_offset
        start_frame = anchor_in + offset

        built = _importer.build_tracks(cut, start_frame)
        built = [(t, r) for t, r in built if r.clips]
        if not built:
            self._set_status('Nothing to import from %s.'
                             % os.path.basename(path), _log.WARN)
            return

        ref_layers, ref_clips = [], []
        if media.reference:
            ref = _importer.build_tracks(cut, start_frame)
            ref = [(t, r) for t, r in ref if r.clips]
            for _t, res in ref:
                point_at_extracted(res.clips, extracted)
            ref_layers = self._place_tracks(ref, suffix=' (reference)')[0]
            ref_clips  = [c for _t, r in ref for c in r.clips]
        elif media.extract:
            for _t, res in built:
                point_at_extracted(res.clips, extracted)

        landed, notes = self._place_tracks(built)
        result = built[0][1]
        for _t, res in built:
            notes.extend(res.notes)
        self._apply_import_range(
            rate, cut.start() + offset, cut.end() + offset, establish)

        for note in notes:
            _log.note('[SMTL] Import: %s' % note, _log.WARN)

        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_viewer_group('SMTL: Import edit list')
        self._refresh_merge_bar()
        self._refresh_status()

        if media.extract:
            to_bind = ref_clips if media.reference else \
                [c for _t, r in built for c in r.clips]
            self._run_conform(to_bind, _conform.SearchSpec(
                search_in=_conform.ORIGINAL_PATH), label='Bundle media')
            for layer in ref_layers:
                layer.locked = True
            if ref_layers:
                self._timeline.set_layers(self._layers, self._active_idx,
                                          add_idx=self._add_idx)
                self._sync_viewer_group('SMTL: Bundle reference')

        extra = ''
        if result.ignored.get('audio'):
            extra += ', %d audio ignored' % result.ignored['audio']
        n_clips = sum(len(r.clips) for _t, r in built)
        self._set_status(
            'Imported %d clip%s onto %s at %g fps%s — offline until '
            'conformed.'
            % (n_clips, '' if n_clips == 1 else 's',
               ', '.join(l.name for l in landed), rate, extra))

    def _media_facts(self):
        """Return a MediaFacts per clip id, read from the DAG."""
        names = set()
        for layer in self._layers:
            for clip in layer.clips:
                if clip.node_name and clip.node_name != _NO_MEDIA:
                    names.add(clip.node_name)
        found = node_media_facts(names)
        out = {}
        for layer in self._layers:
            for clip in layer.clips:
                info = found.get(clip.node_name)
                if info is None:
                    continue
                out[clip.clip_id] = _exporter.MediaFacts(
                    path=info['path'], start_tc=info['start_tc'],
                    start_frame=info['start_frame'], rate=info['rate'],
                    available=info['available'], node=clip.node_name,
                    hold=info.get('hold'))
        return out

    def _on_export_clicked(self):
        """Write the timeline out as OTIO."""
        try:
            import nuke
        except Exception:
            self._set_status('Export needs Nuke.', _log.WARN)
            return
        if not any(layer.clips for layer in self._layers):
            self._set_status('Nothing to export — the timeline is empty.',
                             _log.WARN)
            return

        script = ''
        try:
            script = str(nuke.root().name() or '')
        except Exception:
            script = ''
        if not script or script == 'Root':
            try:
                nuke.scriptSaveAs()
                script = str(nuke.root().name() or '')
            except Exception as e:
                _log.note('[SMTL] Export: save cancelled (%s)' % e, _log.WARN)
                script = ''
            if not script or script == 'Root':
                self._set_status('Export needs the script saved first — it '
                                 'records where the timeline came from.',
                                 _log.WARN)
                return

        stem = os.path.splitext(os.path.basename(script))[0] or 'timeline'
        default = os.path.join(os.path.dirname(script), stem + '.otio')
        path = nuke.getFilename('SMTL — export OTIO', '*.otio', default,
                                type='save')
        if not path:
            return
        if not os.path.splitext(path)[1]:
            path += '.otio'

        rate  = root_fps() or 24.0
        first = _root_first_frame()
        document, notes = _exporter.build(
            self._layers, first, rate, media=self._media_facts(),
            name=stem, script=script)
        try:
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(_exporter.to_json(document))
        except Exception as e:
            self._set_status('Could not write %s: %s'
                             % (os.path.basename(path), e), _log.WARN)
            return

        for note in notes:
            _log.note('[SMTL] Export: %s' % note, _log.WARN)

        n_clips = sum(len(layer.clips) for layer in self._layers)
        extra = '' if not notes else ' — %d note%s in the script editor' % (
            len(notes), '' if len(notes) == 1 else 's')
        self._set_status('Exported %d clip%s to %s%s.'
                         % (n_clips, '' if n_clips == 1 else 's',
                            os.path.basename(path), extra))

    def _on_conform_clicked(self):
        """Conform clips without media through the conform dialog."""
        try:
            import nuke
        except Exception:
            self._set_status('Conform needs Nuke.', _log.WARN)
            return

        waiting = [c for layer in self._layers for c in layer.clips
                   if c.is_placeholder and not layer.locked]
        sel    = set(self._timeline.selection())
        chosen = [c for c in waiting if c in sel]

        dlg = ConformOptionsDialog(len(waiting), len(chosen), parent=self,
                                   have_paths=any(c.src_path for c in waiting),
                                   have_names=any(c.src_name for c in waiting),
                                   have_reels=any(_conform.is_reel(c.src_reel)
                                                  for c in waiting))
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return
        spec = dlg.spec()
        clips = chosen if (dlg.selected_only() and chosen) else waiting
        self._run_conform(clips, spec)

    def _alpha_menu(self, clip, global_pos):
        """Show the alpha mode menu for a clip and apply the choice."""
        menu = StickyMenu(self)
        menu.setStyleSheet(_theme.menu_style())

        what = menu.addAction(clip.display_label)
        what.setEnabled(False)
        menu.addSeparator()

        premult = menu.addAction('Premultiply')
        premult.setCheckable(True)
        premult.setChecked(bool(clip.alpha_premult))
        premult.setEnabled(clip.alpha_mode in (ALPHA_USE, ALPHA_INVERT))
        menu.addSeparator()

        picked = [clip.alpha_mode]
        acts   = []
        for key, label in ALPHA_MODES:
            act = menu.addAction(label)
            act.setCheckable(True)
            act.setChecked(clip.alpha_mode == key)
            acts.append((act, key))

        def choose(key):
            picked[0] = key
            for act, k in acts:
                act.setChecked(k == key)
            premult.setEnabled(key in (ALPHA_USE, ALPHA_INVERT))

        for act, key in acts:
            act.triggered.connect(lambda _c=False, k=key: choose(k))

        menu.addSeparator()
        scope = menu.addAction('Every clip on this source')
        scope.setCheckable(True)

        menu.addSeparator()
        go = [False]
        row = QtWidgets.QWidget()
        lay = QtWidgets.QHBoxLayout(row)
        lay.setContentsMargins(8, 2, 8, 2)
        lay.setSpacing(6)
        b_apply  = QtWidgets.QPushButton('Apply')
        b_cancel = QtWidgets.QPushButton('Cancel')
        for b in (b_apply, b_cancel):
            set_button_style(b, _theme.push_button_style('default'))
        b_apply.clicked.connect(lambda: (go.__setitem__(0, True), menu.close()))
        b_cancel.clicked.connect(menu.close)
        lay.addStretch(1)
        lay.addWidget(b_apply)
        lay.addWidget(b_cancel)
        holder = QtWidgets.QWidgetAction(menu)
        holder.setDefaultWidget(row)
        menu.addAction(holder)

        menu.exec_(global_pos)
        if go[0]:
            self._set_alpha_mode(clip, picked[0], premult.isChecked(),
                                 whole_source=scope.isChecked())

    def _set_alpha_mode(self, clip, mode, premult=False, whole_source=False):
        """Set the alpha mode on the clip, its selection, or its whole source."""
        if whole_source:
            targets = [c for lyr in self._layers for c in lyr.clips
                       if c.node_name == clip.node_name
                       and not layer_blocked(lyr)]
        else:
            sel = set(self._timeline.selection())
            targets = [c for lyr in self._layers for c in lyr.clips
                       if (c is clip or c in sel) and not layer_blocked(lyr)]
            if clip not in targets:
                targets = [clip]
        if not targets:
            return
        for c in targets:
            c.alpha_mode    = mode
            c.alpha_premult = bool(premult)
        self._sync_viewer_group('SMTL: Alpha')
        self._timeline.update()
        said = dict(ALPHA_MODES).get(mode, mode)
        self._set_status('%s%s on %d clip%s.'
                         % (said, ', premultiplied' if premult else '',
                            len(targets), '' if len(targets) == 1 else 's'))

    def _on_reconform(self, clip):
        """Reconform the selected clips, or the clicked one, from their cut."""
        try:
            import nuke
        except Exception:
            self._set_status('Reconform needs Nuke.', _log.WARN)
            return
        sel = set(self._timeline.selection())
        clips = [c for layer in self._layers for c in layer.clips
                 if c in sel and not layer_blocked(layer)]
        if clip not in clips:
            clips = [clip]
        clips = [c for c in clips if c.src_tc and c.src_rate > 0]
        if not clips:
            self._set_status('Nothing here to reconform.', _log.WARN)
            return
        dlg = ConformOptionsDialog(len(clips), 0, parent=self,
                                   have_paths=any(c.src_path for c in clips),
                                   have_names=any(c.src_name for c in clips),
                                   have_reels=any(_conform.is_reel(c.src_reel)
                                                  for c in clips))
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return
        self._run_conform(clips, dlg.spec(), label='Reconform',
                          unconform_first=True)

    def _run_conform(self, clips, spec, label='Conform', unconform_first=False):
        """Find media for clips and bind to it in one undo group."""
        notes = []
        was_nodes = set()
        if unconform_first:
            keep = []
            for clip in clips:
                was_nodes.add(clip.node_name)
                if node_class(clip.node_name) == 'FrameHold':
                    clip.speed = 0.0
                info = self._source_tc_info(clip.node_name)
                if _conform.unconform(clip,
                                      media_rate=(info[2] if info else 0.0)):
                    keep.append(clip)
                else:
                    notes.append('%s came from the DAG, not an edit — there '
                                 'is no cut to go back to'
                                 % clip.display_label)
            clips = keep
            if not clips:
                self._set_status('Nothing to reconform.', _log.WARN)
                for note in notes:
                    _log.note('[SMTL] Reconform: %s' % note, _log.WARN)
                return
            for layer in self._layers:
                for tr in layer.transitions:
                    _importer.grant_handle(layer.clips, tr.at_frame,
                                           tr.before, tr.after, notes)

        if spec.search_in == _conform.ORIGINAL_PATH:
            seen = {}
            for clip in clips:
                if clip.src_path:
                    seen.setdefault(os.path.dirname(clip.src_path), None)
            if not seen:
                self._set_status(
                    'These clips state no file path — an edit list carries a '
                    'reel and nothing else.  Search a folder instead.',
                    _log.WARN)
                return
            pool = []
            for folder in seen:
                pool.extend(_conform.scan(folder, recurse=False))
        else:
            if not os.path.isdir(spec.root):
                self._set_status('No such folder: %s' % (spec.root or '—'),
                                 _log.WARN)
                return
            pool = _conform.scan(spec.root, recurse=spec.recurse)
        if not pool:
            self._set_status('Nothing to look at — no files found.', _log.WARN)
            return

        by_path = reads_in_script()

        groups = _conform.group_by_source(clips)
        trace  = []
        wanted = self._candidates_worth_probing(clips, pool, spec)
        if wanted:
            self._set_status('Reading %d file%s…'
                             % (len(wanted), '' if len(wanted) == 1 else 's'))
            QtWidgets.QApplication.processEvents()
            facts = probe_media({c.path: (c.first, c.last)
                                 for c in wanted}, trace=trace)
            for cand in wanted:
                got = facts.get(cand.path)
                if not got:
                    continue
                (cand.tc, cand.tc_frame, cand.rate, cand.width, cand.height,
                 cand.first, cand.last) = got

        trace = self._conform_header(clips, groups, pool, spec) + trace

        done = conflicts = missing = 0
        mismatched = []
        clashes = []
        with _undo_group('SMTL: %s' % label):
            for _key, group in groups.items():
                decision = _conform.match(group[0], pool, spec, trace=trace)
                if decision.state != _conform.MATCHED:
                    if decision.state == _conform.CONFLICT:
                        conflicts += len(group)
                        clashes.append((group, decision.candidates))
                        notes.append(
                            '%s: %d candidates — %s'
                            % (group[0].display_label, len(decision.candidates),
                               ', '.join(c.path for c in decision.candidates[:4])))
                    else:
                        missing += len(group)
                        for flag in decision.flags:
                            notes.append('%s: %s'
                                         % (group[0].display_label, flag))
                    continue
                was_rate = float(group[0].src_rate or 0.0)
                cand_rate = float(decision.candidate.rate or 0.0)
                bound = self._bind(group, decision, by_path, notes)
                if bound:
                    done    += len(bound)
                    missing += len(group) - len(bound)
                    for flag in decision.flags:
                        notes.append('%s: %s'
                                     % (group[0].display_label, flag))
                    if (was_rate and cand_rate
                            and abs(was_rate - cand_rate) > 1e-6):
                        mismatched.append((bound, decision.candidate,
                                           was_rate, cand_rate))
                else:
                    missing += len(group)
            if clashes:
                picked = self._ask_about_clashes(clashes, by_path, notes,
                                                 mismatched)
                done      += picked
                conflicts -= picked
            if mismatched:
                self._ask_about_rates(mismatched, notes)
            if done:
                self._recheck_missing_frames(set_modes=True)
                self._nothing_is_waiting()
                link_viewer_if_needed()
            if was_nodes:
                in_use = {c.node_name for lyr in self._layers
                          for c in lyr.clips}
                for gone in prune_unused(was_nodes, in_use):
                    notes.append('%s had nothing left on it and was removed'
                                 % gone)
            self._sync_viewer_group('SMTL: %s' % label)
            if done:
                tidy_sources({c.node_name for c in clips
                              if c.node_name and not c.is_placeholder})

        print('\n'.join(trace))
        for note in notes:
            _log.note('[SMTL] %s: %s' % (label, note), _log.WARN)
        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._refresh_offline_states()
        self._refresh_status()
        said = []
        if done:
            said.append('%d conformed' % done)
        if conflicts:
            said.append('%d skipped' % conflicts)
        if missing:
            said.append('%d not found' % missing)
        summary = ', '.join(said) + '.' if said else 'Nothing to do.'
        self._set_status(summary,
                         _log.WARN if (conflicts or missing) else None)
        if not done:
            summary = 'Nothing conformed.  ' + summary
        self._show_conform_report(label, summary)

    def _conform_header(self, clips, groups, pool, spec):
        """Return the trace header lines for a conform run."""
        out = ['[SMTL] Conform: %d clip%s, %d source%s, %d candidate%s'
               % (len(clips), '' if len(clips) == 1 else 's',
                  len(groups), '' if len(groups) == 1 else 's',
                  len(pool), '' if len(pool) == 1 else 's'),
               '  search in %s%s' % (spec.search_in,
                                     ' ' + spec.root if spec.root else ''),
               '  match on: %s%s' % (', '.join(
                   n for n, on in (('reel', spec.use_reel),
                                   ('name', spec.use_name),
                                   ('extension ' + (spec.ext or '—'),
                                    spec.use_ext and spec.ext)) if on)
                   or 'nothing',
                   '' if spec.case_sensitive else '  (case insensitive)'),

               '  first few candidates:']
        for cand in pool[:6]:
            out.append('    %s  %s' % (
                cand.path,
                '%d-%d' % (cand.first, cand.last)
                if cand.last > cand.first else 'single'))
        if len(pool) > 6:
            out.append('    … and %d more' % (len(pool) - 6))
        return out

    def _candidates_worth_probing(self, clips, pool, spec):
        """Return the unprobed candidates that pass the name filters."""
        want = []
        for cand in pool:
            if cand.tc:
                continue
            if spec.search_in == _conform.ORIGINAL_PATH:
                if any(cand.path.lower() == (c.src_path or '').lower()
                       for c in clips):
                    want.append(cand)
                continue
            if not spec.use_name:
                if spec.use_ext and spec.ext and cand.ext != spec.ext:
                    continue
                want.append(cand)
                continue
            if any(_conform._same_name(cand, c.src_name, spec) for c in clips):
                want.append(cand)
        return want

    def _ask_about_clashes(self, clashes, by_path, notes, mismatched):
        """Ask which candidate each clashing source uses; return clips bound."""
        rows = []
        for group, cands in clashes:
            labels = _conform.distinguishing([c.path for c in cands])
            rows.append((group[0].display_label, list(zip(labels, cands))))

        first_of = {}
        for group, cands in clashes:
            rate = float(group[0].src_rate or 0.0)
            want = int(group[0].orig_src_first)
            for cand in cands:
                at = _conform.place(cand, want, rate)
                first_of[id(cand)] = int(cand.first if at is None else at)

        def shot(cand):
            return thumbnail(cand.path, first_of.get(id(cand), cand.first))

        dlg = ConflictDialog(rows, parent=self, thumb=shot)
        dlg.show()
        QtWidgets.QApplication.processEvents()
        dlg.fill_thumbnails(QtWidgets.QApplication.processEvents)
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            notes.append('%d clash%s left unanswered — those clips are still '
                         'without media'
                         % (len(clashes), '' if len(clashes) == 1 else 'es'))
            return 0

        picked = 0
        for i, cand in dlg.choices().items():
            group = clashes[i][0]
            was_rate = float(group[0].src_rate or 0.0)
            asked = _conform.demand(group[0], cand)
            decision = _conform.Decision(_conform.MATCHED, candidate=cand,
                                         anchor=asked[0] if asked else None)
            bound = self._bind(group, decision, by_path, notes)
            if not bound:
                notes.append('%s: %s states no timecode, so there is '
                             'nothing to place the frames with — the clip '
                             'is still unmatched'
                             % (group[0].display_label, cand.path))
                continue
            picked += len(bound)
            notes.append('%s: you chose %s'
                         % (group[0].display_label, cand.path))
            cand_rate = float(cand.rate or 0.0)
            if was_rate and cand_rate and abs(was_rate - cand_rate) > 1e-6:
                mismatched.append((bound, cand, was_rate, cand_rate))
        return picked

    def _ask_about_rates(self, mismatched, notes):
        """Ask to retime or keep each source whose file rate differs from the edit."""
        answer = None
        for i, (group, cand, was_rate, cand_rate) in enumerate(mismatched):
            if answer is None:
                dlg = RateMismatchDialog(
                    os.path.basename(cand.path), cand_rate, was_rate,
                    parent=self, more=len(mismatched) - i - 1)
                retime = dlg.exec_() == QtWidgets.QDialog.Accepted
                if dlg.apply_to_all():
                    answer = retime
            else:
                retime = answer
            ratio = cand_rate / was_rate
            for clip in group:
                span = clip.last_frame - clip.first_frame + 1
                if retime:
                    clip.speed *= ratio
                    if clip.speed != 1.0 and not clip.retime_node:
                        clip.retime_node = RETIME_TIMEWARP
                else:
                    clip.src_last = clip.src_first + span - 1
            notes.append('%s is %g fps and the edit counted %g — %s'
                         % (os.path.basename(cand.path), cand_rate, was_rate,
                            'retimed' if retime else 'left as the list had it'))

    def _bind(self, clips, decision, reads_by_path, notes=None):
        """Bind clips to the decision's media on its numbering; return clips bound."""
        cand = decision.candidate
        bind, refused = [], []
        for clip in clips:
            state, gaps = _conform.held(clip, cand)
            (refused if state == _conform.NOWHERE
             else bind).append((clip, state, gaps))
        if notes is not None:
            for clip, _s, gaps in refused:
                absent = sum(int(hi) - int(lo) + 1 for lo, hi in gaps)
                notes.append('%s: none of the %d frame%s it needs %s in %s '
                             '— left unconformed'
                             % (clip.display_label, absent,
                                '' if absent == 1 else 's',
                                'is' if absent == 1 else 'are',
                                os.path.basename(cand.path)))
        clips = [c for c, _s, _g in bind]
        if not clips:
            return []
        if _conform.rebase(clips, decision) is None:
            return []
        name = reads_by_path.get(cand.path) or read_for_media(
            cand.path, int(cand.first), int(cand.last),
            label=clips[0].display_label)
        if not name:
            return []
        for c in clips:
            c.node_name = name
            if c.speed == 0:
                self._freeze_conformed(c)
        if notes is not None:
            for clip, state, gaps in bind:
                if state != _conform.PARTLY:
                    continue
                absent = sum(int(hi) - int(lo) + 1 for lo, hi in gaps)
                notes.append('%s: %d frame%s it needs %s not on disk (%s%s)'
                             % (clip.display_label, absent,
                                '' if absent == 1 else 's',
                                'is' if absent == 1 else 'are',
                                ', '.join('%d-%d' % (lo, hi)
                                          for lo, hi in gaps[:4]),
                                '' if len(gaps) <= 4 else ', …'))
        if _check_clip_offline_by_name(name):
            _log.note('[SMTL] Conform: %s is bound to %s, which is in error '
                      '— check its colourspace'
                      % (clips[0].display_label, name), _log.WARN)
        return clips

    def _freeze_conformed(self, clip):
        """Replace a zero-speed conformed clip's source with a FrameHold freeze."""
        node = make_freeze_node(clip.node_name, clip.src_first,
                                label=clip.label)
        if node is None:
            _log.note('[SMTL] Conform: could not freeze %s'
                      % clip.display_label, _log.WARN)
            return
        clip.node_name = node.name()
        clip.speed     = 1.0
        span = node_span_by_name(clip.node_name)
        if span is None:
            return
        _label, first, last, is_still = span
        clip.src_first = first
        clip.src_last, _len, clip.orig_src_first, clip.orig_src_last = \
            resolve_add_span(first, last, is_still,
                             duration=clip.last_frame - clip.first_frame + 1)


    def _on_refresh_clicked(self):
        """Re-read source extents, then re-check missing frames and offline."""
        self._src_tc_cache.clear()
        if not self._refresh_source_extents():
            return
        self._recheck_missing_frames(set_modes=True)
        self._refresh_offline_states()

    def _nothing_is_waiting(self):
        """Mark every clip's missing frames as loaded and clear arrivals."""
        for layer in self._layers:
            for clip in layer.clips:
                clip.was_missing = clip.missing
                clip.arrived = ()

    def _recheck_missing_frames(self, set_modes=False):
        """Update each clip's missing frames and optionally Read on_error modes."""
        by_name = {}
        for layer in self._layers:
            for clip in layer.clips:
                if clip.node_name:
                    by_name.setdefault(clip.node_name, []).append(clip)
        paths = {name: path for path, name in reads_in_script().items()}
        changed, short, reloaded = [], 0, 0
        watch = {}
        for name, clips in by_name.items():
            path = paths.get(name, '')
            runs = _conform.runs_of(path)
            gained = False
            for clip in clips:
                was = clip.missing
                clip.missing = () if runs is None else _conform.gaps_in(
                    runs, int(clip.src_first), int(clip.src_last))
                clip.arrived = tuple(
                    run for lo, hi in clip.was_missing
                    for run in _conform.gaps_in(clip.missing, lo, hi))
                if clip.missing:
                    short += 1
                if clip.arrived:
                    gained = True
                if clip.missing != was:
                    changed.append(clip.display_label)
            if (set_modes and runs is not None and len(runs) > 1
                    and set_read_error_mode(name, True)):
                _log.note('[SMTL] %s: has frames missing — serving %s'
                          % (name, _READ_ERROR_MODE))
            if set_modes and gained and reload_read(name):
                reloaded += 1
                for clip in clips:
                    clip.was_missing = clip.missing
                    clip.arrived = ()
            if runs is not None and any(c.missing or c.arrived
                                        for c in clips):
                watch.setdefault(os.path.dirname(path), None)
        self._watched = {folder: self._watched.get(folder)
                         for folder in watch}
        if reloaded:
            _log.note('[SMTL] %d source(s) had gained frames — reloaded'
                      % reloaded)
        if changed:
            self._timeline.update()
            _log.note('[SMTL] %d clip(s) short of frames: %s'
                      % (short, ', '.join(sorted(set(changed))[:6]))
                      if short else
                      '[SMTL] every clip has all its frames again')
        return short

    def _check_sources_changed(self, announce=True):
        """Flag clips whose source range differs from the cut and report it."""
        ranges = node_ranges({c.node_name for lyr in self._layers
                              for c in lyr.clips})
        before = [c.stale for lyr in self._layers for c in lyr.clips]
        changed = []
        for layer in self._layers:
            for clip in layer.clips:
                clip.stale = False
                got = ranges.get(clip.node_name)
                if got is None:
                    continue
                first, last, is_still = got
                if is_still:
                    continue
                if (first, last) != (clip.orig_src_first, clip.orig_src_last):
                    clip.stale = True
                    changed.append(clip.display_label)

        self._sources_stale = bool(changed)
        self._refresh_source_button()
        if before != [c.stale for lyr in self._layers for c in lyr.clips]:
            self._timeline.update()

        now = frozenset(changed)
        if announce and now and now != getattr(self, '_stale_said', frozenset()):
            names = ', '.join(sorted(now)[:4])
            more  = '' if len(now) <= 4 else ', …'
            self._set_status(
                f'{len(changed)} clip(s) have changed since this was cut '
                f'({names}{more}) — Refresh to update.', _log.WARN)
        self._stale_said = now

    def _refresh_source_button(self):
        """Style the Refresh button amber while sources are stale."""
        if getattr(self, '_btn_offline_check', None) is None:
            return
        variant = ('attention' if getattr(self, '_sources_stale', False)
                   else 'default')
        if variant == getattr(self, '_source_btn_variant', None):
            return
        self._source_btn_variant = variant
        set_button_style(self._btn_offline_check,
                         _theme.push_button_style(variant))

    def _refresh_source_extents(self):
        """Re-read each clip's source range from its node; False if cancelled."""
        targets = self._timeline.selection()

        if not targets:
            box = QtWidgets.QMessageBox(self)
            box.setWindowTitle('SMTL')
            box.setText('All clips will be updated — are you sure?')
            named = sum(1 for lyr in self._layers for c in lyr.clips
                        if c.user_label)
            if named:
                box.setInformativeText(
                    f'{named} clip(s) you have renamed will go back to the '
                    f'name their node gives them.  Colours are kept.')
            box.setStandardButtons(QtWidgets.QMessageBox.Yes
                                   | QtWidgets.QMessageBox.Cancel)
            box.setDefaultButton(QtWidgets.QMessageBox.Cancel)
            if box.exec_() != QtWidgets.QMessageBox.Yes:
                self._set_status('Refresh: cancelled.')
                return False
            targets = [c for lyr in self._layers for c in lyr.clips]

        longer = shorter = moved = renamed = unnamed = 0
        beyond = []
        for clip in targets:
            span = node_span_by_name(clip.node_name)
            if span is None:
                continue
            label, first, last, is_still = span
            if is_still:
                continue
            if label != clip.label:
                clip.label = label
                renamed += 1
            if clip.user_label:
                clip.user_label = ''
                unnamed += 1
            if (first, last) == (clip.orig_src_first, clip.orig_src_last):
                continue

            was = clip.orig_src_last - clip.orig_src_first + 1
            now = last - first + 1
            clip.orig_src_first, clip.orig_src_last = first, last
            if now > was:
                longer += 1
            elif now < was:
                shorter += 1
            else:
                moved += 1
            if clip.src_last > last or clip.src_first < first:
                beyond.append(clip.display_label)

        self._check_sources_changed(announce=False)

        if not (longer or shorter or moved or renamed or unnamed):
            self._set_status('Refresh: every source still as it was.')
            return True

        self._sync_viewer_group('SMTL: Refresh sources')
        self._refresh_status()

        said = []
        if longer:
            said.append(f'{longer} longer')
        if shorter:
            said.append(f'{shorter} shorter')
        if moved:
            said.append(f'{moved} renumbered')
        if renamed:
            said.append(f'{renamed} renamed')
        if unnamed:
            said.append(f'{unnamed} back to their node name')
        msg = 'Refresh: ' + ', '.join(said) + '.'
        if beyond:
            msg += ('  Now past its media: ' + ', '.join(sorted(set(beyond)))
                    + '.')
        self._set_status(msg)
        return True

    def _refresh_offline_states(self, _path=None):
        """Re-check every clip's offline status and rebuild if any changed."""
        unique_names = {clip.node_name
                        for layer in self._layers
                        for clip in layer.clips}
        read_offline = {name: _check_clip_offline_by_name(name)
                        for name in unique_names}
        changed = False
        for layer in self._layers:
            for clip in layer.clips:
                was        = clip.offline
                clip.offline = read_offline.get(clip.node_name, False)
                if clip.offline != was:
                    changed = True
        if changed:
            self._sync_viewer_group()
        self._timeline._freeze_nodes = freeze_nodes_now(self._layers)
        self._timeline.update()


    def _update_fs_watcher(self):
        """Sync the QFileSystemWatcher's directory list to the current clip set."""
        if self._fs_watcher is None:
            return
        try:
            existing = (self._fs_watcher.directories()
                        + self._fs_watcher.files())
            if existing:
                self._fs_watcher.removePaths(existing)
            dirs = set()
            unwatched = []
            for layer in self._layers:
                for clip in layer.clips:
                    try:
                        import nuke
                        node = nuke.toNode(clip.node_name)
                        if node:
                            raw = node['file'].value()
                            if raw:
                                d = os.path.dirname(raw)
                                if d and os.path.isdir(d):
                                    dirs.add(d)
                    except Exception as e:
                        unwatched.append(f'{clip.node_name} ({e})')
            if unwatched:
                _log.note('offline checking will not cover %d source(s): %s'
                          % (len(unwatched), ', '.join(unwatched[:5])
                             + (' ...' if len(unwatched) > 5 else '')),
                          _log.WARN)
            if dirs:
                self._fs_watcher.addPaths(list(dirs))
        except Exception as e:
            print(f'[SMTL] fs_watcher update error: {e}')


    def _ensure_viewer(self):
        """Wire the active viewer to SMTL_Group, then rebuild."""
        msg = _connect_viewer_to_group()
        self._set_status(msg)
        self._sync_viewer_group()

    def _reset_timeline(self):
        """Clear all clips and layers and delete SMTL nodes from the DAG."""
        reply = QtWidgets.QMessageBox.question(
            self,
            'Reset Timeline',
            'Clear all clips and layers and delete SMTL_Group from the DAG?\n\n'
            'This cannot be undone.',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.Cancel,
            QtWidgets.QMessageBox.Cancel,
        )
        if reply != QtWidgets.QMessageBox.Yes:
            return

        _delete_smtl_nodes()

        self._layers         = starting_tracks()
        self._active_idx     = 0
        self._add_idx        = 0
        self._sel_clip       = None

        self._timeline.set_timeline_start(None)
        self._timeline._cursor_frame = self._timeline._tl_start
        self._timeline._mark_in      = None
        self._timeline._mark_out     = None
        self._timeline._ghost_in     = None
        self._timeline._ghost_out    = None
        self._src_tc_cache.clear()
        self._import_options = None
        self._import_offset  = 0
        self._timeline.set_layers(self._layers, 0, add_idx=0)
        self._had_clips = False
        self._update_fs_watcher()

        self._refresh_removal_buttons()
        self._on_start_auto()
        self._refresh_merge_bar()
        self._refresh_status()
        self._set_status('Timeline reset.', _log.WARN)

    def _apply_saved(self, saved):
        """Put a saved timeline on the panel — opening, Rebuild and undo."""
        (layers, active_idx, add_idx, cursor_frame, timeline_start,
         timeline_end, mark_in, mark_out, dissolve,
         ghost_in, ghost_out) = saved
        self._load_dissolve_prefs(dissolve)
        self._layers     = layers
        self._active_idx = active_idx
        self._add_idx    = add_idx
        tl = self._timeline
        tl._mark_in,  tl._mark_out  = mark_in,  mark_out
        tl._ghost_in, tl._ghost_out = ghost_in, ghost_out
        if cursor_frame is not None:
            tl._cursor_frame = cursor_frame
        if timeline_start is not None:
            tl._tl_start = tl._origin_frame = timeline_start
        if timeline_end is not None:
            tl._tl_end = timeline_end

    def _reload_from_node(self):
        """Restore timeline state from SMTL_Group's smtl_state knob and rebuild."""
        self._src_tc_cache.clear()
        self._sel_clip = None
        self._timeline._sel_clip = None
        self._timeline._selected_clips = set()
        saved = _load_timeline_from_node()
        if saved is not None:
            self._apply_saved(saved)
            self._sync_spins()
            self._set_status('Timeline restored from saved state.')
        else:
            self._set_status('No saved state found in SMTL_Group.', _log.WARN)

        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_viewer_group()
        self._refresh_merge_bar()
        self._refresh_status()
        self._check_sources_changed()

    def _apply_undo_state(self, action='Undo'):
        """Sync the Qt model from smtl_state after an undo, redo or reload."""
        saved = _load_timeline_from_node()
        if saved is None:
            self._set_status(f'{action}: no state to restore.', _log.WARN)
            return
        self._state_seen = read_state_blob()
        self._apply_saved(saved)
        self._sel_clip = None
        self._timeline._sel_clip = None
        self._timeline._selected_clips = set()
        self._refresh_removal_buttons()
        self._timeline.set_layers(self._layers, self._active_idx,
                                  add_idx=self._add_idx)
        self._sync_spins()
        self._refresh_merge_bar()
        self._rekey_from_model()
        self._check_sources_changed()
        self._update_clip_frame_spin()
        self._update_fs_watcher()
        self._refresh_status()

    def _rekey_from_model(self):
        """Write the merge gates and retime curves again from the model."""
        pairs = [(layer, clip) for layer in self._layers for clip in layer.clips]
        if not pairs:
            return
        try:
            _update_merge_settings(pairs)
            _update_retime(pairs)
        except Exception as e:
            _log.note(f'Could not re-key after a state change: {e}', _log.WARN)


    def _sync_spins(self):
        """Push the timeline bounds and cursor frame into their spinboxes."""
        self._spin_start.blockSignals(True)
        self._spin_end.blockSignals(True)
        self._spin_cursor.blockSignals(True)
        self._spin_start.setValue(self._timeline._tl_start)
        self._spin_end.setValue(self._timeline._tl_end)
        self._spin_cursor.setValue(self._timeline._cursor_frame)
        self._spin_start.blockSignals(False)
        self._spin_end.blockSignals(False)
        self._spin_cursor.blockSignals(False)

    def _sync_mark_spins(self):
        """Show the marks in their fields, greying a ghosted or unset one."""
        if getattr(self, '_spin_mark_in', None) is None:
            return
        tl = self._timeline
        for spin, mark, ghost, fallback in (
            (self._spin_mark_in,  tl._mark_in,  tl._ghost_in,  tl._tl_start),
            (self._spin_mark_out, tl._mark_out, tl._ghost_out, tl._tl_end),
        ):
            live = mark is not None
            value = mark if live else (ghost if ghost is not None else fallback)
            spin.blockSignals(True)
            spin.setValue(int(value))
            spin.blockSignals(False)
            spin.setEnabled(live)

    def _sync_view_spins(self):
        """Push the visible frame range into the viewport spinboxes."""
        tl       = self._timeline
        canvas_w = max(1, tl.width() - _LABEL_W)
        vis_first = tl._x_to_frame(_LABEL_W)
        vis_last  = tl._x_to_frame(_LABEL_W + canvas_w)
        self._spin_view_start.blockSignals(True)
        self._spin_view_end.blockSignals(True)
        self._spin_view_start.setValue(vis_first)
        self._spin_view_end.setValue(vis_last)
        self._spin_view_start.blockSignals(False)
        self._spin_view_end.blockSignals(False)

    def _on_spin_start_edited(self):
        val = self._spin_start.value()
        self._timeline._tl_start     = val
        self._timeline._origin_frame = val
        self._timeline._scroll_x     = 0
        try:
            import nuke
            nuke.root()['first_frame'].setValue(val)
        except Exception as e:
            _log.note(f'timeline start: root first_frame not set to {val}: {e}',
                      _log.WARN)
        self._timeline.tl_bounds_changed.emit()
        self._timeline.update()

    def _on_spin_end_edited(self):
        val = self._spin_end.value()
        self._timeline._tl_end = val
        try:
            import nuke
            nuke.root()['last_frame'].setValue(val)
        except Exception as e:
            _log.note(f'timeline end: root last_frame not set to {val}: {e}',
                      _log.WARN)
        self._timeline.tl_bounds_changed.emit()
        self._timeline.update()

    def _on_spin_view_start_edited(self):
        """Pan the viewport so the typed frame is at the left edge."""
        tl  = self._timeline
        val = self._spin_view_start.value()
        tl._scroll_x = int((val - tl._origin_frame) * tl.zoom)
        tl.viewport_changed.emit()
        tl.update()

    def _on_spin_view_end_edited(self):
        """Zoom the viewport so the typed frame is at the right edge."""
        tl        = self._timeline
        val       = self._spin_view_end.value()
        vis_first = tl._x_to_frame(_LABEL_W)
        span      = max(1, val - vis_first)
        canvas_w  = max(1, tl.width() - _LABEL_W)
        tl.zoom      = canvas_w / float(span)
        tl._scroll_x = int((vis_first - tl._origin_frame) * tl.zoom)
        tl._update_size()
        tl.viewport_changed.emit()
        tl.update()

    def _on_tl_bounds_changed(self):
        """Sync the spinboxes and save state after the timeline bounds change."""
        self._sync_spins()
        self._save_state()

    def _on_start_auto(self):
        """Reset both timeline bounds to the Nuke root first/last frame."""
        rf = _root_first_frame()
        rl = _root_last_frame()
        self._timeline._tl_start     = rf
        self._timeline._tl_end       = rl
        self._timeline._origin_frame = rf
        self._sync_spins()
        self._timeline._scroll_x = 0
        self._timeline.update()
        self._save_state()


    def _refresh_status(self, cursor_only=False):
        self._sync_mark_spins()
        if not self._layers:
            self._lbl_status.setText('No layers.')
            return
        cursor    = self._timeline._cursor_frame
        add_layer = self._layers[self._add_idx]
        act_layer = self._layers[self._active_idx]
        parts = [f'↦ {cursor}',
                 f'● {add_layer.name}',
                 f'● {act_layer.name}']
        if self._add_idx == self._active_idx:
            parts = [f'↦ {cursor}', f'Track: {add_layer.name}']
        if self._sel_clip:
            c          = self._sel_clip
            offline_tag = '  ⚠ offline' if c.offline else ''
            parts.append(f'{c.display_label}  tl {c.first_frame}–{c.last_frame}{offline_tag}')
        mi, mo = self._timeline._mark_in, self._timeline._mark_out
        if mi is not None or mo is not None:
            i_str = str(mi) if mi is not None else '–'
            o_str = str(mo) if mo is not None else '–'
            parts.append(f'I:{i_str}  O:{o_str}')
        self._lbl_status.setText('  •  '.join(parts))
        if cursor_only:
            self._refresh_freeze_button()
            return
        self._refresh_removal_buttons()
        self._refresh_lock_state()


    _LOCK_GREYS = (
        '_btn_clip_overwrite', '_btn_clip_splice', '_btn_clip_replace',
        '_btn_clip_lift', '_btn_clip_extract',
        '_btn_clip_dissolve', '_btn_clip_freeze', '_btn_clip_retime',
        '_btn_tool_edit', '_btn_tool_trim', '_btn_tool_slide',
        '_btn_tool_splice', '_btn_tool_sel_left', '_btn_tool_sel_right',
    )

    def _locked_now(self):
        """Return True when the add-target layer is locked or muted."""
        idx = self._add_idx
        return (0 <= idx < len(self._layers)
                and layer_blocked(self._layers[idx]))

    def _refresh_lock_state(self):
        """Grey every editing tool while the target layer is blocked."""
        locked = self._locked_now()
        for name in self._LOCK_GREYS:
            btn = getattr(self, name, None)
            if btn is not None and locked:
                btn.setEnabled(False)
            elif btn is not None and name.startswith('_btn_tool_'):
                btn.setEnabled(True)


    def _on_play_pressed(self, direction):
        """Toggle or reverse playback from a transport button."""
        self._set_playing(0 if self._playing == direction else direction)

    def _set_playing(self, direction):
        """Start, stop or reverse playback and update the transport buttons."""
        if direction == self._playing:
            self._refresh_play_buttons()
            return
        if self._playing:
            _do_stop()
        self._playing = direction
        if direction:
            self._play(direction)
        else:
            self._catch_up_to_viewer()
        self._poll_idle_ticks = 0
        self._refresh_play_buttons()

    def _catch_up_to_viewer(self):
        """Move the panel cursor to the frame the viewer is showing."""
        if not _nuke_ok():
            return
        try:
            import nuke
            frame = int(nuke.frame())
        except Exception:
            return
        self._last_seen_frame = frame
        tl = self._timeline
        tl._cursor_frame = frame
        tl.update()
        self._on_cursor_spin_update(frame)
        self._refresh_status()

    def _forget_playing(self):
        """Mark playback as stopped without stopping the viewer."""
        if not self._playing:
            return
        self._playing = 0
        self._catch_up_to_viewer()
        self._refresh_play_buttons()

    def _refresh_play_buttons(self):
        """Check the transport button matching the current playback direction."""
        for btn, d in ((self._btn_play_rev, -1), (self._btn_play_fwd, 1)):
            btn.blockSignals(True)
            btn.setChecked(self._playing == d)
            btn.blockSignals(False)

    def _play(self, direction):
        """Play forward or reverse, restricted to the mark range when both are set."""
        mi = self._timeline._mark_in
        mo = self._timeline._mark_out
        if mi is not None and mo is not None:
            first = min(mi, mo)
            last  = max(mi, mo)
            _do_play(direction, first_frame=first, last_frame=last)
        else:
            _do_play(direction)


    def showEvent(self, event):
        """Start the polls and lock button widths when the panel is shown."""
        super().showEvent(event)
        if not getattr(self, '_widths_locked', False) and getattr(self, '_shift_names', None):
            self._widths_locked = True
            self._lock_shift_widths()
        if getattr(self, '_shift_poll', None) is not None:
            self._shift_poll.start()
        if getattr(self, '_frame_poll', None) is None:
            return
        self._poll_idle_ticks = 0
        self._frame_poll.setInterval(_POLL_FAST_MS)
        self._frame_poll.start()

    def hideEvent(self, event):
        """Stop polling while the panel is hidden."""
        super().hideEvent(event)
        if getattr(self, '_frame_poll', None) is not None:
            self._frame_poll.stop()
        if getattr(self, '_shift_poll', None) is not None:
            self._shift_poll.stop()

    def _replace_selection(self, names=None):
        """Return (clip, node_name) for Replace, or (None, reason)."""
        if names is None:
            names = selected_source_names()
        if not names:
            return None, 'Select a source in the graph to replace with.'
        if len(names) > 1:
            return None, f'Select one source, not {len(names)}.'
        node_name = list(names)[0]

        sel = self._timeline.selection()
        if not sel:
            return None, 'Select the clip to replace.'
        if len(sel) > 1:
            return None, f'Select one clip, not {len(sel)}.'
        clip = sel[0]


        layer = next((l for l in self._layers if clip in l.clips), None)
        if layer is not None and self._timeline._layer_blocked(layer):
            reason = 'muted' if getattr(layer, 'hidden', False) else 'locked'
            return None, f'Track "{layer.name}" is {reason}.'
        return (clip, node_name), None

    def _replace_clip(self):
        """Swap a clip's source, keeping its timeline position and length."""
        found, why = self._replace_selection()
        if found is None:
            self._set_status(why, _log.WARN)
            return
        clip, node_name = found

        span = node_span_by_name(node_name)
        if span is None:
            self._set_status(f'{node_name} is no longer in the graph.', _log.ERROR)
            return
        label, src_first, src_last, is_still = span

        plan = resolve_replace(clip, src_first, src_last, is_still)
        if plan is None:
            have = src_last - src_first + 1
            over = (max(0, clip.orig_src_first - clip.src_first)
                    + max(0, clip.src_last - clip.orig_src_last))
            need = clip.duration - over
            msg = (f'{label} has {have} frames ({src_first}\u2013{src_last}).\n'
                   f'{clip.display_label} needs {need}.\n'
                   f'{need - have} short.')
            if over:
                msg += (f'\n\n(It is {clip.duration} frames long, {over} of them '
                        f'already past its media \u2014 those are allowed to stay '
                        f'past it.)')
            self._set_status(msg.replace('\n', '  '), _log.ERROR)
            QtWidgets.QMessageBox.warning(self, 'Cannot replace', msg)
            return

        new_first, new_last, how = plan
        clip.node_name = node_name
        clip.label     = label
        clip.user_label = ''
        clip.src_first, clip.src_last = new_first, new_last
        if is_still:
            clip.orig_src_first = new_first - _STILL_HANDLE
            clip.orig_src_last  = new_last  + _STILL_HANDLE
        else:
            clip.orig_src_first = src_first
            clip.orig_src_last  = src_last
        clip.offline = _check_clip_offline(clip)
        clip.stale   = False

        touching = [tr for tr in self._layers[self._add_idx].transitions
                    if tr.at_frame in (clip.first_frame, clip.last_frame + 1)]
        was = [(tr, tr.length) for tr in touching]

        self._sync_viewer_group('SMTL: Replace clip')
        self._refresh_status()

        lost = sum(old_len - tr.length for tr, old_len in was
                   if tr.length < old_len)
        said = {'frames': 'matching the frame numbers',
                'head':   'from the head \u2014 the numbering did not match',
                'still':  'held, as a still'}[how]
        msg = f'Replaced with {label}, {said}.  {new_first}\u2013{new_last}.'
        if lost:
            msg += f'  Dissolves shortened by {lost} frame(s) \u2014 less handle.'
        self._set_status(msg)

    def _refresh_replace_button(self):
        """Enable Replace when one source and one clip are selected."""
        found, _why = self._replace_selection(names=self._dag_sel_names)
        self._btn_clip_replace.setEnabled(found is not None
                                          and not self._locked_now())

    def _poll_read_selection(self):
        """Poll the graph selection and enable Overwrite, Splice In and Replace."""
        self._sel_poll_tick += 1
        if self._sel_poll_tick % 5:
            return
        names = selected_source_names()
        self._dag_sel_names = names
        has = bool(names)
        self._refresh_replace_button()
        locked = self._locked_now()
        if (has, locked) == self._has_reads:
            return
        self._has_reads = (has, locked)
        self._btn_clip_overwrite.setEnabled(has and not locked)
        self._btn_clip_splice.setEnabled(has and not locked)

    def _install_shortcuts(self):
        """Bind every editorial key as a QShortcut on the timeline widget."""
        self._shortcuts = []
        binds = (
            ('Z',              lambda: self._shortcut_remove(False)),
            ('X',              lambda: self._shortcut_remove(True)),
            ('Del',            lambda: self._shortcut_delete(False)),
            ('Backspace',      lambda: self._shortcut_delete(False)),
            ('Shift+Del',      lambda: self._shortcut_delete(True)),
            ('Shift+Backspace', lambda: self._shortcut_delete(True)),
            ('Y',              lambda: self._btn_tool_edit.click()),
            ('U',              lambda: self._btn_tool_trim.click()),
            ('T',              lambda: self._mark_clip()),
            ('Shift+T',        lambda: self._clear_marks()),
            ('I',              lambda: self._set_mark_in(self._timeline._cursor_frame)),
            ('Shift+I',        lambda: self._set_mark_in(None)),
            ('O',              lambda: self._set_mark_out(self._timeline._cursor_frame)),
            ('Shift+O',        lambda: self._set_mark_out(None)),
            ('Alt+T',          lambda: self._toggle_ghost('both')),
            ('Alt+I',          lambda: self._toggle_ghost('in')),
            ('Alt+O',          lambda: self._toggle_ghost('out')),
            ('D',              lambda: self._toggle_clip_disabled()),
            ('C',              lambda: self._copy_clip()),
            ('V',              lambda: self._paste_clip()),
            ('J',              lambda: self._set_playing(-1)),
            ('K',              lambda: self._set_playing(0)),
            ('L',              lambda: self._set_playing(1)),
            ('Left',           lambda: self._timeline._step_frame(-1)),
            ('Right',          lambda: self._timeline._step_frame(1)),
            ('Ctrl+Z',         lambda: self._shortcut_undo(False)),
            ('Ctrl+Shift+Z',   lambda: self._shortcut_undo(True)),
            ('Ctrl+Y',         lambda: self._shortcut_undo(True)),
        )
        _QShortcut = getattr(QtWidgets, 'QShortcut', None) or QtGui.QShortcut
        for seq, fn in binds:
            sc = _QShortcut(QtGui.QKeySequence(seq), self._timeline)
            sc.setContext(Qt.WidgetWithChildrenShortcut)
            sc.activated.connect(fn)
            self._shortcuts.append(sc)

    def _shortcut_remove(self, extract):
        """Lift (Z) or extract (X) the selected clips."""
        if extract:
            if (self._can_remove()
                    and len(self._timeline.removal_layers()) <= 1):
                self._remove_clip(True)
        elif self._can_remove():
            self._remove_clip(False)

    def _shortcut_delete(self, extract=False):
        """Delete the selected dissolve, or else lift or extract the clips."""
        if self._remove_dissolve():
            return
        if self._can_remove():
            self._remove_clip(extract)

    def _shortcut_undo(self, redo):
        """Run Nuke undo or redo, then reload the panel state."""
        if not _nuke_ok():
            return
        import nuke as _nuke
        if redo:
            _nuke.redo()
            self._apply_undo_state('Redo')
        else:
            _nuke.undo()
            self._apply_undo_state('Undo')

    def _clear_marks(self):
        """Clear both marks and their ghosts."""
        self._set_marks(None, None)
        self._timeline._ghost_in = self._timeline._ghost_out = None
        self._timeline.update()
        self._save_state()
        self._set_status('Marks cleared.')

    def _toggle_ghost(self, which='both'):
        """Ghost the live marks, or restore ghosted ones."""
        tl = self._timeline
        ends = ('in', 'out') if which == 'both' else (which,)

        if which == 'both':
            turning_off = tl._mark_in is not None or tl._mark_out is not None
        else:
            turning_off = getattr(tl, '_mark_' + which) is not None

        touched = False
        for end in ends:
            live  = getattr(tl, '_mark_' + end)
            ghost = getattr(tl, '_ghost_' + end)
            setter = self._set_mark_in if end == 'in' else self._set_mark_out
            if turning_off:
                if live is None:
                    continue
                setattr(tl, '_ghost_' + end, live)
                setter(None)
                touched = True
            else:
                if ghost is None:
                    continue
                setter(ghost, restoring=True)
                touched = True

        if not touched:
            self._set_status('Nothing to switch %s.'
                             % ('off' if turning_off else 'back on'), _log.WARN)
            return

        tl.update()
        self._save_state()
        what = {'both': 'Marks', 'in': 'Mark in', 'out': 'Mark out'}[which]
        self._set_status('%s %s.' % (what, 'ghosted' if turning_off else 'restored'))

    def _poll_missing_nodes(self):
        """Rebind or mark offline clips whose node has gone from the graph."""
        self._gone_poll_tick += 1
        if self._gone_poll_tick % 12:
            return
        names = {clip.node_name
                 for layer in self._layers
                 for clip in layer.clips}
        if not names:
            return
        self._check_sources_changed()
        missing = _missing_node_names(names)
        rebound = {}
        for name in missing:
            now = feeding_now(name)
            if now:
                rebound[name] = now
        if rebound:
            for layer in self._layers:
                for clip in layer.clips:
                    if clip.node_name in rebound:
                        clip.node_name = rebound[clip.node_name]
            missing = {n for n in missing if n not in rebound}
            for was, now in sorted(rebound.items()):
                _log.note('[SMTL] %s is now %s — the clip followed the wire'
                          % (was, now))
            self._save_state()
            self._timeline.update()
        changed = False
        for layer in self._layers:
            for clip in layer.clips:
                gone = clip.node_name in missing
                if gone and not clip.offline:
                    clip.offline = True
                    changed = True
        if changed:
            self._sync_viewer_group()
            self._timeline.update()
            self._set_status('A clip\'s node has gone from the graph.', _log.ERROR)

    def _poll_for_frames(self):
        """Recheck missing frames when a watched folder's mtime changes."""
        self._watch_tick += 1
        if self._watch_tick % 125:
            return
        if not self._watched:
            return
        touched = False
        for folder, seen in list(self._watched.items()):
            try:
                now = os.stat(folder).st_mtime
            except OSError:
                continue
            if seen is None:
                self._watched[folder] = now
                continue
            if now != seen:
                self._watched[folder] = now
                touched = True
        if touched:
            self._recheck_missing_frames()

    def _poll_state_knob(self):
        """Reload the panel when the smtl_state knob changes externally."""
        self._state_poll_tick += 1
        if self._state_poll_tick % 6:
            return
        blob = read_state_blob()
        if blob is None or blob == self._state_seen:
            return
        self._state_seen = blob
        self._apply_undo_state('Reload')

    def _refresh_mode_labels(self):
        """Update mode labels for Shift and enable Dissolve and Conform."""
        if not getattr(self, '_shift_names', None):
            return
        shift  = is_shift(held())
        mode   = self._timeline._tool_mode
        locked = self._locked_now()
        has_clips = any(getattr(l, 'clips', None)
                        for l in (getattr(self, '_layers', None) or []))
        waiting = any(c.is_placeholder
                      for l in (getattr(self, '_layers', None) or [])
                      if not l.locked
                      for c in getattr(l, 'clips', None) or [])
        state  = (shift, mode, locked, has_clips, waiting)
        if state == getattr(self, '_shift_state', None):
            return
        self._shift_state = state
        for key, (btn, plain, shifted) in self._shift_names.items():
            label, tip = shifted if (shift and mode == key) else plain
            apply_button_face(btn, label, self._icons_dir, tip)
        self._refresh_dissolve_tip(shift)
        self._btn_clip_dissolve.setEnabled(mode != 'slide'
                                           and not locked
                                           and has_clips)
        self._btn_conform.setEnabled(waiting)

    def _poll_viewer_frame(self):
        """Follow the Nuke playhead with the timeline cursor."""
        if self._pushing_frame or not _nuke_ok():
            return

        try:
            import nuke
            frame = int(nuke.frame())
        except Exception:
            return

        if frame == self._last_seen_frame:
            self._poll_viewer_marks()
            self._poll_idle_ticks += 1
            if self._playing and self._poll_idle_ticks >= _PLAY_STILL_TICKS:
                self._forget_playing()
            if (self._poll_idle_ticks == _POLL_IDLE_AFTER
                    and self._frame_poll.interval() != _POLL_IDLE_MS):
                self._frame_poll.setInterval(_POLL_IDLE_MS)
            return

        self._poll_idle_ticks = 0
        if self._frame_poll.interval() != _POLL_FAST_MS:
            self._frame_poll.setInterval(_POLL_FAST_MS)
        self._last_seen_frame = frame

        if self._ui_freeze and self._playing:
            return

        tl = self._timeline
        if frame == tl._cursor_frame:
            return
        tl._cursor_frame = frame
        tl.update()
        self._on_cursor_spin_update(frame)
        self._refresh_status(cursor_only=True)

    def _poll_viewer_marks(self):
        """Mirror the viewer's restricted frame range into the timeline marks."""
        rng = _read_viewer_range()
        if rng is None or rng == self._pushed_range:
            return
        self._pushed_range = rng

        first, last, locked = rng
        new_in, new_out = (first, last) if locked else (None, None)
        tl = self._timeline
        if (new_in, new_out) == (tl._mark_in, tl._mark_out):
            return
        if new_in is not None or new_out is not None:
            tl._ghost_in = tl._ghost_out = None
        tl._mark_in, tl._mark_out = new_in, new_out
        tl.update()
        self._save_state()
        self._refresh_status()

        self._poll_idle_ticks = 0
        if self._frame_poll.interval() != _POLL_FAST_MS:
            self._frame_poll.setInterval(_POLL_FAST_MS)

    def _sync_viewer_range(self):
        """Push the timeline's marks onto the active viewer's frame range."""
        if not _nuke_ok():
            return
        try:
            import nuke
            av = nuke.activeViewer()
            if av is None:
                return
            vn = av.node()

            mi = self._timeline._mark_in
            mo = self._timeline._mark_out
            rf = int(nuke.root()['first_frame'].value())
            rl = int(nuke.root()['last_frame'].value())

            if mi is None and mo is None:
                vn['frame_range'].setValue(f'{rf}-{rl}')
                vn['frame_range_lock'].setValue(False)
                self._pushed_range = (rf, rl, False)
                return

            start = mi if mi is not None else getattr(self._timeline, '_tl_start', rf)
            end   = mo if mo is not None else getattr(self._timeline, '_tl_end',   rl)
            first, last = min(start, end), max(start, end)
            vn['frame_range'].setValue(f'{first}-{last}')
            vn['frame_range_lock'].setValue(True)
            self._pushed_range = (first, last, True)
        except Exception as e:
            print(f'[SMTL] _sync_viewer_range: {e}')

    def _set_marks(self, mark_in, mark_out):
        """Set both marks together, swapping them if reversed."""
        tl = self._timeline
        if mark_in is not None and mark_out is not None and mark_in > mark_out:
            mark_in, mark_out = mark_out, mark_in
        if mark_in is not None or mark_out is not None:
            tl._ghost_in = tl._ghost_out = None
        tl._mark_in, tl._mark_out = mark_in, mark_out
        tl.update()
        with _undo_group('SMTL: Marks'):
            self._sync_viewer_range()
            self._save_state()
        self._refresh_status()

    def _set_mark_in(self, frame, restoring=False):
        """Set or clear the mark-in point."""
        tl = self._timeline
        dropped = (frame is not None and tl._mark_out is not None
                   and frame > tl._mark_out)
        if dropped:
            tl._mark_out = tl._ghost_out = None
        if frame is not None:
            tl._ghost_in = None
            if not restoring:
                tl._ghost_out = None
        tl._mark_in = frame
        tl.update()
        with _undo_group('SMTL: Mark in'):
            self._sync_viewer_range()
            self._save_state()
        self._refresh_status()
        if dropped:
            self._set_status(f'In at {frame} — Out dropped, it was behind it.',
                             _log.WARN)

    def _set_mark_out(self, frame, restoring=False):
        """Set or clear the mark-out point."""
        tl = self._timeline
        dropped = (frame is not None and tl._mark_in is not None
                   and frame < tl._mark_in)
        if dropped:
            tl._mark_in = tl._ghost_in = None
        if frame is not None:
            tl._ghost_out = None
            if not restoring:
                tl._ghost_in = None
        tl._mark_out = frame
        tl.update()
        with _undo_group('SMTL: Mark out'):
            self._sync_viewer_range()
            self._save_state()
        self._refresh_status()
        if dropped:
            self._set_status(f'Out at {frame} — In dropped, it was ahead of it.',
                             _log.WARN)

    def _mark_clip(self):
        """Mark the selection, clip or gap under the playhead."""
        idx = self._add_idx
        if not (0 <= idx < len(self._layers)):
            self._set_status('No layer selected.', _log.WARN)
            return

        sel = set(self._timeline.selection())

        found = mark_clip_range(
            self._layers[idx].clips,
            self._timeline._cursor_frame,
            selection=sel,
            track_first=self._timeline._tl_start,
        )
        if found is None:
            self._set_status('Nothing under the playhead to mark.', _log.WARN)
            return

        first, last, what = found
        self._set_marks(first, last)
        said = {'selection': f'{len(sel)} clip(s)',
                'clip':      'the clip',
                'gap':       'the gap'}[what]
        self._set_status(f'Marked {said} — {last - first + 1} frames.')


    def _on_layer_lock_toggled(self, idx):
        with _undo_group('SMTL: Track lock'):
            self._save_state()
        self._refresh_merge_bar()
        self._refresh_status()

    def _on_layer_hide_toggled(self, idx):
        """Toggle the layer's Merge disable knob without a rebuild."""
        with _undo_group('SMTL: Track hide'):
            _set_layer_merge_disabled(self._layers, idx)
            self._save_state()
        self._refresh_status()

    def _on_layer_solo_toggled(self, idx):
        """Update the solo switch and gates without a rebuild."""
        solo_idx = next((i for i, l in enumerate(self._layers) if l.solo), None)
        with _undo_group('SMTL: Track solo'):
            _set_solo_switch(solo_idx, self._active_idx, self._layers)
            self._save_state()
        self._refresh_status()


    def _copy_clip(self):
        """Copy the selected clip to the internal clipboard."""
        if not self._sel_clip:
            self._set_status('Nothing selected to copy.', _log.WARN)
            return
        c = self._sel_clip
        self._clipboard = {
            'node_name':  c.node_name,
            'label':      c.label,
            'src_first':  c.src_first,
            'src_last':   c.src_last,
            'duration':   c.duration,
        }
        self._clipboard.update({f: getattr(c, f)
                                for f in CLIP_MATERIAL_FIELDS})
        self._set_status(f'Copied: {c.display_label}  ({c.duration} frames)')

    def _paste_clip(self):
        """Paste the clipboard clip onto the add-target layer at the cursor."""
        if self._clipboard is None:
            self._set_status('Clipboard is empty — select a clip and press C to copy.',
                             _log.WARN)
            return

        cb        = self._clipboard
        layer_idx = self._add_idx
        layer     = self._layers[layer_idx]

        if layer_blocked(layer):
            why = 'muted' if getattr(layer, 'hidden', False) else 'locked'
            self._set_status(f'Track "{layer.name}" is {why} — cannot paste.',
                             _log.WARN)
            return

        cursor = self._timeline._cursor_frame
        tl_end = cursor + cb['duration'] - 1

        clip = SMTLClip(cb['node_name'], cb['label'], cursor, tl_end,
                        src_first=cb['src_first'], src_last=cb['src_last'])
        for field in CLIP_MATERIAL_FIELDS:
            if field in cb:
                setattr(clip, field, cb[field])
        clip.offline = _check_clip_offline(clip)
        layer.clips.append(clip)
        self._timeline._resolve_collisions(layer_idx, [clip])

        self._timeline._cursor_frame = tl_end + 1
        self._timeline.cursor_moved.emit(self._timeline._cursor_frame)
        self._timeline._update_size()
        self._timeline.update()

        self._sync_viewer_group('SMTL: Paste clip')
        self._refresh_status()
        print(f'[SMTL] Pasted "{cb.get("user_label") or cb["label"]}" → "{layer.name}"  '
              f'tl={cursor}–{tl_end}  src={cb["src_first"]}–{cb["src_last"]}')


_panel           = None
_widget_instance = None


class SMTLPanelKnob:
    """Knob factory that embeds the SMTL widget in a Nuke panel."""

    def makeUI(self):
        global _widget_instance
        _widget_instance = SMTLWidget()
        return _widget_instance

    def updateValue(self):
        pass


def _make_nuke_panel():
    import nukescripts
    import nuke

    class _NukeSMTLPanel(nukescripts.PythonPanel):
        def __init__(self):
            nukescripts.PythonPanel.__init__(
                self, 'Snow Monkey Time Line', 'com.snowmonkeyvfx.SMTL')
            knob = nuke.PyCustom_Knob(
                'smtl_panel', '',
                "__import__('sys').modules['_sm_smtl'].SMTLPanelKnob()")
            self.addKnob(knob)

    return _NukeSMTLPanel()


def _add_to_pane():
    sys.modules['_sm_smtl'] = sys.modules[__name__]
    return _make_nuke_panel().addToPane()


def registerPanel():
    """Register SMTL in Nuke's Pane menu."""
    try:
        import nuke
        import nukescripts

        sys.modules['_sm_smtl'] = sys.modules[__name__]
        nukescripts.registerPanel('com.snowmonkeyvfx.SMTL', _add_to_pane)
        nuke.menu('Pane').addCommand('Snow Monkey Time Line', _add_to_pane)
        print('[SMTL] Panel registered.')

    except Exception as e:
        print(f'[SMTL] registerPanel failed: {e}')


def reload_timeline():
    """Reload the SMTL timeline from the smtl_state knob on SMTL_Group."""
    widget = _active_widget() if _active_widget is not None else None
    if widget is not None:
        try:
            widget._reload_from_node()
            widget.show()
            widget.raise_()
            print('[SMTL] Timeline reloaded from node knob.')
            return
        except Exception as e:
            print(f'[SMTL] reload_timeline: widget reload failed ({e}), reopening panel')

    show()


def show():
    """Open the SMTL panel docked into the active Nuke pane."""
    global _panel
    try:
        _add_to_pane()
        return
    except Exception as e:
        _log.note(f'could not dock into the active pane: {e}', _log.WARN)

    if _panel is None or not _panel.isVisible():
        _panel = SMTLWidget()
        try:
            flags = Qt.WindowType.Tool
        except AttributeError:
            flags = Qt.Tool
        _panel.setWindowFlags(flags)
        _panel.resize(720, 300)
    _panel.show()
    _panel.raise_()
    _panel.activateWindow()

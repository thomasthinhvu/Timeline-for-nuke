SNOW MONKEY TIME LINE (SMTL) 1.0.1

Timeline panel for Nuke. Requires Nuke 14 or later. MIT licence.


INSTALL
Copy the SMTL_1_0_1 folder to ~/.nuke and add to menu.py:

    import SMTL_1_0_1.smtl_panel as smtl
    smtl.registerPanel()

Open from Pane > Snow Monkey Time Line.


ADDING CLIPS
Select a node, set the playhead, then Overwrite or Splice In.
With marks set:
    in and out    marks set the length
    in only       starts at the in
    out only      ends on the out
Ctrl-click ignores the marks. Nodes without a duration arrive as
five-second stills. Read nodes are never modified.


SELECTING
    click                 select
    Shift+click           toggle; a second Shift+click selects the range
    Ctrl+Shift+click      toggle one clip
    Ctrl+Shift+drag       lasso


MODES
    Edit (Y)       move clips. Alt+drag copies.
    Trim (U)       trim edges. Near a cut: roll. Shift: ripple.
                   Ctrl: dissolve. Alt: past the media.
    Slide          move clips along the track. Shift: slip.
    Splice         cut at the pointer.
    Sel L / Sel R  select everything to one side.
Click the active mode to return to Edit.


KEYS (pointer over the timeline)
    Z / X                  lift / extract
    Del / Backspace        delete dissolve, else lift; Shift: extract
    Y / U                  Edit / Trim
    T                      mark clip, selection or gap
    Shift+T                clear marks
    I / O                  mark in / out; Shift clears
    Alt+T, Alt+I, Alt+O    ghost marks
    C / V                  copy / paste
    D                      mute clip
    J / K / L              reverse / stop / play
    Left / Right           step one frame
    Ctrl+Z / Ctrl+Shift+Z  undo / redo


EDITING
Lift leaves a gap; Extract closes it. A selection takes priority over
the marks. Ctrl-click Lift or Extract to apply the marked range to every
track with a selected clip.

+ Dissolve adds a dissolve at the nearest cut. Shift: S curve.
Ctrl-click: alignment and length.

+ Freeze holds the playhead frame using a FrameHold in the main graph.

+ Retime sets clip speed. Right-click a retimed clip to change the node
type, open it or remove it. Kronos requires NukeX.

Replace swaps a clip's source, keeping position and length.

Alt+T ghosts the marks; Alt+T again restores them.


CLIPS
Right-click a clip to rename or colour it.
    red, !      offline
    amber, ?    source changed; use Refresh
    grey        muted
Each clip has its own merge Operation and Mix. Tracks composite
bottom-up and can be locked, muted or soloed.


INTERCHANGE
Import: EDL, OTIO, OTIOZ, FCP7 XML, FCPXML, AAF.
Conform links imported clips to media. Export writes OTIO.


PANEL BUTTONS
    Relink Viewer   point the viewer at SMTL_Group
    Refresh         re-read sources
    Rebuild         reload the timeline and rebuild SMTL_Group
    Reset           delete the timeline and SMTL_Group
    Log             status messages


NOTES
The timeline is saved in the Nuke script, on SMTL_Group. The group's
Rebuild Timeline button reopens it, including in another script.
A clip follows one named node. Use Replace after swapping a node
further up its tree.

"""Public entry point to the interchange parsers, by file extension."""

from smtl_parsers.common import (
    ImportEvent, ImportTransition, ImportedCut, track_kind,
    NULL_REELS, BLACK_REEL, VIDEO, AUDIO, OTHER,
    _hold_transition, _path_from_url)

from smtl_parsers.edl_parser import parse_cmx3600
from smtl_parsers.otio_parser import (parse_otio, _otio_media,
                                 _otio_speed, parse_otioz,
                                 otioz_media, extract_otioz,
                                 OTIOZ_CONTENT)
from smtl_parsers.fcp7_parser import parse_fcp7
from smtl_parsers.fcpxml_parser import parse_fcpxml
from smtl_parsers.aaf_parser import parse_aaf, _aaf_module


WANTS_PATH = frozenset({'.aaf', '.otioz'})


PARSERS = {
    '.edl':  parse_cmx3600,
    '.otio': parse_otio,
    '.xml':  parse_fcp7,
    '.fcpxml': parse_fcpxml,
    '.aaf':  parse_aaf,
    '.otioz': parse_otioz,
}

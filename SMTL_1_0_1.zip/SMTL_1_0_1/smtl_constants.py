"""Layout metrics, timing values, merge operations and DAG node names."""

__version__ = '1.0.1'

_SMTL_AUTHOR = 'Howard Jones'
_SMTL_URL    = 'https://snowmonkeyvfx.com'


_LAYER_H         = 34
_HEADER_H        = 30
_LABEL_W         = 260
_DEFAULT_ZOOM    = 4.0
_MIN_ZOOM        = 0.05
_MAX_ZOOM        = 800.0

_POLL_FAST_MS    = 50
_POLL_IDLE_MS    = 200
_POLL_IDLE_AFTER = 20
_PLAY_STILL_TICKS = 12


_STILL_SECONDS   = 5
_NO_WALL         = 10 ** 6
_STILL_HANDLE    = _NO_WALL


_MATCH_TAPE_W = 11
_MATCH_TAPE_H = 9

_TRIM_HANDLE_PX  = 30
_TRIM_ROLL_PX    = 7
_DRAG_TOLERANCE_PX = 4


_TC_FIELD_MIN_W  = 88
_TC_FIELD_CHROME = 20
_TC_FIELD_H      = 22

_FIT_MARGIN      = 0.02

_DOT_VIEW_X      = 17

_ICON_EDGE       = 16
_CLIP_ICON_GAP   = 3
_ICON_STEP       = 26


_MERGE_OPS = [
    'atop', 'average', 'color-burn', 'color-dodge', 'conjoint-over',
    'copy', 'difference', 'disjoint-over', 'divide', 'exclusion',
    'from', 'geometric', 'hard-light', 'hypot', 'in',
    'mask', 'matte', 'max', 'min', 'minus',
    'multiply', 'out', 'over', 'overlay', 'plus',
    'screen', 'soft-light', 'stencil', 'under', 'XOR',
]


_DLG_MARGIN      = 14
_DLG_SPACING     = 8
_DLG_GROUP_GAP   = 14
_DLG_INDENT      = 18
_DLG_FIELD_W     = 150
_DLG_FIELD_H     = 26


_NO_MEDIA          = '<no media>'

_SMTL_GROUP_NAME   = 'SMTL_Group'
_SMTL_LAYER_SWITCH = 'SMTL_LayerSwitch'
_SMTL_SOLO_SWITCH  = 'SMTL_SoloSwitch'
_SMTL_STATE_KNOB   = 'smtl_state'

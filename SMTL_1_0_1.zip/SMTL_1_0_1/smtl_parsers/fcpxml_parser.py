"""FCPXML parser."""

import re as _re
import xml.etree.ElementTree as _ET

from smtl_models import frames_to_timecode

from smtl_parsers.common import (ImportEvent, ImportTransition, ImportedCut,
                            VIDEO, AUDIO, _hold_transition, _path_from_url)


_RATIONAL_RE = _re.compile(r'^\s*(-?\d+)(?:/(\d+))?s\s*$')


def _fcpxml_seconds(text, default=0.0):
    """Return a rational FCPXML time such as `86401/24s` in seconds."""
    if not text:
        return float(default)
    m = _RATIONAL_RE.match(str(text))
    if not m:
        return float(default)
    num = float(m.group(1))
    den = float(m.group(2) or 1)
    return num / den if den else float(default)


def _fcpxml_primary_ref(el):
    """Return the asset a wrapper's primary media reference names, or ''."""
    for child in el:
        if child.tag in ('video', 'audio') and child.get('lane') is None:
            if child.get('ref'):
                return child.get('ref')
    return ''


def _fcpxml_timemap(el, rate):
    """Return (start frame, speed) from a clip's timeMap, or None."""
    tm = el.find('timeMap')
    if tm is None:
        return None
    pts = [(_fcpxml_seconds(p.get('time')), _fcpxml_seconds(p.get('value')))
           for p in tm.findall('timept')]
    if len(pts) < 2:
        return None
    (t0, v0), (t1, v1) = pts[0], pts[1]
    if not (t1 > t0):
        return None
    speed = 0.0 if abs(v1 - v0) < 1e-9 else (v1 - v0) / (t1 - t0)
    return int(round(v0 * rate)), speed


def _fcpxml_ramps(el):
    """Return True when the timeMap has more than one speed within the clip."""
    tm = el.find('timeMap')
    if tm is None:
        return False
    dur = _fcpxml_seconds(el.get('duration'))
    pts = [(_fcpxml_seconds(p.get('time')), _fcpxml_seconds(p.get('value')))
           for p in tm.findall('timept')]
    slopes = set()
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t1 > t0 and t0 < dur:
            slopes.add(round((v1 - v0) / (t1 - t0), 6))
    return len(slopes) > 1


def parse_fcpxml(text, rate=None, drop=None):
    """Read an FCPXML sequence into an `ImportedCut`."""
    root = _ET.fromstring(text)
    res  = {r.get('id'): r for r in (root.find('resources') or [])}
    seq  = root.find('.//sequence')
    if seq is None:
        return ImportedCut(fmt='fcpxml', rate=float(rate or 24.0))

    fmt = res.get(seq.get('format'))
    frame_dur = _fcpxml_seconds(fmt.get('frameDuration')) if fmt is not None else 0
    stated = (1.0 / frame_dur) if frame_dur else None
    seq_rate = float(stated or rate or 24.0)
    is_drop  = (str(seq.get('tcFormat') or '').upper() == 'DF')

    def frames(text, default=0.0):
        return int(round(_fcpxml_seconds(text, default) * seq_rate))

    start = frames(seq.get('tcStart'))
    cut = ImportedCut(rate=seq_rate, drop=is_drop, fmt='fcpxml',
                      title=str((root.find('.//project') or seq).get('name')
                                or ''),
                      stated_rate=stated, stated_start=start)

    lanes = {}

    def walk(node, parent_offset, lane=0):
        """Place every clip under `node`, offsets accumulating downwards."""
        pending_head = None
        pending_at   = None
        last_by_lane = {}
        for el in node:
            if el.tag == 'transition':
                at = parent_offset + frames(el.get('offset'))
                n  = frames(el.get('duration'))
                pending_head = _hold_transition(
                    pending_head,
                    ImportTransition('dissolve', before=0, after=n),
                    cut.notes, 'lane %d' % lane)
                pending_at   = at
                continue
            if el.tag == 'spine':
                walk(el, parent_offset + frames(el.get('offset'))
                     - frames(el.get('start')),
                     int(el.get('lane') or lane))
                continue
            if el.tag not in ('asset-clip', 'clip', 'video', 'audio', 'gap'):
                continue
            if (el.tag in ('video', 'audio') and el.get('lane') is None
                    and node.tag in ('clip', 'asset-clip', 'video',
                                     'audio')):
                continue
            offset = parent_offset + frames(el.get('offset'))
            dur    = frames(el.get('duration'))
            if el.tag == 'gap':
                walk(el, offset - frames(el.get('start')), lane)
                pending_head, pending_at = None, None
                continue

            here   = int(el.get('lane') or lane)
            asset  = res.get(el.get('ref') or _fcpxml_primary_ref(el))
            rep    = asset.find('media-rep') if asset is not None else None
            path   = _path_from_url(rep.get('src') if rep is not None
                                    else (asset.get('src')
                                          if asset is not None else ''))
            a_fmt  = res.get(asset.get('format')) if asset is not None else None
            a_dur  = (_fcpxml_seconds(a_fmt.get('frameDuration'))
                      if a_fmt is not None else 0)
            a_rate = (1.0 / a_dur) if a_dur else seq_rate
            src_i  = int(round(_fcpxml_seconds(el.get('start')) * a_rate))

            has_video = (el.tag == 'video'
                         or (asset is not None
                             and (str(asset.get('hasVideo') or '') == '1'
                                  or asset.get('format'))))
            reel = ''
            for holder in (el, asset):
                if holder is None:
                    continue
                for md in holder.findall('.//md'):
                    key = str(md.get('key') or '')
                    if key.endswith('.reel') or key == 'reel':
                        if md.get('value'):
                            reel = str(md.get('value'))
                            break
                if reel:
                    break
            src_span = int(round(_fcpxml_seconds(el.get('duration'))
                                 * a_rate)) or dur
            speed = (a_rate / seq_rate) if (a_rate and seq_rate) else 1.0
            mapped = _fcpxml_timemap(el, a_rate)
            if mapped is not None:
                src_i, speed = mapped
                src_span = dur
                if _fcpxml_ramps(el):
                    cut.notes.append(
                        'event %d: the retime changes speed part way '
                        'through and comes in at the speed it starts at — '
                        'the shape is on the node to rebuild'
                        % (len(cut.events) + 1))
            elif el.find('timeMap') is not None:
                cut.notes.append(
                    'event %d: a retime is stated but could not be read, '
                    'so it comes in as an ordinary clip'
                    % (len(cut.events) + 1))

            ev = ImportEvent(
                number    = str(len(cut.events) + 1),
                track     = 'Lane %d' % here,
                track_id  = here,
                kind      = VIDEO if (has_video and el.tag != 'audio') else AUDIO,
                rec_first = offset,
                rec_last  = offset + dur - 1,
                src_first = src_i,
                src_last  = src_i + src_span - 1,
                speed     = speed,
                reel        = reel,
                name        = str(el.get('name') or ''),
                source_name = str(asset.get('name') or '')
                              if asset is not None else '',
                path        = path,
                src_tc    = frames_to_timecode(src_i, a_rate, is_drop),
                src_rate  = a_rate,
            )
            if pending_head is not None and pending_at is not None:
                if pending_at <= offset:
                    ev.transition = pending_head
                elif last_by_lane.get(here) is not None:
                    last_by_lane[here].tail_transition = ImportTransition(
                        'dissolve', before=pending_head.after, after=0)
                pending_head, pending_at = None, None
            cut.events.append(ev)
            lanes.setdefault(here, []).append(ev)
            last_by_lane[here] = ev
            if cut.stated_end is None or ev.rec_last > cut.stated_end:
                cut.stated_end = ev.rec_last
            walk(el, offset - frames(el.get('start')), lane)
        if pending_head is not None and pending_at is not None:
            for _lane, ev in last_by_lane.items():
                if ev is not None:
                    ev.tail_transition = ImportTransition(
                        'dissolve', before=pending_head.after, after=0)
                    break

    spine = seq.find('spine')
    if spine is not None:
        walk(spine, 0)

    for lane in sorted(l for l in lanes
                       if any(e.kind == VIDEO for e in lanes[l])):
        cut.tracks.append({'name': 'Lane %d' % lane, 'id': lane,
                           'kind': VIDEO, 'hidden': False})
    cut.events.sort(key=lambda e: (e.rec_first, e.rec_last))
    n_audio = len(cut.of_kind(AUDIO))
    if n_audio:
        cut.ignored['audio'] = n_audio
    return cut

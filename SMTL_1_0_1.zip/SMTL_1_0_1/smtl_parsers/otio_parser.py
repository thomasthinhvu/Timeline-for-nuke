"""OpenTimelineIO and OTIOZ parser, reading OTIO as JSON."""

import json as _json
import os as _os

from smtl_models import frames_to_timecode

from smtl_parsers.common import (ImportEvent, ImportTransition, ImportedCut,
                            VIDEO, AUDIO, _hold_transition, _path_from_url)


def _rt(node, default=0.0):
    """Return a RationalTime's value, or a default."""
    if not isinstance(node, dict):
        return float(default)
    return float(node.get('value', default))


def _rt_rate(node, default=24.0):
    if not isinstance(node, dict):
        return float(default)
    return float(node.get('rate', default))


def _schema(node):
    return str((node or {}).get('OTIO_SCHEMA', '')).split('.')[0]


def _otio_ref(clip):
    """Return a clip's active media reference, or an empty dict."""
    refs = clip.get('media_references')
    if isinstance(refs, dict) and refs:
        key = clip.get('active_media_reference_key')
        ref = refs.get(key) or next(iter(refs.values()))
    else:
        ref = clip.get('media_reference')
    return ref if isinstance(ref, dict) else {}


def _otio_start_frame(ref, at, media_start):
    """Return the image-sequence file number for media time `at`, or None."""
    if _schema(ref) != 'ImageSequenceReference':
        return None
    start = ref.get('start_frame')
    if start is None or media_start is None:
        return None
    step = int(ref.get('frame_step') or 1)
    return int(start) + (int(at) - int(media_start)) * step


def _otio_media(clip):
    """Return (name, path, available_range) for a clip's active media reference."""
    ref = _otio_ref(clip)

    path = _path_from_url(ref.get('target_url'))
    if not path and _schema(ref) == 'ImageSequenceReference':
        base   = _path_from_url(ref.get('target_url_base'))
        prefix = str(ref.get('name_prefix') or '')
        suffix = str(ref.get('name_suffix') or '')
        pad    = int(ref.get('frame_zero_padding') or 0)
        if base or prefix:
            path = '%s%s%s%s' % (base.rstrip('/') + '/' if base else '',
                                 prefix, '%%0%dd' % pad if pad else '%d',
                                 suffix)
    return (str(ref.get('name') or ''), path, ref.get('available_range'))


def _otio_speed(clip):
    """Return the speed a clip's time effect asks for, or 1.0."""
    for eff in clip.get('effects') or []:
        if isinstance(eff, dict) and 'time_scalar' in eff:
            return float(eff['time_scalar'])
    return 1.0


def parse_otio(text, rate=None, drop=None):
    """Read an OTIO timeline into an `ImportedCut`."""
    data  = _json.loads(text or '{}')
    gst   = data.get('global_start_time') or {}
    stated_rate = _rt_rate(gst, 0.0) or None
    seq_rate    = float(stated_rate or rate or 24.0)
    cut = ImportedCut(rate=seq_rate, drop=bool(drop), fmt='otio',
                      title=str(data.get('name') or ''),
                      stated_rate=stated_rate,
                      stated_start=(int(round(_rt(gst))) if gst else None))

    stack = data.get('tracks') or {}
    for t_idx, track in enumerate(stack.get('children') or []):
        kind = (VIDEO if str(track.get('kind', '')).lower().startswith('v')
                else AUDIO)
        name = str(track.get('name') or '')
        if kind == VIDEO:
            cut.tracks.append({
                'name':   name,
                'id':     t_idx,
                'kind':   kind,
                'hidden': not bool(track.get('enabled', True)),
            })
        at   = int(round(_rt(gst)))
        pending_head = None
        last_event   = None

        for child in track.get('children') or []:
            what = _schema(child)
            if what == 'Transition':
                tr = ImportTransition(
                    kind   = 'dissolve',
                    before = int(round(_rt(child.get('in_offset')))),
                    after  = int(round(_rt(child.get('out_offset')))),
                )
                pending_head = _hold_transition(pending_head, tr,
                                                cut.notes, 'track %r' % name)
                continue

            src = child.get('source_range') or {}
            dur = int(round(_rt(src.get('duration'))))
            if what == 'Gap':
                if pending_head is not None and last_event is not None:
                    last_event.tail_transition = pending_head
                at += dur
                pending_head, last_event = None, None
                continue
            if what != 'Clip':
                cut.notes.append('%s in track %r is not a clip and was left'
                                 % (what or 'an item', name))
                at += dur
                continue

            mname, path, avail = _otio_media(child)
            first = int(round(_rt(src.get('start_time'))))
            raw_first = first
            src_rate = _rt_rate(src.get('start_time'), seq_rate)
            speed = _otio_speed(child)
            media_rate  = 0.0
            media_start = None
            if isinstance(avail, dict):
                media_rate  = _rt_rate(avail.get('start_time'), 0.0)
                media_start = int(round(_rt(avail.get('start_time'))))
            span = dur
            if (media_rate and src_rate and media_start is not None
                    and abs(media_rate - src_rate) > 1e-6):
                ratio = media_rate / src_rate
                head  = int(round(media_start * src_rate / media_rate))
                off   = first - head
                first = media_start + int(round(off * ratio))
                span  = (media_start + int(round((off + dur * (abs(speed) or 1.0))
                                                  * ratio))) - first
                speed = speed * ratio
                src_rate = media_rate
            src_frame = _otio_start_frame(_otio_ref(child), raw_first,
                                          media_start)
            ev = ImportEvent(
                number    = str(len(cut.events) + 1),
                track     = name,
                track_id  = t_idx,
                kind      = kind,
                rec_first = at,
                rec_last  = at + dur - 1,
                src_first = first,
                src_last  = first + span - 1,
                reel        = '',
                name        = str(child.get('name') or mname),
                source_name = mname,
                path        = path,
                src_tc    = frames_to_timecode(first, src_rate,
                                               bool(drop)),
                src_frame = src_frame,
                src_rate  = src_rate,
                speed     = speed,
            )
            if pending_head is not None:
                ev.transition = pending_head
                pending_head  = None
            cut.events.append(ev)
            last_event = ev
            at += dur

        if pending_head is not None and last_event is not None:
            last_event.tail_transition = pending_head

        if cut.stated_end is None or at - 1 > cut.stated_end:
            cut.stated_end = at - 1

    cut.events.sort(key=lambda e: (e.rec_first, e.rec_last))
    n_audio = len(cut.of_kind(AUDIO))
    if n_audio:
        cut.ignored['audio'] = n_audio
    return cut


OTIOZ_CONTENT = 'content.otio'
OTIOZ_MEDIA   = 'media/'


def _otioz_zip(path):
    """Return the bundle open for reading; raise ValueError if it is not one."""
    import zipfile
    zf = zipfile.ZipFile(path)
    if OTIOZ_CONTENT not in zf.namelist():
        zf.close()
        raise ValueError('no %s in the bundle — this is a zip, not an OTIOZ'
                         % OTIOZ_CONTENT)
    return zf


def parse_otioz(path, rate=None, drop=None):
    """Read the timeline out of an OTIOZ bundle without extracting."""
    zf = _otioz_zip(path)
    try:
        text = zf.read(OTIOZ_CONTENT).decode('utf-8', 'replace')
    finally:
        zf.close()
    cut = parse_otio(text, rate, drop)
    cut.format = 'otioz'
    return cut


def otioz_media(path):
    """Return the bundle's media as [(name, bytes)] without extracting."""
    zf = _otioz_zip(path)
    try:
        return [(_os.path.basename(n), zf.getinfo(n).file_size)
                for n in zf.namelist()
                if n.startswith(OTIOZ_MEDIA) and not n.endswith('/')]
    finally:
        zf.close()


def extract_otioz(path, dest):
    """Extract the bundle's media into `dest`; return {zip name: path}."""
    zf = _otioz_zip(path)
    out = {}
    try:
        for name in zf.namelist():
            if not name.startswith(OTIOZ_MEDIA) or name.endswith('/'):
                continue
            landed = _os.path.join(dest, *name.split('/'))
            if not _os.path.exists(landed):
                zf.extract(name, dest)
            out[name] = landed
    finally:
        zf.close()
    return out

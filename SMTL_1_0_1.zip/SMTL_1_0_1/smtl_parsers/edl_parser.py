"""CMX3600 edit decision list parser."""

import re as _re

from smtl_models import timecode_to_frames, frames_to_timecode

from smtl_parsers.common import (ImportEvent, ImportTransition, ImportedCut,
                            track_kind, AUDIO, OTHER, BLACK_REEL)


_TC = r'(\d{1,2}[:;]\d{2}[:;]\d{2}[:;]\d{2})'

_EVENT_RE = _re.compile(
    r'^\s*(?P<num>\d+)\s+'
    r'(?P<reel>\S+)\s+'
    r'(?P<track>\S+)\s+'
    r'(?P<edit>W\d{3}|[A-Z]+)\s*'
    r'(?P<dur>\d+)?\s+'
    r'(?P<si>' + _TC + r')\s+(?P<so>' + _TC + r')\s+'
    r'(?P<ri>' + _TC + r')\s+(?P<ro>' + _TC + r')\s*$'
)

_M2_RE = _re.compile(
    r'^\s*M2\s+(?P<reel>\S+)\s+(?P<fps>-?[\d.]+)\s+' + _TC + r'\s*$'
)

_FCM_RE     = _re.compile(r'^\s*FCM:\s*(?P<mode>.+?)\s*$', _re.I)
_TITLE_RE   = _re.compile(r'^\s*TITLE:\s*(?P<title>.*?)\s*$', _re.I)
_FROM_RE    = _re.compile(r'^\s*\*\s*FROM CLIP NAME:\s*(?P<name>.*?)\s*$', _re.I)
_TO_RE      = _re.compile(r'^\s*\*\s*TO CLIP NAME:\s*(?P<name>.*?)\s*$', _re.I)
_SRCFILE_RE = _re.compile(r'^\s*\*\s*SOURCE FILE:\s*(?P<name>.*?)\s*$', _re.I)

_NOT_A_NAME = frozenset({'transition'})


def parse_cmx3600(text, rate, drop=None):
    """Read a CMX3600 list into an `ImportedCut`, sorted by record in."""
    cut = ImportedCut(rate=rate, drop=bool(drop), fmt='cmx3600')
    fcm_drop = None
    events   = []
    pending  = None
    from_side = None

    def _f(tc, dr):
        return timecode_to_frames(tc, rate, dr)

    for raw in (text or '').splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue

        m = _TITLE_RE.match(line)
        if m and not _EVENT_RE.match(line):
            cut.title = m.group('title')
            continue

        m = _FCM_RE.match(line)
        if m:
            mode = m.group('mode').upper()
            fcm_drop = ('NON' not in mode) and ('DROP' in mode)
            continue

        m = _M2_RE.match(line)
        if m:
            if pending is None:
                cut.notes.append('M2 line with no event before it — ignored')
                continue
            fps = float(m.group('fps'))
            base = float(rate)
            pending.speed = 0.0 if fps == 0 else (fps / base if base else 1.0)
            if fps == 0 and pending.src_length > 1:
                pending.notes.append(
                    'M2 says speed 0 (freeze) but the source advances %d '
                    'frames — contradictory, left as a freeze'
                    % pending.src_length)
            continue

        m = _FROM_RE.match(line)
        if m:
            name = m.group('name')
            if pending is not None and name.strip().lower() not in _NOT_A_NAME:
                pending.name = name
            continue

        m = _SRCFILE_RE.match(line)
        if m:
            if pending is not None:
                pending.source_name = m.group('name')
            continue

        m = _TO_RE.match(line)
        if m:
            if pending is not None:
                pending.name = m.group('name')
            continue

        m = _EVENT_RE.match(line)
        if not m:
            if not line.lstrip().startswith('*'):
                cut.notes.append('unrecognised line: %s' % line.strip())
            continue

        dr = fcm_drop if drop is None else bool(drop)
        if dr is None:
            dr = False
        reel  = m.group('reel')
        edit  = m.group('edit').upper()
        rec_i = _f(m.group('ri'), dr)
        rec_o = _f(m.group('ro'), dr)
        src_i = _f(m.group('si'), dr)
        src_o = _f(m.group('so'), dr)

        if rec_o <= rec_i:
            from_side = reel.strip().upper()
            pending = None
            continue

        ev = ImportEvent(
            number    = m.group('num'),
            track     = m.group('track'),
            kind      = track_kind(m.group('track')),
            rec_first = rec_i,
            rec_last  = rec_o - 1,
            src_first = src_i,
            src_last  = src_o - 1,
            reel      = reel,
            src_tc    = frames_to_timecode(src_i, rate, dr),
            src_rate  = float(rate),
        )
        if edit[:1] in ('D', 'W') and m.group('dur'):
            ev.transition = ImportTransition(
                kind       = 'dissolve',
                before     = 0,
                after      = int(m.group('dur')),
                from_black = (from_side == BLACK_REEL),
            )
            if edit.startswith('W'):
                cut.notes.append('event %s: wipe %s brought in as a %d-frame '
                                 'dissolve' % (m.group('num'), edit,
                                               int(m.group('dur'))))
        from_side = None
        events.append(ev)
        pending = ev

    events.sort(key=lambda e: (e.rec_first, e.rec_last))
    cut.events = events

    if drop is None and fcm_drop is not None:
        cut.drop = bool(fcm_drop)

    for ev in events:
        for note in ev.notes:
            cut.notes.append('event %s: %s' % (ev.number, note))

    n_audio = len(cut.of_kind(AUDIO))
    n_other = len(cut.of_kind(OTHER))
    if n_audio:
        cut.ignored['audio'] = n_audio
    if n_other:
        cut.ignored['other'] = n_other
    return cut

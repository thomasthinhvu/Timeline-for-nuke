"""AAF parser, through pyaaf2."""

import os as _os

from smtl_models import frames_to_timecode

from smtl_parsers.common import (ImportEvent, ImportTransition, ImportedCut,
                            VIDEO, AUDIO, OTHER, _path_from_url)


def _aaf_module():
    """Return the pyaaf2 module, preferring an installed copy over the vendored one."""
    try:
        import aaf2
        return aaf2
    except ImportError:
        pass
    import os as _os
    import sys as _sys
    vendor = _os.path.join(
        _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
        'vendor')
    if vendor not in _sys.path:
        _sys.path.append(vendor)
    import aaf2
    return aaf2


def _aaf_locator(mob):
    """Return the file this mob's own descriptor points at, or ''."""
    try:
        descriptor = mob.descriptor
    except Exception:
        return ''
    if descriptor is None:
        return ''
    try:
        for locator in (descriptor['Locator'].value or []):
            url = locator['URLString'].value
            if url:
                return _path_from_url(url)
    except Exception:
        pass
    return ''


def _aaf_timecode(mob):
    """Return the (start, rate, drop) a mob's timecode slot states, or None."""
    for slot in (getattr(mob, 'slots', None) or []):
        seg = getattr(slot, 'segment', None)
        if seg is None or type(seg).__name__ != 'Timecode':
            continue
        try:
            return (int(seg['Start'].value), float(seg['FPS'].value),
                    bool(seg['Drop'].value))
        except Exception:
            continue
    return None


def _aaf_source_chain(mob, depth=0):
    """Follow a mob down to its media; return path, reel, length and timecode."""
    out = {'path': '', 'reel': '', 'length': None,
           'tc_start': None, 'tc_rate': 0.0, 'tc_drop': False}
    if mob is None or depth > 8:
        return out
    try:
        descriptor = mob.descriptor
    except Exception:
        descriptor = None

    timecode = _aaf_timecode(mob)
    if timecode is not None:
        out['tc_start'], out['tc_rate'], out['tc_drop'] = timecode

    if descriptor is not None:
        if type(descriptor).__name__ == 'TapeDescriptor':
            out['reel'] = str(getattr(mob, 'name', '') or '')
            return out
        out['path'] = _aaf_locator(mob)

    for slot in (getattr(mob, 'slots', None) or []):
        seg = getattr(slot, 'segment', None)
        if seg is None or type(seg).__name__ != 'SourceClip':
            continue
        if out['length'] is None:
            try:
                out['length'] = int(getattr(seg, 'length', 0) or 0) or None
            except Exception:
                out['length'] = None
        try:
            below = seg.mob
        except Exception:
            below = None
        if below is None:
            continue
        deeper = _aaf_source_chain(below, depth + 1)
        for key in ('path', 'reel', 'length'):
            out[key] = out[key] or deeper[key]
        if out['tc_start'] is None and deeper['tc_start'] is not None:
            out['tc_start'] = deeper['tc_start']
            out['tc_rate']  = deeper['tc_rate']
            out['tc_drop']  = deeper['tc_drop']
        if out['path'] and out['reel'] and out['tc_start'] is not None:
            break
    return out


def parse_aaf(text, rate=None, drop=None):
    """Read an AAF file at path `text` into an `ImportedCut`."""
    aaf2 = _aaf_module()
    cut  = ImportedCut(fmt='aaf', rate=float(rate or 24.0))

    with aaf2.open(text, 'r') as f:
        for mob in f.content.toplevel():
            cut.title = str(mob.name or '')
            start, seq_rate, is_drop = 0, float(rate or 24.0), bool(drop)

            for slot in mob.slots:
                seg = slot.segment
                if seg.media_kind != 'Timecode':
                    continue
                try:
                    start    = int(seg.start)
                    seq_rate = float(seg.fps)
                    is_drop  = bool(seg['Drop'].value)
                except Exception:
                    pass
            cut.rate         = seq_rate
            cut.drop         = is_drop
            cut.stated_rate  = seq_rate
            cut.stated_start = start

            for slot in mob.slots:
                seg  = slot.segment
                kind = (VIDEO if seg.media_kind == 'Picture'
                        else AUDIO if seg.media_kind == 'Sound' else OTHER)
                if kind == OTHER:
                    continue
                seqs = (list(getattr(seg, 'slots', []) or [])
                        if type(seg).__name__ == 'NestedScope' else [seg])
                for t_idx, sequence in enumerate(seqs, 1):
                    name = str(slot.name or '') or '%s %d' % (
                        'Video' if kind == VIDEO else 'Audio', t_idx)
                    if len(seqs) > 1:
                        name = '%s %d' % (
                            'Video' if kind == VIDEO else 'Audio', t_idx)
                    t_id = len(cut.tracks) if kind == VIDEO else \
                           'audio %d' % t_idx
                    if kind == VIDEO:
                        cut.tracks.append({'name': name, 'id': t_id,
                                           'kind': kind, 'hidden': False})
                    _aaf_track(cut, sequence, name, kind, start,
                               seq_rate, is_drop, t_id)

    cut.events.sort(key=lambda e: (e.rec_first, e.rec_last))
    n_audio = len(cut.of_kind(AUDIO))
    if n_audio:
        cut.ignored['audio'] = n_audio
    return cut


def _aaf_track(cut, sequence, name, kind, start, seq_rate, is_drop,
               track_id=None):
    """Walk one AAF Sequence, adding its clips and transitions to the cut."""
    at           = int(start)
    pending_head = None
    last_event   = None

    for comp in getattr(sequence, 'components', []) or []:
        what   = type(comp).__name__
        length = int(getattr(comp, 'length', 0) or 0)

        if what == 'Transition':
            at -= length
            pending_head = ImportTransition('dissolve', before=0, after=length)
            continue

        if what in ('Filler', 'ScopeReference'):
            if pending_head is not None and last_event is not None:
                last_event.tail_transition = ImportTransition(
                    'dissolve', before=pending_head.after, after=0)
            at += length
            pending_head, last_event = None, None
            continue

        clip = comp
        if what == 'OperationGroup':
            inner = [c for c in (getattr(comp, 'segments', None)
                                 or getattr(comp, 'slots', None) or [])
                     if type(c).__name__ == 'SourceClip']
            if inner:
                clip = inner[0]
        if type(clip).__name__ != 'SourceClip':
            at += length
            continue

        try:
            mob = clip.mob
        except Exception:
            mob = None
        chain = _aaf_source_chain(mob)
        path, reel = chain['path'], chain['reel']
        src_rate = chain['tc_rate'] or seq_rate
        drop     = chain['tc_drop'] if chain['tc_rate'] else is_drop
        start = int(getattr(clip, 'start', 0) or 0)
        base  = int(chain['tc_start'] or 0)
        ratio = ((src_rate / seq_rate)
                 if (src_rate and seq_rate
                     and abs(src_rate - seq_rate) > 1e-6) else 0.0)
        if ratio:
            src_first = base + int(round(start * ratio))
            src_last  = base + int(round((start + length) * ratio)) - 1
            speed     = ratio
        else:
            src_first = base + start
            src_last  = src_first + length - 1
            speed     = 1.0
        src_name = _os.path.basename(path) if path else ''
        ev = ImportEvent(
            number    = str(len(cut.events) + 1),
            track     = name,
            track_id  = track_id,
            kind      = kind,
            rec_first = at,
            rec_last  = at + length - 1,
            src_first = src_first,
            src_last  = src_last,
            speed     = speed,
            reel        = reel,
            name        = str(getattr(mob, 'name', '') or ''),
            source_name = src_name,
            path        = path,
            src_tc    = frames_to_timecode(src_first, src_rate, drop),
            src_rate  = src_rate,
        )
        if pending_head is not None:
            ev.transition, pending_head = pending_head, None
        cut.events.append(ev)
        last_event = ev
        at += length
        if cut.stated_end is None or ev.rec_last > cut.stated_end:
            cut.stated_end = ev.rec_last

    if pending_head is not None and last_event is not None:
        last_event.tail_transition = ImportTransition(
            'dissolve', before=pending_head.after, after=0)

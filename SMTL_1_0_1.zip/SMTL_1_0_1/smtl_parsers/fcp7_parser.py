"""FCP7 XML (xmeml) parser."""

import xml.etree.ElementTree as _ET

from smtl_models import timecode_to_frames, frames_to_timecode

from smtl_parsers.common import (ImportEvent, ImportTransition, ImportedCut,
                            VIDEO, AUDIO, _hold_transition, _path_from_url)


def _fcp7_time(el, tag, default=None):
    text = el.findtext(tag)
    if text is None or text.strip() == '':
        return default
    try:
        return int(text)
    except ValueError:
        return default


def _fcp7_freeze(el):
    """Return (is_freeze, held_frame) from a timeremap filter; held may be None."""
    for filt in el.findall('filter'):
        eff = filt.find('effect')
        if eff is None:
            continue
        if str(eff.findtext('effectid') or '').strip() != 'timeremap':
            continue
        speed = held = None
        for par in eff.findall('parameter'):
            pid = str(par.findtext('parameterid') or '').strip()
            if pid == 'speed':
                try:
                    speed = float(par.findtext('value'))
                except (TypeError, ValueError):
                    speed = None
            elif pid == 'graphdict':
                keys = par.findall('keyframe')
                marked = [k for k in keys
                          if str(k.findtext('speedkfin') or '').upper() == 'TRUE']
                for k in (marked or keys):
                    try:
                        held = int(round(float(k.findtext('value'))))
                        break
                    except (TypeError, ValueError):
                        continue
        if speed is not None and abs(speed) < 1e-9:
            return True, held
    return False, None


def parse_fcp7(text, rate=None, drop=None):
    """Read an FCP7 XML (xmeml) sequence into an `ImportedCut`."""
    root = _ET.fromstring(text)
    seq  = root.find('.//sequence')
    if seq is None:
        return ImportedCut(fmt='fcp7', rate=float(rate or 24.0))

    rate_el = seq.find('rate')
    stated  = (float(rate_el.findtext('timebase'))
               if rate_el is not None and rate_el.findtext('timebase')
               else None)
    seq_rate = float(stated or rate or 24.0)

    tc_el   = seq.find('timecode')
    start   = _fcp7_time(tc_el, 'frame', 0) if tc_el is not None else 0
    is_drop = (str(tc_el.findtext('displayformat') or '').upper() == 'DF'
               if tc_el is not None else bool(drop))

    cut = ImportedCut(rate=seq_rate, drop=is_drop, fmt='fcp7',
                      title=str(seq.findtext('name') or ''),
                      stated_rate=stated, stated_start=start)

    files = {}
    for f in root.iter('file'):
        fid = f.get('id')
        if fid and f.findtext('pathurl') is not None:
            files[fid] = f

    media = seq.find('media')
    for kind_tag, kind in (('video', VIDEO), ('audio', AUDIO)):
        group = media.find(kind_tag) if media is not None else None
        if group is None:
            continue
        for t_idx, track in enumerate(group.findall('track'), 1):
            name = '%s %d' % (kind_tag.capitalize(), t_idx)
            t_id = '%s %d' % (kind_tag, t_idx)
            if kind == VIDEO:
                cut.tracks.append({
                    'name': name, 'id': t_id, 'kind': kind,
                    'hidden': str(track.findtext('enabled') or 'TRUE'
                                  ).upper() == 'FALSE',
                })
            pending_head = None
            pending_at   = None
            last_event   = None
            for el in track:
                if el.tag == 'transitionitem':
                    a  = str(el.findtext('alignment') or 'center').lower()
                    n  = (_fcp7_time(el, 'end', 0) or 0) - (_fcp7_time(el, 'start', 0) or 0)
                    if a.startswith('end'):
                        if last_event is not None:
                            last_event.tail_transition = ImportTransition(
                                'dissolve', before=n, after=0)
                    elif a.startswith('start'):
                        pending_head = _hold_transition(
                            pending_head,
                            ImportTransition('dissolve', before=0, after=n),
                            cut.notes, 'track %r' % name)
                    else:
                        half = n // 2
                        pending_head = _hold_transition(
                            pending_head,
                            ImportTransition('dissolve', before=half,
                                             after=n - half),
                            cut.notes, 'track %r' % name)
                    pending_at = _fcp7_time(el, 'start', None)
                    continue
                if el.tag != 'clipitem':
                    continue

                src_i = _fcp7_time(el, 'in', 0) or 0
                src_o = _fcp7_time(el, 'out', 0) or 0
                dur   = src_o - src_i
                rec_i = _fcp7_time(el, 'start', -1)
                rec_o = _fcp7_time(el, 'end', -1)
                if rec_i is None or rec_i < 0:
                    if rec_o is not None and rec_o >= 0:
                        rec_i = rec_o - dur
                    elif pending_at is not None:
                        rec_i = pending_at
                    else:
                        rec_i = 0
                if rec_o is None or rec_o < 0:
                    rec_o = rec_i + dur

                f    = el.find('file')
                fid  = f.get('id') if f is not None else None
                full = files.get(fid, f)
                path = _path_from_url(full.findtext('pathurl')
                                      if full is not None else '')
                f_rate = seq_rate
                if full is not None:
                    fr = full.find('rate')
                    if fr is not None and fr.findtext('timebase'):
                        f_rate = float(fr.findtext('timebase'))

                media_start = 0
                said = full.findtext('timecode/string') if full is not None \
                    else None
                if said:
                    try:
                        media_start = timecode_to_frames(said, f_rate,
                                                         ';' in said)
                    except Exception:
                        media_start = 0

                reel = ''
                for holder in (full, el):
                    if holder is None:
                        continue
                    got = holder.findtext('timecode/reel/name')
                    if got and got.strip():
                        reel = got.strip()
                        break
                src_name = str((full.findtext('name') or '')
                               if full is not None else '')

                frozen, held = _fcp7_freeze(el)
                speed = 1.0
                if frozen and held is not None:
                    src_i, src_o = held, held + (rec_o - rec_i)
                    speed = 0.0
                elif frozen:
                    cut.notes.append(
                        'event %d: a freeze is stated but the frame it holds '
                        'could not be read, so it comes in as an ordinary '
                        'clip' % (len(cut.events) + 1))

                ratio = ((f_rate / seq_rate)
                         if (f_rate and seq_rate
                             and abs(f_rate - seq_rate) > 1e-6) else 0.0)
                if ratio:
                    src_first = media_start + int(round(src_i * ratio))
                    src_last  = media_start + int(round(src_o * ratio)) - 1
                    speed     = speed * ratio
                else:
                    src_first = src_i + media_start
                    src_last  = src_o - 1 + media_start

                ev = ImportEvent(
                    number    = str(len(cut.events) + 1),
                    track     = name,
                    track_id  = t_id,
                    kind      = kind,
                    rec_first = start + rec_i,
                    rec_last  = start + rec_o - 1,
                    src_first = src_first,
                    src_last  = src_last,
                    speed     = speed,
                    reel        = reel,
                    name        = str(el.findtext('name') or ''),
                    source_name = src_name,
                    path        = path,
                    src_tc    = frames_to_timecode(src_first, f_rate,
                                                   is_drop),
                    src_rate  = f_rate,
                )
                if pending_head is not None:
                    ev.transition, pending_head = pending_head, None
                pending_at = None
                cut.events.append(ev)
                last_event = ev
                if cut.stated_end is None or ev.rec_last > cut.stated_end:
                    cut.stated_end = ev.rec_last

    cut.events.sort(key=lambda e: (e.rec_first, e.rec_last))
    n_audio = len(cut.of_kind(AUDIO))
    if n_audio:
        cut.ignored['audio'] = n_audio
    return cut

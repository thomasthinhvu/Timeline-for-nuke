"""Neutral event list returned by every parser, and shared helpers."""

import re as _re
from urllib.parse import unquote as _unquote, urlparse as _urlparse


NULL_REELS = frozenset({'AX', 'BL', ''})

BLACK_REEL = 'BL'

VIDEO, AUDIO, OTHER = 'video', 'audio', 'other'


def track_kind(track):
    """Return the kind (video, audio or other) a CMX track column names."""
    t = (track or '').strip().upper()
    if t.startswith('V'):
        return VIDEO
    if t.startswith('A'):
        return AUDIO
    return OTHER


class ImportTransition(object):
    """A transition, as offsets either side of the point it sits on."""

    __slots__ = ('kind', 'before', 'after', 'from_black')

    def __init__(self, kind='dissolve', before=0, after=0, from_black=False):
        self.kind       = kind
        self.before     = int(before)
        self.after      = int(after)
        self.from_black = bool(from_black)

    def __repr__(self):
        return ('ImportTransition(%r, before=%d, after=%d, from_black=%r)'
                % (self.kind, self.before, self.after, self.from_black))


class ImportEvent(object):
    """One imported event, in inclusive frames, with its identity evidence."""

    __slots__ = (
        'number', 'track', 'track_id', 'kind',
        'rec_first', 'rec_last',
        'src_first', 'src_last',
        'reel', 'name', 'source_name', 'path',
        'src_tc', 'src_frame', 'src_rate',
        'speed', 'transition', 'tail_transition', 'notes',
    )

    def __init__(self, number='', track='V', kind=VIDEO, track_id=None,
                 rec_first=0, rec_last=0, src_first=0, src_last=0,
                 reel='', name='', path='', source_name='',
                 src_tc='', src_frame=None, src_rate=0.0,
                 speed=1.0, transition=None, tail_transition=None):
        self.number     = str(number)
        self.track      = str(track)
        self.track_id   = track_id
        self.kind       = kind
        self.rec_first  = int(rec_first)
        self.rec_last   = int(rec_last)
        self.src_first  = int(src_first)
        self.src_last   = int(src_last)
        self.reel       = str(reel)
        self.name        = str(name)
        self.source_name = str(source_name)
        self.path        = str(path)
        self.src_tc     = str(src_tc)
        self.src_frame  = None if src_frame is None else int(src_frame)
        self.src_rate   = float(src_rate)
        self.speed      = float(speed)
        self.transition      = transition
        self.tail_transition = tail_transition
        self.notes           = []

    @property
    def rec_length(self):
        return self.rec_last - self.rec_first + 1

    @property
    def src_length(self):
        return self.src_last - self.src_first + 1

    def __repr__(self):
        return ('ImportEvent(%s %s rec %d-%d src %d-%d %r)'
                % (self.number, self.track, self.rec_first, self.rec_last,
                   self.src_first, self.src_last, self.name or self.reel))


class ImportedCut(object):
    """Events, rate, declared extents and notes read from one file."""

    __slots__ = ('events', 'rate', 'drop', 'title', 'notes', 'ignored',
                 'format', 'stated_rate', 'stated_start', 'stated_end', 'tracks')

    def __init__(self, events=None, rate=24.0, drop=False, title='',
                 fmt='cmx3600', stated_rate=None, stated_start=None,
                 stated_end=None, tracks=None):
        self.events  = list(events or [])
        self.rate    = float(rate)
        self.drop    = bool(drop)
        self.title   = str(title)
        self.format  = fmt
        self.notes   = []
        self.ignored = {}
        self.stated_rate  = stated_rate
        self.stated_start = stated_start
        self.stated_end   = stated_end
        self.tracks = list(tracks or [])

    def of_kind(self, kind):
        return [e for e in self.events if e.kind == kind]

    @property
    def video(self):
        return self.of_kind(VIDEO)

    def start(self):
        """Return the declared start, or the earliest event's record frame."""
        if self.stated_start is not None:
            return int(self.stated_start)
        span = self.span()
        return None if span is None else span[0]

    def end(self):
        """Return the declared end, or the last event's record frame."""
        if self.stated_end is not None:
            return int(self.stated_end)
        span = self.span()
        return None if span is None else span[1]

    def span(self):
        """Return (first, last) record frames across every event, or None if empty."""
        if not self.events:
            return None
        return (min(e.rec_first for e in self.events),
                max(e.rec_last for e in self.events))

    def __repr__(self):
        return ('ImportedCut(%s, %d events, %g fps%s)'
                % (self.format, len(self.events), self.rate,
                   ', drop' if self.drop else ''))


def _hold_transition(pending, arriving, notes, where=''):
    """Merge an arriving transition with a held one, noting the merge."""
    if pending is None:
        return arriving
    notes.append('two transitions at one point%s were read as one; a cut is '
                 'one anchor' % (' in %s' % where if where else ''))
    return ImportTransition(
        kind       = pending.kind or arriving.kind,
        before     = max(pending.before, arriving.before),
        after      = max(pending.after,  arriving.after),
        from_black = pending.from_black or arriving.from_black,
    )


def _path_from_url(url):
    """Return a local path from a target_url or file:// URL."""
    if not url:
        return ''
    if url.startswith('file:'):
        parsed = _unquote(_urlparse(url).path)
        host = _urlparse(url).netloc
        if host and host.lower() != 'localhost':
            parsed = '//%s%s' % (host, parsed)
        path = parsed
    else:
        path = _unquote(url)

    path = path.replace('\\', '/')
    m = _re.match(r'^/([A-Za-z]:/)', path)
    if m:
        path = path[1:]
    return path

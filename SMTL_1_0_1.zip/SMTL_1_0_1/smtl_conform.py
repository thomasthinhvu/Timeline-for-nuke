"""Match clips to media files on disk and place their frames."""

import os as _os
import re as _re

from smtl_constants import _NO_MEDIA
from smtl_models import timecode_to_frames
from smtl_parse import NULL_REELS


ORIGINAL_PATH = 'original'
CUSTOM_PATH   = 'custom'


class SearchSpec(object):
    """Conform search settings from the dialogue."""

    __slots__ = ('search_in', 'root', 'use_reel', 'use_name', 'use_ext',
                 'ext', 'case_sensitive', 'recurse')

    def __init__(self, search_in=ORIGINAL_PATH, root='', use_reel=False,
                 use_name=True, use_ext=True, ext='', case_sensitive=True,
                 recurse=True):
        self.search_in = search_in
        self.root      = str(root or '')
        self.use_reel  = bool(use_reel)
        self.use_name  = bool(use_name)
        self.use_ext   = bool(use_ext)
        self.ext       = str(ext or '').lower()
        self.case_sensitive = bool(case_sensitive)
        self.recurse   = bool(recurse)

    @property
    def usable(self):
        """Return False when there is nothing to match on."""
        if self.search_in == ORIGINAL_PATH:
            return True
        return bool(self.use_reel or self.use_name)


class Candidate(object):
    """A file or sequence on disk that could be a clip's media."""

    __slots__ = ('path', 'first', 'last', '_runs', 'tc', 'tc_frame',
                 'rate', 'width', 'height')

    def __init__(self, path, first=0, last=0, tc='', tc_frame=0, rate=0.0,
                 width=0, height=0, runs=None):
        self.path     = str(path)
        self.first    = int(first)
        self.last     = int(last)
        self._runs    = (tuple((int(a), int(b)) for a, b in runs)
                         if runs else None)
        self.tc       = str(tc or '')
        self.tc_frame = int(tc_frame)
        self.rate     = float(rate or 0.0)
        self.width    = int(width or 0)
        self.height   = int(height or 0)

    @property
    def runs(self):
        """The frames really there, and **not a copy taken at birth**.

        A movie says nothing about its length until a Read opens it, so
        the caller fills `first` and `last` in afterwards — and a tuple
        built in `__init__` would still be saying 0-0 when it did.  So
        where nothing has been told, the answer is derived every time.

        Told something, it is kept: only `collapse` knows about holes,
        because only a directory listing does.
        """
        if self._runs is None:
            return ((self.first, self.last),)
        return self._runs

    @runs.setter
    def runs(self, value):
        self._runs = (tuple((int(a), int(b)) for a, b in value)
                      if value else None)

    @property
    def name(self):
        return _os.path.basename(self.path)

    @property
    def ext(self):
        return _os.path.splitext(self.path)[1].lower()

    @property
    def stem(self):
        """Return the name with its extension and any frame padding removed."""
        base = _os.path.splitext(self.name)[0]
        return _SEQ_TAIL_RE.sub('', base)

    def __repr__(self):
        return '<Candidate %r %d-%d>' % (self.path, self.first, self.last)


_SEQ_MEMBER_RE = _re.compile(r'^(?P<stem>.*?)(?P<sep>[._]?)(?P<num>\d+)$')
_SEQ_TAIL_RE   = _re.compile(r'[._]?%0?\d*d$')


def _runs(numbers):
    """Return the unbroken runs formed by a list of frame numbers."""
    out = []
    start = prev = None
    for n in sorted(set(int(x) for x in numbers)):
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append((start, prev))
            start = prev = n
    if start is not None:
        out.append((start, prev))
    return tuple(out)


def collapse(paths):
    """Group file paths into candidates, collapsing sequences."""
    groups = {}
    singles = []
    for path in paths:
        folder, name = _os.path.split(path)
        base, ext = _os.path.splitext(name)
        m = _SEQ_MEMBER_RE.match(base)
        if not m or not m.group('num'):
            singles.append(Candidate(path))
            continue
        num = m.group('num')
        key = (folder, m.group('stem'), m.group('sep'), len(num), ext)
        groups.setdefault(key, []).append(int(num))

    out = list(singles)
    for (folder, stem, sep, pad, ext), numbers in groups.items():
        if len(numbers) == 1:
            n = numbers[0]
            name = '%s%s%0*d%s' % (stem, sep, pad, n, ext)
            out.append(Candidate(_os.path.join(folder, name), n, n))
            continue
        name = '%s%s%%0%dd%s' % (stem, sep, pad, ext)
        runs = _runs(numbers)
        out.append(Candidate(_os.path.join(folder, name),
                             runs[0][0], runs[-1][1], runs=runs))
    out.sort(key=lambda c: c.path)
    return out


def scan(root, recurse=True):
    """Return every file under root, collapsed into candidates."""
    found = []
    if not root or not _os.path.isdir(root):
        return []
    if recurse:
        for folder, _dirs, files in _os.walk(root):
            found.extend(_os.path.join(folder, f) for f in files
                         if not f.startswith('.'))
    else:
        found.extend(_os.path.join(root, f) for f in _os.listdir(root)
                     if not f.startswith('.')
                     and _os.path.isfile(_os.path.join(root, f)))
    return collapse(found)


def _fold(text, spec):
    """Return text case-folded according to the search spec."""
    text = str(text or '')
    return text if spec.case_sensitive else text.lower()


def _same_name(candidate, wanted_name, spec):
    """Return True when the candidate's stem matches the wanted name."""
    if not wanted_name:
        return False
    want_stem, _want_ext = _os.path.splitext(wanted_name)
    want_stem = _SEQ_TAIL_RE.sub('', want_stem)
    if _fold(candidate.stem, spec) != _fold(want_stem, spec):
        return False
    if spec.use_ext and spec.ext:
        return candidate.ext == (spec.ext if spec.ext.startswith('.')
                                 else '.' + spec.ext)
    return True


def is_reel(reel):
    """Return True when this is a reel rather than a placeholder for one."""
    return str(reel or '').strip().upper() not in NULL_REELS


def _has_reel(candidate, reel, spec):
    """Return True when the candidate's name or folder contains the reel."""
    want = _fold(str(reel or '').strip(), spec)
    if not want:
        return False
    stem   = _fold(candidate.stem, spec)
    folder = _fold(_os.path.basename(_os.path.dirname(candidate.path)), spec)
    if want in stem or want in folder:
        return True
    head, tail = want[:4], want[4:]
    return bool(head and tail and head in stem
                and tail in stem and stem.index(head) < stem.index(tail))


def _tc_span(candidate):
    """Return (first, last) of a candidate in timecode frames, or None."""
    if not candidate.tc or candidate.rate <= 0:
        return None
    try:
        at = timecode_to_frames(candidate.tc, candidate.rate,
                                ';' in candidate.tc)
    except Exception:
        return None
    return (at - (candidate.tc_frame - candidate.first),
            at + (candidate.last - candidate.tc_frame))


def _span_at(candidate, rate):
    """Return a candidate's timecode span counted at the given rate."""
    span = _tc_span(candidate)
    if span is None:
        return None
    if not rate or not candidate.rate or abs(rate - candidate.rate) < 1e-6:
        return span
    scale = float(rate) / float(candidate.rate)
    start = int(round(span[0] * scale))
    return (start, start + int((span[1] - span[0]) * scale))


def runs_at(candidate, rate=0.0):
    """Return a candidate's runs counted at the given rate, or None."""
    span = _span_at(candidate, rate or candidate.rate)
    if span is None:
        return None
    runs = candidate.runs
    if len(runs) == 1:
        return (span,)
    out = []
    for lo, hi in runs:
        out.append((_at_clock(candidate, lo, rate),
                    _at_clock(candidate, hi, rate)))
    return tuple(out)


def _at_clock(candidate, media_frame, rate=0.0):
    """Return the timecode frame of a media frame at the given rate."""
    rate = rate or candidate.rate
    span = _span_at(candidate, rate)
    if span is None:
        return None
    into = int(media_frame) - candidate.first
    if rate and candidate.rate and abs(rate - candidate.rate) > 1e-6:
        into = int(round(into * float(rate) / float(candidate.rate)))
    return span[0] + into


def missing_in(candidate, first_tc_frame, last_tc_frame, rate=0.0):
    """Return the parts of first..last this media does not hold."""
    runs = runs_at(candidate, rate)
    if runs is None:
        return ()
    return gaps_in(runs, first_tc_frame, last_tc_frame)


def runs_of(path):
    """Return the runs of a printf-padded sequence on disk, or None."""
    if not path or '%0' not in path:
        return None
    folder, name = _os.path.split(path)
    try:
        head, tail = name.split('%0', 1)
        pad = int(tail.split('d', 1)[0])
        after = tail.split('d', 1)[1]
    except (ValueError, IndexError):
        return None
    numbers = []
    try:
        entries = _os.listdir(folder)
    except OSError:
        return None
    for entry in entries:
        if not entry.startswith(head) or not entry.endswith(after):
            continue
        mid = entry[len(head):len(entry) - len(after)] if after \
            else entry[len(head):]
        if len(mid) != pad or not mid.isdigit():
            continue
        numbers.append(int(mid))
    if not numbers:
        return None
    return _runs(numbers)


def gaps_in(runs, first, last):
    """Return the parts of first..last no run covers."""
    lo_want, hi_want = int(first), int(last)
    if hi_want < lo_want:
        return ()
    out = []
    at = lo_want
    for lo, hi in runs:
        if hi < at:
            continue
        if lo > hi_want:
            break
        if lo > at:
            out.append((at, min(lo - 1, hi_want)))
        at = max(at, hi + 1)
        if at > hi_want:
            break
    if at <= hi_want:
        out.append((at, hi_want))
    return tuple(out)


def covers(candidate, first_tc_frame, last_tc_frame, rate=0.0):
    """Return True when the media holds every timecode frame in the range."""
    span = _span_at(candidate, rate or candidate.rate)
    if span is None:
        return False
    if span[0] > first_tc_frame or span[1] < last_tc_frame:
        return False
    return not missing_in(candidate, first_tc_frame, last_tc_frame, rate)

def place(candidate, tc_frame, rate=0.0):
    """Return the media frame for a timecode frame."""
    rate = rate or candidate.rate
    span = _span_at(candidate, rate)
    if span is None:
        return None
    into = int(tc_frame) - span[0]
    if rate and candidate.rate and abs(rate - candidate.rate) > 1e-6:
        into = int(round(into * float(candidate.rate) / float(rate)))
    return candidate.first + into


MATCHED, CONFLICT, NOT_FOUND = 'matched', 'conflict', 'none'


class Decision(object):
    """Matcher result: matched, conflict or not found."""

    __slots__ = ('state', 'candidate', 'candidates', 'first', 'flags',
                 'anchor')

    def __init__(self, state, candidate=None, candidates=None, first=None,
                 flags=None, anchor=None):
        self.state      = state
        self.anchor     = anchor
        self.candidate  = candidate
        self.candidates = list(candidates or [])
        self.first      = first
        self.flags      = list(flags or [])

    def __repr__(self):
        return '<Decision %s %r>' % (self.state, self.candidate)


def _say(trace, text):
    if trace is not None:
        trace.append(text)


def match(clip, candidates, spec, trace=None):
    """Match one clip against a pool of candidates."""
    pool = list(candidates)
    _say(trace, '%s: %d candidate%s to start with'
         % (clip.display_label, len(pool), '' if len(pool) == 1 else 's'))
    _say(trace, '    the edit said  name=%r  path=%r  tc=%r @ %g'
         % (clip.src_name, clip.src_path, clip.src_tc, clip.src_rate))

    if spec.search_in == ORIGINAL_PATH:
        if not clip.src_path:
            _say(trace, '    the edit gave no path, so there is nowhere to '
                        'look — this format states none')
            return Decision(NOT_FOUND,
                            flags=['the file gave no path to look at'])
        pool = [c for c in pool if _same_path(c.path, clip.src_path)]
        _say(trace, '    at the original path: %d' % len(pool))
        return _place(clip, pool, trace=trace)

    if spec.use_reel:
        if not is_reel(clip.src_reel):
            _say(trace, '    reel is ticked and this clip has none (%r) — '
                        'skipped' % (clip.src_reel,))
        else:
            pool = [c for c in pool if _has_reel(c, clip.src_reel, spec)]
            _say(trace, '    after reel %r: %d' % (clip.src_reel, len(pool)))

    if spec.use_name:
        if not clip.src_name:
            _say(trace, '    the edit named no source, and no clip name to '
                        'fall back to — nothing to identify this with')
            return Decision(NOT_FOUND,
                            flags=['this clip has no name to match on'])
        pool = [c for c in pool if _same_name(c, clip.src_name, spec)]
        _say(trace, '    after name %r%s: %d'
             % (clip.src_name,
                ' + extension' if (spec.use_ext and spec.ext) else '',
                len(pool)))
    elif spec.use_ext and spec.ext:
        want = spec.ext if spec.ext.startswith('.') else '.' + spec.ext
        pool = [c for c in pool if c.ext == want]
        _say(trace, '    after extension %s: %d' % (want, len(pool)))

    return _place(clip, pool, trace=trace)


NUMBERING, TIMECODE = 'numbering', 'timecode'


def demand(clip, candidate):
    """Return (anchor, first, last) the clip asks of a candidate, or None."""
    src_frame = getattr(clip, 'src_frame', None)
    if src_frame is not None:
        off  = int(src_frame) - int(clip.src_first)
        first = int(clip.orig_src_first) + off
        last  = int(clip.orig_src_last) + off
        if last >= candidate.first and first <= candidate.last:
            return (NUMBERING, first, last)
    if _tc_span(candidate) is not None:
        return (TIMECODE, int(clip.orig_src_first), int(clip.orig_src_last))
    return None


def _lacking(clip, candidate):
    """Return (anchor, gaps, wanted) for a clip against a candidate."""
    asked = demand(clip, candidate)
    if asked is None:
        return None, None, 0
    anchor, first, last = asked
    wanted = max(0, int(last) - int(first) + 1)
    if anchor == NUMBERING:
        return anchor, gaps_in(candidate.runs, first, last), wanted
    rate = float(clip.src_rate or 0.0)
    return anchor, missing_in(candidate, first, last, rate), wanted


WHOLLY, PARTLY, NOWHERE = 'wholly', 'partly', 'nowhere'


def _state(gaps, wanted):
    """WHOLLY, PARTLY or NOWHERE, from what a file lacks of what was asked."""
    if not gaps:
        return WHOLLY
    absent = sum(int(hi) - int(lo) + 1 for lo, hi in gaps)
    return NOWHERE if absent >= wanted else PARTLY


def held(clip, candidate):
    """Return (state, gaps) for how much of a clip a candidate holds."""
    anchor, gaps, wanted = _lacking(clip, candidate)
    if anchor is None:
        return NOWHERE, ()
    state = _state(gaps, wanted)
    return state, (() if state == WHOLLY else gaps)


def _place(clip, pool, trace=None):
    """Choose the candidate that can place and hold the clip's frames."""
    flags = []
    rate = float(clip.src_rate or 0.0)
    anchors, lacks, states = {}, {}, {}
    usable = []
    for cand in pool:
        anchor, gaps, wanted = _lacking(clip, cand)
        if anchor is None:
            continue
        anchors[id(cand)] = anchor
        lacks[id(cand)] = gaps
        states[id(cand)] = _state(gaps, wanted)
        usable.append(cand)
    _say(trace, '    of those, %d share an anchor with the clip' % len(usable))
    if not usable:
        if not pool:
            _say(trace, '    nothing left — not found')
            return Decision(NOT_FOUND)
        said = ('nothing states where the frames go — no timecode, and no '
                'numbering these files use')
        if len(pool) > 1:
            return Decision(CONFLICT, candidates=pool, flags=[said])
        if pool:
            said = '%s: %s' % (pool[0].name, said)
        return Decision(NOT_FOUND, flags=[said])
    covering = [c for c in usable if states[id(c)] == WHOLLY]
    for cand in usable[:4]:
        if anchors[id(cand)] == NUMBERING:
            _say(trace, '    %s is placed by its own frame numbering'
                 % cand.name)
        elif rate and cand.rate and abs(rate - cand.rate) > 1e-6:
            _say(trace, '    %s runs at %g and the cut counts it at %g '
                        '— compared as time, not as frames'
                 % (cand.name, cand.rate, rate))
    _say(trace, '    holding everything asked for: %d' % len(covering))
    for cand in usable[:4]:
        gaps = lacks[id(cand)]
        _say(trace, '        %s lacks %d frame%s'
             % (cand.name, sum(b - a + 1 for a, b in gaps),
                '' if sum(b - a + 1 for a, b in gaps) == 1 else 's'))
    if not covering:
        covering = [c for c in usable if states[id(c)] == PARTLY]
    pool = covering

    if not pool:
        _say(trace, '    nothing left — not found')
        return Decision(NOT_FOUND)
    if len(pool) > 1:
        _say(trace, '    %d left, so it is a choice' % len(pool))
        return Decision(CONFLICT, candidates=pool)

    only = pool[0]
    _say(trace, '    matched %s' % only.path)
    gaps = lacks.get(id(only)) or ()
    if gaps:
        flags.append(_shortfall(only, gaps, rate))
    return Decision(MATCHED, candidate=only, flags=flags,
                    anchor=anchors.get(id(only)))


def _shortfall(candidate, gaps, rate=0.0):
    """Return the flag text for frames a clip needs and lacks."""
    gone = sum(b - a + 1 for a, b in gaps)
    said = 'missing %d frame%s' % (gone, '' if gone == 1 else 's')
    span = _span_at(candidate, rate or candidate.rate)
    if span is not None and all(b < span[0] or a > span[1] for a, b in gaps):
        return said + ' — the pull is short'
    return said + ' of what this clip needs'


def _same_path(a, b):
    """Return True when two paths name one file, ignoring case and slashes."""
    return (str(a or '').replace('\\', '/').rstrip('/').lower()
            == str(b or '').replace('\\', '/').rstrip('/').lower())


def distinguishing(paths):
    """Return the shortest part of each path that tells it from the others."""
    parts = [str(p or '').replace('\\', '/').strip('/').split('/')
             for p in paths]
    if len(parts) < 2:
        return [_os.path.basename(str(p or '')) for p in paths]

    def shared(index_of):
        n = 0
        while True:
            try:
                seen = {p[index_of(n, len(p))] for p in parts}
            except IndexError:
                return n
            if len(seen) != 1 or all(n + 1 >= len(p) for p in parts):
                return n
            n += 1

    head = shared(lambda n, _l: n)
    tail = shared(lambda n, l: l - 1 - n)

    def middles(head):
        return [p[head:len(p) - tail] if head + tail < len(p) else []
                for p in parts]

    while head > 0 and any(not m for m in middles(head)):
        head -= 1
    return ['/'.join(m) or p[-1] for m, p in zip(middles(head), parts)]


def group_by_source(clips):
    """Group clips by the media path or name they ask for."""
    out = {}
    for clip in clips:
        key = (clip.src_path or '').lower() or (clip.src_name or '').lower()
        if not key:
            key = ('\x00id', clip.clip_id)
        out.setdefault(key, []).append(clip)
    return out


def rebase(clips, decision):
    """Move a group of clips onto the media's own frame numbering."""
    if not clips or decision.candidate is None:
        return None
    cand  = decision.candidate
    moved = None
    decision.first = None
    if decision.anchor == NUMBERING:
        for c in clips:
            off = int(c.src_frame) - int(c.src_first)
            if moved is None:
                moved = off
                decision.first = int(c.src_frame)
            c.src_first += off
            c.src_last  += off
            c.orig_src_first = min(int(cand.first), c.src_first)
            c.orig_src_last  = max(int(cand.last),  c.src_last)
        return moved
    for c in clips:
        rate  = float(c.src_rate or 0.0)
        head  = place(cand, int(c.src_first), rate)
        tail  = place(cand, int(c.src_last) + 1, rate)
        if head is None or tail is None:
            return moved
        tail -= 1
        if moved is None:
            moved = head - int(c.src_first)
            decision.first = head
        c.src_first, c.src_last = head, tail
        c.orig_src_first = min(int(cand.first), head)
        c.orig_src_last  = max(int(cand.last),  tail)
    return moved


def unconform(clip, media_rate=0.0):
    """Restore a conformed clip to the cut its file stated."""
    tc   = str(clip.src_tc or '')
    rate = float(clip.src_rate or 0.0)
    if not tc or rate <= 0:
        return False
    try:
        head = int(timecode_to_frames(tc, rate, ';' in tc))
    except Exception:
        return False
    span  = int(clip.src_last) - int(clip.src_first)
    media_rate = float(media_rate or 0.0)
    if media_rate > 0 and abs(media_rate - rate) > 1e-6:
        span = int(round(span * rate / media_rate))
    clip.src_first = head
    clip.src_last  = head + span
    clip.orig_src_first = clip.src_first
    clip.orig_src_last  = clip.src_last
    clip.node_name = _NO_MEDIA
    return True
